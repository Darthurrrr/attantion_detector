ATTENTION DETECTOR — COMPILE HOTFIX

This hotfix fixes the two Dart compilation errors reported by the user:
1) lib/screens/landing.dart: imports ../core/models.dart so Pet is defined.
2) lib/tests/host.dart: removes const from the Text widget whose TextStyle calls alpha().

Install:
- Stop Flutter (Ctrl+C).
- Extract this ZIP into C:\attention_flutter and allow overwrite.
- Run: flutter run -d edge --web-port=53919 --dart-define=API_BASE=http://127.0.0.1:8000

Only the two affected Dart files are included. It does not replace your database or other project files.
