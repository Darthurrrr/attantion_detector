"""Contract tests: metrics emitted by Flutter games must be accepted by logic.py."""
from __future__ import annotations

import unittest

import logic


FLUTTER_METRICS = {
    "reaction": {"avg_ms": 320, "false_starts": 0, "attempts": 5, "best_ms": 250},
    "stroop": {"total": 10, "correct": 8, "avg_ms": 1000},
    "schulte": {"size": 4, "seconds": 35.0, "errors": 1, "hints": 0},
    "memory": {"max_len": 6, "mistakes": 0},
    "gonogo": {
        "hits": 10,
        "go_total": 12,
        "false_alarms": 1,
        "nogo_total": 8,
        "avg_ms": 500,
    },
    "nback": {
        "n": 1,
        "hits": 6,
        "targets": 7,
        "false_alarms": 1,
        "non_targets": 12,
    },
    "simon": {"max_len": 6, "mistakes": 0},
    "odd": {"total": 8, "correct": 6, "avg_ms": 2500, "size": 3},
}


class FlutterMetricsContractTests(unittest.TestCase):
    def test_all_flutter_test_payloads_are_scored(self) -> None:
        self.assertEqual(set(FLUTTER_METRICS), set(logic.TEST_NAMES))
        for test, metrics in FLUTTER_METRICS.items():
            with self.subTest(test=test):
                score = logic.score_result(test, metrics, age=12)
                self.assertIsInstance(score, int)
                self.assertGreaterEqual(score, 0)
                self.assertLessEqual(score, 100)
                self.assertTrue(logic.recommendation(test, score, metrics))

    def test_unknown_test_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            logic.score_result("not_a_test", {}, age=12)


if __name__ == "__main__":
    unittest.main()
