"""Логика оценки внимания: баллы, уровни, рекомендации, адаптивная сложность, коуч.
Без внешних зависимостей, чтобы её можно было тестировать отдельно."""

import random
from datetime import date

TEST_NAMES = {
    "reaction": "Реакция",
    "stroop": "Тест Струпа",
    "schulte": "Таблица Шульте",
    "memory": "Память на числа",
    "gonogo": "Светофор",
    "nback": "N-назад",
    "simon": "Повтори за роботом",
    "odd": "Лишнее",
}


def _clamp(x, lo=0.0, hi=100.0):
    return max(lo, min(hi, x))


def level_of(score):
    if score >= 80:
        return "высокий"
    if score >= 60:
        return "средний"
    return "низкий"


def score_result(test, m, age=None):
    """Переводит сырые метрики теста в балл 0..100. Возраст (если известен) смягчает нормы для детей."""
    kid = max(0, 18 - int(age)) if age else 0
    if test == "reaction":
        avg = float(m["avg_ms"]) - kid * 6          # дети реагируют чуть медленнее: добавляем «бонус»
        false_starts = int(m.get("false_starts", 0))
        s = 100 - (avg - 220) * 0.15 - false_starts * 8
    elif test == "stroop":
        total = max(1, int(m["total"]))
        acc = int(m["correct"]) / total
        avg = float(m["avg_ms"]) - kid * 25
        s = acc * 70 + _clamp(30 - (avg - 700) / 40, 0, 30)
    elif test == "schulte":
        size = int(m["size"])
        eff = float(m["seconds"]) + 2.0 * int(m.get("errors", 0)) + 1.0 * int(m.get("hints", 0))
        per_cell = eff / (size * size)
        # ожидаемое время на клетку растёт с размером: в большой таблице искать заметно дольше
        base = (0.8 + 0.14 * size) * (1 + 0.03 * kid)
        r = per_cell / base
        bonus = 3.0 * max(0, size - 4)                   # награда за сложность: 7×7 +9, 10×10 +18
        s = 100 - (r - 0.8) * 80 + bonus
    elif test == "memory":
        bonus = max(0, 16 - int(age)) * 0.1 if age else 0.0
        s = (int(m["max_len"]) + (bonus if int(m["max_len"]) > 0 else 0) - 3) * 20
    elif test == "gonogo":
        go_acc = int(m["hits"]) / max(1, int(m["go_total"]))
        stop_acc = 1 - int(m["false_alarms"]) / max(1, int(m["nogo_total"]))
        acc = 0.5 * go_acc + 0.5 * stop_acc
        avg = float(m.get("avg_ms", 600)) - kid * 12
        s = 78 * acc + _clamp(22 - (avg - 380) / 18, 0, 22)
    elif test == "nback":
        n = int(m["n"])
        hit = int(m["hits"]) / max(1, int(m["targets"]))
        fa = int(m["false_alarms"]) / max(1, int(m["non_targets"]))
        s = (0.6 * hit + 0.4 * (1 - fa)) * 100 * (0.92 + 0.04 * n)
    elif test == "simon":
        bonus = max(0, 16 - int(age)) * 0.1 if age else 0.0
        s = (int(m["max_len"]) + (bonus if int(m["max_len"]) > 0 else 0) - 2) * 13
    elif test == "odd":
        acc = int(m["correct"]) / max(1, int(m["total"]))
        avg = float(m.get("avg_ms", 3000)) - kid * 60
        s = acc * 72 + _clamp(28 - (avg - 1600) / 70, 0, 28) + 2 * max(0, int(m.get("size", 3)) - 3)
    else:
        raise ValueError(f"Неизвестный тест: {test}")
    return int(round(_clamp(s)))


def recommendation(test, score, m):
    name = TEST_NAMES[test]
    if test == "reaction" and int(m.get("false_starts", 0)) >= 2:
        return "Много ложных стартов: вы торопитесь. Попробуйте сначала дождаться сигнала, а потом реагировать."
    if test == "stroop" and int(m["correct"]) / max(1, int(m["total"])) < 0.8:
        return "Много ошибок в Струпе: замедлитесь и отвечайте на ЦВЕТ букв, а не на слово."
    if test == "schulte" and int(m.get("errors", 0)) >= 3:
        return "Много промахов в таблице Шульте: держите взгляд в центре и ищите цифру периферийным зрением."
    if test == "memory" and int(m.get("mistakes", 0)) >= 3:
        return "Попробуйте группировать цифры по 2-3 (например 48-215): так запоминать легче."
    if test == "gonogo" and int(m.get("false_alarms", 0)) >= 3:
        return "Много нажатий на красный: сначала смотрите на цвет, а уже потом жмите."
    if test == "nback" and score < 60:
        return "Не получается? Начните с N=1: запоминайте только предыдущий символ."
    if test == "simon" and int(m.get("max_len", 0)) < 5:
        return "Разбейте последовательность на части по 3-4 сигнала: так её проще удержать."
    if test == "odd" and int(m.get("correct", 0)) < int(m.get("total", 1)) * 0.7:
        return "Не спешите: сначала оглядите всё поле, потом выбирайте лишнее."
    if score >= 80:
        return f"{name}: отличный результат. Система предложит усложнение."
    if score >= 60:
        return f"{name}: хороший уровень. Ещё 2-3 тренировки, и можно усложнять."
    return f"{name}: пока ниже нормы. Тренируйтесь короткими сессиями по 5 минут и отдохните."


def streak_info(rows, today=None, freezes=0):
    """(серия, сколько заморозок потрачено). Заморозка перекрывает один пропущенный день."""
    days = sorted({r["created_at"][:10] for r in rows}, reverse=True)
    if not days:
        return 0, 0
    today = today or date.today()
    cur = date.fromisoformat(days[0])
    left, used = int(freezes), 0
    gap = (today - cur).days - 1
    if gap > 0:
        if gap > left:
            return 0, 0
        left -= gap
        used += gap
    streak, prev = 1, cur
    for d in days[1:]:
        dd = date.fromisoformat(d)
        miss = (prev - dd).days - 1
        if miss == 0:
            streak += 1
        elif miss <= left:
            left -= miss
            used += miss
            streak += 1
        else:
            break
        prev = dd
    return streak, used


def streak_days(rows, today=None, freezes=0):
    """Сколько дней подряд (до сегодня/вчера) были тренировки."""
    return streak_info(rows, today, freezes)[0]


def summary(rows):
    """rows — результаты, новые сверху. Каждый: test, score, ..."""
    per = {}
    for r in rows:
        per.setdefault(r["test"], []).append(r["score"])
    tests = {}
    for t, scores in per.items():
        tests[t] = {
            "count": len(scores),
            "best": max(scores),
            "avg": round(sum(scores) / len(scores)),
            "last": scores[0],
        }
    overall = None
    if per:
        recent_avgs = [sum(s[:3]) / len(s[:3]) for s in per.values()]
        overall = int(round(sum(recent_avgs) / len(recent_avgs)))

    trend = None
    chrono = [r["score"] for r in reversed(rows)]
    if len(chrono) >= 4:
        last3 = sum(chrono[-3:]) / 3
        prev = chrono[-6:-3] or chrono[:-3]
        diff = last3 - sum(prev) / len(prev)
        trend = "up" if diff > 5 else "down" if diff < -5 else "flat"

    if not per:
        advice = "Пройдите первый тест, чтобы получить оценку внимания."
    else:
        weakest = min(tests, key=lambda t: tests[t]["avg"])
        missing = [t for t in ("reaction", "stroop", "schulte", "memory") if t not in tests]
        if missing:
            advice = f"Попробуйте ещё и «{TEST_NAMES[missing[0]]}», так оценка будет точнее."
        else:
            advice = f"Слабее всего у вас «{TEST_NAMES[weakest]}». Потренируйте именно этот тест."
    return {
        "overall": overall,
        "level": level_of(overall) if overall is not None else None,
        "trend": trend,
        "tests": tests,
        "advice": advice,
        "streak": streak_days(rows),
        "total": len(rows),
    }


def next_difficulty(rows):
    """Адаптивная сложность по последним результатам каждого теста."""
    def recent(test):
        return [r for r in rows if r["test"] == test][:3]

    size = 4
    rs = recent("schulte")
    if rs:
        avg = sum(r["score"] for r in rs) / len(rs)
        size = int(rs[0]["metrics"].get("size", 4)) + (1 if avg >= 80 else -1 if avg < 50 else 0)
    size = int(_clamp(size, 3, 7))

    trials = 10
    rs = recent("stroop")
    if rs and sum(r["score"] for r in rs) / len(rs) >= 80:
        trials = 15

    mem = 4
    rs = recent("memory")
    if rs:
        mem = int(_clamp(int(rs[0]["metrics"].get("max_len", 4)) - 1, 3, 8))
    gn = 24
    rs = recent("gonogo")
    if rs and sum(r["score"] for r in rs) / len(rs) >= 80:
        gn = 32
    nb = 1
    rs = recent("nback")
    if rs:
        last_n = int(rs[0]["metrics"].get("n", 1))
        sc = sum(r["score"] for r in rs) / len(rs)
        nb = int(_clamp(last_n + (1 if sc >= 80 else -1 if sc < 50 else 0), 1, 3))
    sm = 3
    rs = recent("simon")
    if rs:
        sm = int(_clamp(int(rs[0]["metrics"].get("max_len", 3)) - 1, 3, 7))
    od = 3
    rs = recent("odd")
    if rs:
        sc = sum(r["score"] for r in rs) / len(rs)
        od = int(_clamp(int(rs[0]["metrics"].get("size", 3)) + (1 if sc >= 80 else -1 if sc < 50 else 0), 3, 6))
    return {"schulte_size": size, "stroop_trials": trials, "memory_start": mem, "gonogo_trials": gn,
            "nback_n": nb, "simon_start": sm, "odd_size": od}


TIPS = [
    "Работайте блоками 25 минут, затем 5 минут перерыв (метод Помодоро).",
    "Уберите телефон из поля зрения на время занятий: даже лежащий рядом он отвлекает.",
    "Сон 8-9 часов напрямую влияет на скорость реакции и устойчивость внимания.",
    "Короткая прогулка или вода перед занятием помогают сосредоточиться.",
    "Делайте одно дело за раз: переключение между задачами съедает внимание.",
]


def detect_emotion(text):
    t = (text or "").lower()
    if any(w in t for w in ("спасибо", "круто", "класс", "ура", "супер", "отлично", "здорово", "люблю")):
        return "excited"
    if any(w in t for w in ("молодец", "умница", "ты крутой", "красавчик")):
        return "shy"
    if any(w in t for w in ("привет", "здравств", "добрый", "хай")):
        return "happy"
    if any(w in t for w in ("устал", "груст", "плохо", "тяжело", "не получается", "надоел", "бесит", "скучно")):
        return "support"
    if any(w in t for w in ("спать", "сон", "сонн", "ночь", "не выспал")):
        return "sleepy"
    if any(w in t for w in ("вау", "ого", "серьезно", "серьёзно", "невероятно")) or "!!" in t:
        return "surprised"
    if any(w in t for w in ("волнуюсь", "страшно", "боюсь", "переживаю", "экзамен")):
        return "worried"
    return "neutral"


def coach_reply(text, rows, name=""):
    """Возвращает (ответ, эмоция). Эмоция управляет лицом робота."""
    t = (text or "").lower()
    s = summary(rows)
    who = f", {name}" if name else ""
    mood = detect_emotion(text)

    if mood == "excited":
        return f"Пожалуйста{who}! Мне приятно, что это помогает. Продолжим?", "excited"
    if mood == "shy":
        return "Ой, спасибо! Мне приятно, но главная заслуга ваша. Продолжим тренировку?", "shy"
    if mood == "support":
        return ("Бывает, внимание проседает у всех. Сделайте паузу на 5 минут, попейте воды, "
                "а потом пройдите один короткий тест. Я с вами."), "support"
    if mood == "worried":
        return "Понимаю, это волнительно. Дышите медленно и разбейте подготовку на короткие блоки по 25 минут.", "support"
    if mood == "sleepy":
        return "Похоже, вы не выспались. Сон 8-9 часов важнее любых тренировок. Отдохните и возвращайтесь.", "sleepy"
    if mood == "happy" and len(t) < 25:
        return f"Привет{who}! Я помогу разобраться с вашим вниманием. Спросите про результаты или тренировки.", "happy"
    if mood == "surprised":
        return "Ого! Расскажите подробнее, что случилось? Или спросите про свои результаты.", "surprised"

    if any(w in t for w in ("результат", "прогресс", "как мои", "статист", "оценк", "как дела")):
        if s["overall"] is None:
            return "Пока нет данных. Пройдите хотя бы один тест на вкладке «Тесты».", "curious"
        trend = {"up": "растёт", "down": "снижается", "flat": "стабильна", None: "пока недостаточно данных для тренда"}[s["trend"]]
        emo = "happy" if s["overall"] >= 80 else "wink" if s["overall"] >= 60 else "support"
        return (f"Общая оценка внимания: {s['overall']}/100 ({s['level']}). Динамика: {trend}. "
                f"{s['advice']}"), emo
    if any(w in t for w in ("тренир", "упражн", "что делать", "что мне", "посоветуй")):
        return s["advice"], "curious"
    if any(w in t for w in ("совет", "концентр", "внимани", "отвлека", "сосредот")):
        return TIPS[len(rows) % len(TIPS)], "happy"
    if any(w in t for w in ("серия", "стрик", "дней подряд")):
        return f"Серия тренировок: {s['streak']} дн. подряд. Занимайтесь каждый день хотя бы по 5 минут.", "excited"
    return ("Я умею: рассказать о ваших результатах, подсказать что тренировать и дать совет по "
            "концентрации. Спросите, например: «Как мои результаты?»"), "confused"


# ======================= Награды: опыт, уровни, шляпки, самоцветы, лига =======================
LEVEL_TITLES = [(1, "Новичок"), (2, "Любознайка"), (3, "Исследователь"), (5, "Следопыт"), (7, "Знаток внимания"),
                (10, "Мастер концентрации"), (13, "Легенда")]
BASIC_TESTS = {"reaction", "stroop", "schulte", "memory"}
ALL_TESTS = BASIC_TESTS
EXT_TESTS = BASIC_TESTS | {"gonogo", "nback", "simon", "odd"}
HATS = [("cap", "Бейсболка"), ("beanie", "Шапочка с помпоном"), ("party", "Праздничный колпак"),
        ("cowboy", "Ковбойская шляпа"), ("tophat", "Цилиндр"), ("wizard", "Шляпа волшебника"),
        ("grad", "Академическая шапочка"), ("pirate", "Пиратская треуголка"), ("chef", "Поварской колпак"),
        ("crown", "Золотая корона"), ("halo", "Нимб"), ("royal", "Королевская корона")]
HAT_LEVEL = {key: i + 2 for i, (key, _) in enumerate(HATS)}      # шляпка за каждый новый уровень, начиная со 2-го
LEAGUES = [(1, "Бронзовая", "#CD7F32"), (3, "Серебряная", "#B8C2D6"), (5, "Золотая", "#F5C542"),
           (7, "Сапфировая", "#4F8BFF"), (9, "Рубиновая", "#E0245E"), (11, "Алмазная", "#6FE3FF")]
SHOP = {
    "freeze": {"title": "Заморозка серии", "desc": "Спасает серию, если пропустите день", "cost": 80,
               "icon": "AC_UNIT", "emoji": "🧊", "color": "#38BDF8"},
    "boost": {"title": "Двойной опыт", "desc": "Весь опыт за сегодня ×2", "cost": 120,
              "icon": "BOLT", "emoji": "⚡", "color": "#F59E0B"},
    "egg_universal": {"title": "Универсальное яйцо", "desc": "Из него может появиться питомец любой редкости", "cost": 60,
                      "icon": "EGG", "emoji": "🥚", "color": "#A77BF5"},
}
GOALS = (30, 50, 100)


def xp_for_result(score):
    return 8 + int(score) // 3


def xp_needed(level):
    """Первый уровень ~3 дня тренировок, дальше примерно по неделе на уровень."""
    return 450 if level == 1 else int(1050 * 1.08 ** (level - 2))


def level_info(xp):
    lvl, rem = 1, int(xp)
    while rem >= xp_needed(lvl):
        rem -= xp_needed(lvl)
        lvl += 1
    title = [t for l, t in LEVEL_TITLES if lvl >= l][-1]
    return {"level": lvl, "xp": int(xp), "xp_in_level": rem, "xp_needed": xp_needed(lvl), "title": title}


def league_for(level):
    name, color = [(n, c) for l, n, c in LEAGUES if level >= l][-1]
    return {"name": name, "color": color}


def result_xp(r, boost):
    x = xp_for_result(r["score"])
    return x * 2 if r["created_at"][:10] in boost else x


def _by_day(rows):
    d = {}
    for r in rows:
        d.setdefault(r["created_at"][:10], []).append(r)
    return d


def _any(rows, test, pred):
    return any(r["test"] == test and pred(r["metrics"]) for r in rows)


ACHIEVEMENTS = [
    dict(key="first", title="Первый шаг", desc="Пройдите первый тест", icon="FLAG_ROUNDED", emoji="🚩",
         color="#10B981", fn=lambda c: len(c["rows"]) >= 1),
    dict(key="explorer", title="Исследователь", desc="Попробуйте 4 основных теста", icon="EXPLORE", emoji="🧭",
         color="#3B82F6", fn=lambda c: BASIC_TESTS <= {r["test"] for r in c["rows"]}),
    dict(key="universal", title="Универсал", desc="Попробуйте все 8 тестов", icon="AUTO_AWESOME", emoji="🌟",
         color="#8B5CF6", fn=lambda c: EXT_TESTS <= {r["test"] for r in c["rows"]}),
    dict(key="tests10", title="Десятка", desc="Пройдите 10 тестов", icon="MILITARY_TECH", emoji="🎖️",
         color="#F59E0B", fn=lambda c: len(c["rows"]) >= 10),
    dict(key="tests25", title="Четвертак", desc="Пройдите 25 тестов", icon="WORKSPACE_PREMIUM", emoji="🏅",
         color="#F97316", fn=lambda c: len(c["rows"]) >= 25),
    dict(key="tests50", title="Полтинник", desc="Пройдите 50 тестов", icon="DIAMOND", emoji="💎",
         color="#06B6D4", fn=lambda c: len(c["rows"]) >= 50),
    dict(key="streak3", title="Три дня подряд", desc="Тренируйтесь 3 дня подряд", icon="LOCAL_FIRE_DEPARTMENT",
         emoji="🔥", color="#F97316", fn=lambda c: c["streak"] >= 3),
    dict(key="streak7", title="Неделя огня", desc="Тренируйтесь 7 дней подряд", icon="WHATSHOT", emoji="🔥",
         color="#EF4444", fn=lambda c: c["streak"] >= 7),
    dict(key="ace", title="Отличник", desc="Наберите 90 баллов и больше", icon="STAR_ROUNDED", emoji="⭐",
         color="#EAB308", fn=lambda c: any(r["score"] >= 90 for r in c["rows"])),
    dict(key="perfect", title="Идеально", desc="Наберите 100 баллов", icon="EMOJI_EVENTS", emoji="🏆",
         color="#F59E0B", fn=lambda c: any(r["score"] >= 100 for r in c["rows"])),
    dict(key="lightning", title="Молния", desc="Средняя реакция быстрее 270 мс", icon="BOLT", emoji="⚡",
         color="#8B5CF6", fn=lambda c: _any(c["rows"], "reaction", lambda m: float(m.get("avg_ms", 9999)) <= 270)),
    dict(key="sniper", title="Снайпер", desc="Струп без единой ошибки (10+ заданий)", icon="TRACK_CHANGES",
         emoji="🎯", color="#10B981",
         fn=lambda c: _any(c["rows"], "stroop", lambda m: m.get("total", 0) >= 10 and m.get("correct") == m.get("total"))),
    dict(key="shulte7", title="Следопыт Шульте", desc="Пройдите таблицу 7×7 или больше", icon="GRID_VIEW", emoji="▦",
         color="#3B82F6", fn=lambda c: _any(c["rows"], "schulte", lambda m: int(m.get("size", 0)) >= 7)),
    dict(key="shulte10", title="Покоритель 10×10", desc="Пройдите таблицу 10×10", icon="ROCKET_LAUNCH", emoji="🚀",
         color="#EC4899", fn=lambda c: _any(c["rows"], "schulte", lambda m: int(m.get("size", 0)) >= 10)),
    dict(key="memory8", title="Память слона", desc="Запомните число из 8 цифр", icon="PSYCHOLOGY", emoji="🧠",
         color="#EC4899", fn=lambda c: _any(c["rows"], "memory", lambda m: int(m.get("max_len", 0)) >= 8)),
    dict(key="calm", title="Хладнокровие", desc="Светофор без нажатий на красный", icon="TRAFFIC", emoji="🚦",
         color="#22C55E",
         fn=lambda c: _any(c["rows"], "gonogo", lambda m: int(m.get("false_alarms", 1)) == 0 and int(m.get("go_total", 0)) >= 10)),
    dict(key="nback2", title="Мозг-компьютер", desc="N-назад с N=2 на 80 баллов", icon="MEMORY", emoji="🧩",
         color="#06B6D4", fn=lambda c: any(r["test"] == "nback" and int(r["metrics"].get("n", 1)) >= 2 and r["score"] >= 80
                                          for r in c["rows"])),
    dict(key="simon8", title="Музыкальная память", desc="Повторите последовательность из 8 сигналов",
         icon="MUSIC_NOTE", emoji="🎵", color="#EC4899",
         fn=lambda c: _any(c["rows"], "simon", lambda m: int(m.get("max_len", 0)) >= 8)),
    dict(key="eagle", title="Орлиный глаз", desc="Наберите 90 баллов в «Лишнем»", icon="VISIBILITY", emoji="🦅",
         color="#F59E0B", fn=lambda c: any(r["test"] == "odd" and r["score"] >= 90 for r in c["rows"])),
    dict(key="daily3", title="Тренировочный день", desc="Пройдите 3 теста за один день", icon="CALENDAR_MONTH",
         emoji="📅", color="#06B6D4", fn=lambda c: any(len(v) >= 3 for v in c["by_day"].values())),
    dict(key="allday", title="Полный комплект", desc="4 основных теста за один день", icon="VERIFIED", emoji="✅",
         color="#22C55E",
         fn=lambda c: any(BASIC_TESTS <= {r["test"] for r in v} for v in c["by_day"].values())),
]
ACH_BY_KEY = {a["key"]: a for a in ACHIEVEMENTS}


def unlocked_keys(rows, today=None, freezes=0):
    ctx = {"rows": rows, "streak": streak_days(rows, today, freezes), "by_day": _by_day(rows)}
    return [a["key"] for a in ACHIEVEMENTS if a["fn"](ctx)]


def achievement_public(key, date_str=None, unlocked=True):
    a = ACH_BY_KEY[key]
    return {"key": key, "title": a["title"], "desc": a["desc"], "icon": a["icon"], "emoji": a["emoji"],
            "color": a["color"], "unlocked": unlocked, "date": date_str}


QUEST_POOL = [
    ("reaction", "Пройдите тест «Реакция»", 20, lambda t: any(r["test"] == "reaction" for r in t)),
    ("stroop", "Пройдите тест Струпа", 20, lambda t: any(r["test"] == "stroop" for r in t)),
    ("schulte", "Пройдите таблицу Шульте", 20, lambda t: any(r["test"] == "schulte" for r in t)),
    ("memory", "Пройдите тест на память", 20, lambda t: any(r["test"] == "memory" for r in t)),
    ("gonogo", "Пройдите «Светофор»", 20, lambda t: any(r["test"] == "gonogo" for r in t)),
    ("nback", "Пройдите «N-назад»", 20, lambda t: any(r["test"] == "nback" for r in t)),
    ("simon", "Повторите за роботом", 20, lambda t: any(r["test"] == "simon" for r in t)),
    ("odd", "Найдите лишнее", 20, lambda t: any(r["test"] == "odd" for r in t)),
    ("score70", "Наберите 70 баллов и больше", 25, lambda t: any(r["score"] >= 70 for r in t)),
    ("three", "Сделайте 3 теста за день", 30, lambda t: len(t) >= 3),
    ("kinds", "Пройдите 2 разных теста", 20, lambda t: len({r["test"] for r in t}) >= 2),
]


def daily_quests(rows, day=None):
    day = day or date.today()
    picks = random.Random(day.toordinal()).sample(QUEST_POOL, 3)
    today_rows = [r for r in rows if r["created_at"][:10] == day.isoformat()]
    return [{"key": k, "title": t, "xp": x, "done": bool(fn(today_rows))} for k, t, x, fn in picks]


def progress(rows, stored=None, today=None, freezes=0, boosts=(), spent=0, goal=50):
    """Весь «игровой» прогресс ученика. stored — {ключ: дата} полученных наград, boosts — даты двойного опыта."""
    today = today or date.today()
    stored = stored or {}
    boost = set(boosts)
    xp, quests_done = 0, 0
    xp += sum(result_xp(r, boost) for r in rows)
    for day in _by_day(rows):
        done = [q for q in daily_quests(rows, date.fromisoformat(day)) if q["done"]]
        xp += sum(q["xp"] for q in done)
        quests_done += len(done)
    keys = set(unlocked_keys(rows, today, freezes)) | set(stored)
    xp += 15 * len(keys)
    info = level_info(xp)
    lvl = info["level"]
    gems = len(rows) + 10 * quests_done + 25 * (lvl - 1) + 10 * len(keys) - int(spent)
    streak, used = streak_info(rows, today, freezes)
    today_rows = [r for r in rows if r["created_at"][:10] == today.isoformat()]
    quests = daily_quests(rows, today)
    today_xp = sum(result_xp(r, boost) for r in today_rows) + sum(q["xp"] for q in quests if q["done"])
    ach = [achievement_public(a["key"], stored.get(a["key"]), a["key"] in keys) for a in ACHIEVEMENTS]
    hats = [{"key": k, "name": n, "level": HAT_LEVEL[k], "unlocked": lvl >= HAT_LEVEL[k]} for k, n in HATS]
    info.update({"achievements": ach, "unlocked": len(keys), "total": len(ACHIEVEMENTS), "quests": quests,
                 "today": len(today_rows), "goal": 3, "goal_xp": int(goal), "today_xp": int(today_xp),
                 "streak": streak, "freezes_left": max(0, int(freezes) - used), "gems": max(0, gems),
                 "boost_today": today.isoformat() in boost, "hats": hats, "league": league_for(lvl)})
    return info


def weekly_xp(rows, boosts=(), today=None):
    """Опыт за текущую неделю (с понедельника) для рейтинга."""
    today = today or date.today()
    monday = today.toordinal() - today.weekday()
    boost = set(boosts)
    return sum(result_xp(r, boost) for r in rows if date.fromisoformat(r["created_at"][:10]).toordinal() >= monday)
