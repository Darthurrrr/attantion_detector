import csv
import io
import json
import os
import smtplib
import sqlite3
from email.message import EmailMessage
from contextlib import closing
from datetime import datetime

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse, Response
from pydantic import BaseModel

import ai
import logic

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "attention_v2.db")
app = FastAPI(title="Детектор внимания API")
# Единственное отличие от версии для Flet: CORS, нужен только если Flutter запускается как веб-приложение.
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with closing(get_db()) as c:
        c.execute(
            """CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                age INTEGER,
                created_at TEXT NOT NULL)"""
        )
        for col in ("age INTEGER", "hat TEXT", "goal INTEGER DEFAULT 50"):  # база от прошлых версий
            try:
                c.execute(f"ALTER TABLE users ADD COLUMN {col}")
            except sqlite3.OperationalError:
                pass
        c.execute(
            """CREATE TABLE IF NOT EXISTS purchases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                item TEXT NOT NULL,
                day TEXT NOT NULL,
                created_at TEXT NOT NULL)"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS achievements (
                user_id INTEGER NOT NULL,
                key TEXT NOT NULL,
                unlocked_at TEXT NOT NULL,
                PRIMARY KEY (user_id, key))"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS support_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                name TEXT,
                contact TEXT,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL,
                emailed INTEGER NOT NULL DEFAULT 0)"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                test TEXT NOT NULL,
                score INTEGER NOT NULL,
                level TEXT NOT NULL,
                metrics TEXT NOT NULL,
                created_at TEXT NOT NULL)"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS path_progress (
                user_id INTEGER PRIMARY KEY,
                level INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL)"""
        )
        # Сохраняем уже накопленные балансы при переходе с 3 кристаллов за тест на 1.
        # Таблица заполняется ровно один раз для существующих пользователей.
        c.execute(
            """CREATE TABLE IF NOT EXISTS gem_adjustments (
                user_id INTEGER PRIMARY KEY,
                amount INTEGER NOT NULL DEFAULT 0)"""
        )
        c.execute(
            """INSERT OR IGNORE INTO gem_adjustments (user_id, amount)
               SELECT user_id, COUNT(*) * 2 FROM results GROUP BY user_id"""
        )
        c.commit()


init_db()


def now():
    return datetime.now().isoformat(timespec="seconds")


def get_user(user_id):
    with closing(get_db()) as c:
        row = c.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Ученик не найден")
    return {"id": row["id"], "name": row["name"], "age": row["age"], "hat": row["hat"] or "",
            "goal": row["goal"] or 50}


def extras(user_id):
    """Покупки и настройки ученика: заморозки серии, дни двойного опыта, потраченные самоцветы."""
    with closing(get_db()) as c:
        rows = c.execute("SELECT item, day FROM purchases WHERE user_id=?", (user_id,)).fetchall()
    freezes = sum(1 for r in rows if r["item"] == "freeze")
    boosts = [r["day"] for r in rows if r["item"] == "boost"]
    spent = sum(logic.SHOP[r["item"]]["cost"] for r in rows if r["item"] in logic.SHOP)
    dev_gems = sum(int(r["item"].split(":", 1)[1]) for r in rows
                   if str(r["item"]).startswith("dev_gems:"))
    return freezes, boosts, spent, dev_gems


def fetch_rows(user_id, limit=None):
    sql = "SELECT * FROM results WHERE user_id=? ORDER BY id DESC"
    if limit:
        sql += f" LIMIT {int(limit)}"
    with closing(get_db()) as c:
        rows = c.execute(sql, (user_id,)).fetchall()
    return [
        {
            "id": r["id"],
            "test": r["test"],
            "score": r["score"],
            "level": r["level"],
            "metrics": json.loads(r["metrics"]),
            "created_at": r["created_at"],
        }
        for r in rows
    ]


def stored_awards(user_id):
    with closing(get_db()) as c:
        rows = c.execute("SELECT key, unlocked_at FROM achievements WHERE user_id=?", (user_id,)).fetchall()
    return {r["key"]: r["unlocked_at"][:10] for r in rows}


def progress_for(user_id, rows=None):
    rows = fetch_rows(user_id) if rows is None else rows
    freezes, boosts, spent, dev_gems = extras(user_id)
    goal = get_user(user_id)["goal"]
    result = logic.progress(rows, stored_awards(user_id), None, freezes, boosts, spent, goal)
    with closing(get_db()) as c:
        row = c.execute("SELECT amount FROM gem_adjustments WHERE user_id=?", (user_id,)).fetchone()
    legacy_adjustment = int(row["amount"]) if row else 0
    result["gems"] += dev_gems + legacy_adjustment
    result["dev_gems"] = dev_gems
    return result


class UserIn(BaseModel):
    name: str
    age: int | None = None


class AgeIn(BaseModel):
    age: int


class SupportIn(BaseModel):
    user_id: int | None = None
    name: str = ""
    contact: str = ""
    message: str


class ResultIn(BaseModel):
    user_id: int
    test: str
    metrics: dict


class PathProgressIn(BaseModel):
    user_id: int
    level: int


class ChatIn(BaseModel):
    user_id: int
    text: str


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/path-progress")
def get_path_progress(user_id: int):
    get_user(user_id)
    with closing(get_db()) as c:
        row = c.execute("SELECT level FROM path_progress WHERE user_id=?", (user_id,)).fetchone()
    return {"user_id": user_id, "level": int(row["level"]) if row else 0}


@app.put("/api/path-progress")
def save_path_progress(item: PathProgressIn):
    get_user(item.user_id)
    level = max(0, min(10000, int(item.level)))
    with closing(get_db()) as c:
        c.execute(
            """INSERT INTO path_progress (user_id, level, updated_at) VALUES (?,?,?)
               ON CONFLICT(user_id) DO UPDATE SET
               level=MAX(path_progress.level, excluded.level), updated_at=excluded.updated_at""",
            (item.user_id, level, now()),
        )
        c.commit()
        row = c.execute("SELECT level FROM path_progress WHERE user_id=?", (item.user_id,)).fetchone()
    return {"user_id": item.user_id, "level": int(row["level"])}


def check_age(age):
    if age is not None and not (5 <= int(age) <= 99):
        raise HTTPException(status_code=400, detail="Возраст должен быть от 5 до 99 лет")


@app.get("/api/users")
def list_users():
    with closing(get_db()) as c:
        users = c.execute("SELECT * FROM users ORDER BY name").fetchall()
    out = []
    for u in users:
        s = logic.summary(fetch_rows(u["id"]))
        pr = progress_for(u["id"])
        out.append({"id": u["id"], "name": u["name"], "age": u["age"], "overall": s["overall"],
                    "total": s["total"], "streak": s["streak"], "hat": u["hat"] or "", "level": pr["level"]})
    return out


@app.post("/api/users")
def create_user(item: UserIn):
    name = item.name.strip()[:30]
    if not name:
        raise HTTPException(status_code=400, detail="Введите имя")
    check_age(item.age)
    with closing(get_db()) as c:
        row = c.execute("SELECT * FROM users WHERE name=?", (name,)).fetchone()
        if row is None:
            cur = c.execute("INSERT INTO users (name, age, created_at) VALUES (?,?,?)", (name, item.age, now()))
            c.commit()
            return {"id": cur.lastrowid, "name": name, "age": item.age, "hat": "", "goal": 50}
        if item.age is not None:
            c.execute("UPDATE users SET age=? WHERE id=?", (item.age, row["id"]))
            c.commit()
            return {"id": row["id"], "name": row["name"], "age": item.age, "hat": row["hat"] or "",
                    "goal": row["goal"] or 50}
    return {"id": row["id"], "name": row["name"], "age": row["age"], "hat": row["hat"] or "", "goal": row["goal"] or 50}


@app.put("/api/users/{user_id}/age")
def set_age(user_id: int, item: AgeIn):
    get_user(user_id)
    check_age(item.age)
    with closing(get_db()) as c:
        c.execute("UPDATE users SET age=? WHERE id=?", (item.age, user_id))
        c.commit()
    return {"id": user_id, "age": item.age}


@app.post("/api/results")
def add_result(item: ResultIn):
    user = get_user(item.user_id)
    try:
        score = logic.score_result(item.test, item.metrics, user["age"])
        rec = logic.recommendation(item.test, score, item.metrics)
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=400, detail=f"Некорректные данные: {e}")
    level = logic.level_of(score)
    before = progress_for(item.user_id)
    with closing(get_db()) as c:
        c.execute(
            "INSERT INTO results (user_id, test, score, level, metrics, created_at) VALUES (?,?,?,?,?,?)",
            (item.user_id, item.test, score, level, json.dumps(item.metrics), now()),
        )
        c.commit()
    rows = fetch_rows(item.user_id)
    stored = stored_awards(item.user_id)
    new_keys = [k for k in logic.unlocked_keys(rows) if k not in stored]
    if new_keys:
        with closing(get_db()) as c:
            for k in new_keys:
                c.execute("INSERT OR IGNORE INTO achievements (user_id, key, unlocked_at) VALUES (?,?,?)",
                          (item.user_id, k, now()))
            c.commit()
    after = progress_for(item.user_id, rows)
    new_hats = [h for h, b in zip(after["hats"], before["hats"]) if h["unlocked"] and not b["unlocked"]]
    return {"score": score, "level": level, "recommendation": rec,
            "xp_gain": after["xp"] - before["xp"], "level_up": after["level"] > before["level"],
            "gems_gain": after["gems"] - before["gems"], "new_hats": new_hats, "streak": after["streak"],
            "lvl": {k: after[k] for k in ("level", "title", "xp_in_level", "xp_needed")},
            "new_achievements": [logic.achievement_public(k, now()[:10]) for k in new_keys]}


@app.get("/api/history")
def history(user_id: int, limit: int = 30):
    return fetch_rows(user_id, limit)


@app.delete("/api/history")
def clear_history(user_id: int):
    with closing(get_db()) as c:
        c.execute("DELETE FROM results WHERE user_id=?", (user_id,))
        c.commit()
    return {"status": "cleared"}


@app.get("/api/summary")
def get_summary(user_id: int):
    rows = fetch_rows(user_id)
    out = logic.summary(rows)
    out["progress"] = progress_for(user_id, rows)
    return out


@app.get("/api/progress")
def get_progress(user_id: int):
    return progress_for(user_id)


ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
_MEDIA = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}


@app.get("/assets/{path:path}")
def get_asset(path: str):
    """Раздаёт картинки интерфейса. Приложение берёт их по адресу, поэтому Flutter кеширует их и не перекодирует."""
    full = os.path.normpath(os.path.join(ASSETS_DIR, path))
    if not full.startswith(ASSETS_DIR + os.sep) or not os.path.isfile(full):
        raise HTTPException(status_code=404, detail="Нет такого файла")
    with open(full, "rb") as f:
        data = f.read()
    media = _MEDIA.get(os.path.splitext(full)[1].lower(), "application/octet-stream")
    return Response(content=data, media_type=media, headers={"Cache-Control": "public, max-age=86400"})


@app.get("/api/difficulty")
def get_difficulty(user_id: int):
    return logic.next_difficulty(fetch_rows(user_id))


@app.post("/api/chat")
def chat(item: ChatIn):
    user = get_user(item.user_id)
    rows = fetch_rows(item.user_id)
    reply = None
    try:
        reply = ai.external_reply(item.text, rows, user["name"], user["age"])
    except Exception:
        reply = None  # внешний ИИ недоступен: откатываемся на правила
    if reply is None:
        reply = logic.coach_reply(item.text, rows, user["name"])
    return {"response": reply[0], "emotion": reply[1]}


@app.get("/api/export")
def export(user_id: int):
    get_user(user_id)
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["id", "тест", "балл", "уровень", "дата", "метрики"])
    for r in reversed(fetch_rows(user_id)):
        w.writerow([r["id"], logic.TEST_NAMES.get(r["test"], r["test"]), r["score"], r["level"],
                    r["created_at"], json.dumps(r["metrics"], ensure_ascii=False)])
    return PlainTextResponse(buf.getvalue(), media_type="text/csv; charset=utf-8")


# ---------------- Поддержка ----------------
SUPPORT_TO = os.getenv("SUPPORT_TO", "ggkek09@gmail.com")


def send_support_email(msg_id, name, contact, message):
    """Отправляет письмо, если заданы SMTP_HOST, SMTP_USER и SMTP_PASS (иначе сообщение остаётся в базе)."""
    host, user, password = os.getenv("SMTP_HOST"), os.getenv("SMTP_USER"), os.getenv("SMTP_PASS")
    if not (host and user and password):
        return
    try:
        mail = EmailMessage()
        mail["Subject"] = f"Детектор внимания: обращение №{msg_id} от {name or 'ученика'}"
        mail["From"] = user
        mail["To"] = SUPPORT_TO
        mail.set_content(f"Имя: {name}\nКонтакт: {contact}\n\n{message}")
        with smtplib.SMTP(host, int(os.getenv("SMTP_PORT", "587")), timeout=15) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(mail)
        with closing(get_db()) as c:
            c.execute("UPDATE support_messages SET emailed=1 WHERE id=?", (msg_id,))
            c.commit()
    except Exception as e:  # письмо не ушло: сообщение всё равно сохранено в базе
        print("[support] письмо не отправлено:", e)


@app.post("/api/support")
def support(item: SupportIn, tasks: BackgroundTasks):
    message = item.message.strip()
    if len(message) < 5:
        raise HTTPException(status_code=400, detail="Опишите вопрос чуть подробнее (минимум 5 символов)")
    message = message[:3000]
    with closing(get_db()) as c:
        cur = c.execute(
            "INSERT INTO support_messages (user_id, name, contact, message, created_at) VALUES (?,?,?,?,?)",
            (item.user_id, item.name.strip()[:60], item.contact.strip()[:120], message, now()),
        )
        c.commit()
        msg_id = cur.lastrowid
    configured = bool(os.getenv("SMTP_HOST") and os.getenv("SMTP_USER") and os.getenv("SMTP_PASS"))
    if configured:
        tasks.add_task(send_support_email, msg_id, item.name.strip(), item.contact.strip(), message)
    return {"status": "saved", "id": msg_id, "email": "queued" if configured else "not_configured"}


@app.get("/api/support")
def support_list(request: Request):
    """Список обращений. Доступен только с этого же компьютера."""
    if request.client is None or request.client.host not in ("127.0.0.1", "::1", "localhost"):
        raise HTTPException(status_code=403, detail="Только с локального компьютера")
    with closing(get_db()) as c:
        rows = c.execute("SELECT * FROM support_messages ORDER BY id DESC LIMIT 200").fetchall()
    return [dict(r) for r in rows]


# ---------------- Шляпки, цель дня, магазин, рейтинг ----------------
class HatIn(BaseModel):
    hat: str = ""


class GoalIn(BaseModel):
    goal: int


class BuyIn(BaseModel):
    user_id: int
    item: str


@app.put("/api/users/{user_id}/hat")
def set_hat(user_id: int, item: HatIn):
    get_user(user_id)
    hat = item.hat.strip()
    if hat:
        if hat not in logic.HAT_LEVEL:
            raise HTTPException(status_code=400, detail="Нет такой шляпки")
        if progress_for(user_id)["level"] < logic.HAT_LEVEL[hat]:
            raise HTTPException(status_code=403, detail=f"Шляпка откроется на {logic.HAT_LEVEL[hat]} уровне")
    with closing(get_db()) as c:
        c.execute("UPDATE users SET hat=? WHERE id=?", (hat, user_id))
        c.commit()
    return {"id": user_id, "hat": hat}


@app.put("/api/users/{user_id}/goal")
def set_goal(user_id: int, item: GoalIn):
    get_user(user_id)
    if item.goal not in logic.GOALS:
        raise HTTPException(status_code=400, detail="Выберите цель: 30, 50 или 100 XP")
    with closing(get_db()) as c:
        c.execute("UPDATE users SET goal=? WHERE id=?", (item.goal, user_id))
        c.commit()
    return {"id": user_id, "goal": item.goal}


@app.get("/api/shop")
def shop():
    return [{"key": k, **v} for k, v in logic.SHOP.items()]


@app.post("/api/shop/buy")
def shop_buy(item: BuyIn):
    get_user(item.user_id)
    if item.item not in logic.SHOP:
        raise HTTPException(status_code=400, detail="Нет такого товара")
    pr = progress_for(item.user_id)
    cost = logic.SHOP[item.item]["cost"]
    if pr["gems"] < cost:
        raise HTTPException(status_code=400, detail=f"Не хватает самоцветов: нужно {cost}, у вас {pr['gems']}")
    if item.item == "freeze" and pr["freezes_left"] >= 3:
        raise HTTPException(status_code=400, detail="Можно хранить не больше 3 заморозок")
    if item.item == "boost" and pr["boost_today"]:
        raise HTTPException(status_code=400, detail="Двойной опыт на сегодня уже включён")
    with closing(get_db()) as c:
        c.execute("INSERT INTO purchases (user_id, item, day, created_at) VALUES (?,?,?,?)",
                  (item.user_id, item.item, now()[:10], now()))
        c.commit()
    return {"ok": True, "progress": progress_for(item.user_id)}


class DevGrantIn(BaseModel):
    user_id: int
    amount: int = 10000


@app.post("/api/dev/grant-gems")
def dev_grant_gems(item: DevGrantIn):
    # Только для локального тестирования. Не публикуйте backend с этим endpoint в интернете.
    get_user(item.user_id)
    amount = max(0, min(1_000_000, int(item.amount)))
    with closing(get_db()) as c:
        c.execute("INSERT INTO purchases (user_id, item, day, created_at) VALUES (?,?,?,?)",
                  (item.user_id, f"dev_gems:{amount}", now()[:10], now()))
        c.commit()
    return {"ok": True, "progress": progress_for(item.user_id)}


@app.get("/api/leaderboard")
def leaderboard(user_id: int, period: str = "week"):
    """Рейтинг учеников: по опыту за неделю или за всё время. Лига зависит от уровня."""
    with closing(get_db()) as c:
        users = c.execute("SELECT * FROM users").fetchall()
    entries = []
    for u in users:
        rows = fetch_rows(u["id"])
        freezes, boosts, spent, dev_gems = extras(u["id"])
        pr = logic.progress(rows, stored_awards(u["id"]), None, freezes, boosts, spent, u["goal"] or 50)
        entries.append({"id": u["id"], "name": u["name"], "hat": u["hat"] or "", "level": pr["level"],
                        "title": pr["title"], "league": pr["league"], "streak": pr["streak"],
                        "weekly_xp": logic.weekly_xp(rows, boosts), "total_xp": pr["xp"]})
    key = "weekly_xp" if period == "week" else "total_xp"
    entries.sort(key=lambda e: (-e[key], e["name"]))
    for i, e in enumerate(entries):
        e["rank"] = i + 1
        e["xp"] = e[key]
    from datetime import datetime as _dt, timedelta as _td
    nxt = (_dt.now() + _td(days=7 - _dt.now().weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    me = next((e["rank"] for e in entries if e["id"] == user_id), None)
    return {"period": period, "entries": entries, "me": me,
            "week_ends_in_hours": max(0, int((nxt - _dt.now()).total_seconds() // 3600))}
