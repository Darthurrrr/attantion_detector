@echo off
cd /d %~dp0
rem Чтобы сообщения из раздела «Поддержка» приходили на почту, уберите rem и заполните:
rem set SMTP_HOST=smtp.gmail.com
rem set SMTP_USER=ваш_адрес@gmail.com
rem set SMTP_PASS=пароль_приложения_google
rem set SUPPORT_TO=ваш_адрес@gmail.com
uvicorn backend:app --host 0.0.0.0 --port 8000
