@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 goto no_python
if not exist "backend\.venv\Scripts\python.exe" (
  echo Creating Python virtual environment...
  python -m venv "backend\.venv"
  if errorlevel 1 goto failed
)
echo Installing backend packages...
"%~dp0backend\.venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r "%~dp0backend\requirements.txt"
if errorlevel 1 goto failed
cd /d "%~dp0backend"
echo Starting API at http://127.0.0.1:8000 ...
"%~dp0backend\.venv\Scripts\python.exe" -m uvicorn backend:app --host 127.0.0.1 --port 8000
set "RUN_RESULT=%ERRORLEVEL%"
echo Backend exited with code %RUN_RESULT%.
pause
exit /b %RUN_RESULT%
:no_python
echo ERROR: Python was not found in PATH. Install Python 3.11 or newer.
pause
exit /b 1
:failed
echo Backend startup failed. Read the error messages above.
pause
exit /b 1
