@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call :find_flutter
if not defined FLUTTER_BAT goto no_flutter
if not exist "pubspec.yaml" goto no_project
if not exist "web\index.html" (
  echo Creating Flutter Web platform files...
  call "%FLUTTER_BAT%" create --platforms=web --project-name attention_detector .
  if errorlevel 1 goto failed
)
echo Resolving Flutter packages...
call "%FLUTTER_BAT%" pub get
if errorlevel 1 goto failed
echo Starting Flutter Web server on http://127.0.0.1:53919
echo.
echo The launcher will open Microsoft Edge after the server is ready.
echo If you started this file directly, open http://127.0.0.1:53919 manually.
echo.
call "%FLUTTER_BAT%" run -d web-server --web-hostname 127.0.0.1 --web-port=53919 --dart-define=API_BASE=http://127.0.0.1:8000
set "RUN_RESULT=%ERRORLEVEL%"
echo Flutter Web server exited with code %RUN_RESULT%.
pause
exit /b %RUN_RESULT%
:no_flutter
echo ERROR: Flutter SDK was not found.
pause
exit /b 1
:no_project
echo ERROR: pubspec.yaml was not found. Run this file from the project folder.
pause
exit /b 1
:failed
echo.
echo Flutter Web startup failed. Read the error messages above.
pause
exit /b 1
:find_flutter
set "FLUTTER_BAT="
if exist "%USERPROFILE%\gbgb\flutter\bin\flutter.bat" set "FLUTTER_BAT=%USERPROFILE%\gbgb\flutter\bin\flutter.bat"
if not defined FLUTTER_BAT if defined FLUTTER_ROOT if exist "%FLUTTER_ROOT%\bin\flutter.bat" set "FLUTTER_BAT=%FLUTTER_ROOT%\bin\flutter.bat"
if not defined FLUTTER_BAT for /f "delims=" %%F in ('where flutter.bat 2^>nul') do if not defined FLUTTER_BAT set "FLUTTER_BAT=%%F"
if defined FLUTTER_BAT for %%F in ("%FLUTTER_BAT%") do set "PATH=%%~dpF;%PATH%"
exit /b 0
