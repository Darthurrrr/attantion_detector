# Visual and interaction update

## Home
- Restored the illustrated quick-action buttons as two side rails around the pet: shop, tasks, friends, daily series, pets, and event.
- Added a compact warm streak badge next to the level progress and gem wallet.
- The pet no longer navigates away on touch. A tap plays a soft boop and triggers a small vertical squash/bounce; a swipe across the pet triggers a gentle purr and floating hearts.
- Tasks and daily-series buttons show the current progress returned by the backend. Friends and events remain marked as upcoming because the current backend has no corresponding endpoints.

## Adventure map
- Removed all visual level badges, lock circles, and stage labels that sat over the original crystal illustrations.
- The crystal art itself is the invisible tap target.
- Completed crystals receive a fracture overlay and a three-star rating beneath the pedestal; the rating remains saved per user and is not placed over the crystal.

## Shared screen environment
- Added a new illustrated fantasy landscape as the shared backdrop for statistics, tests, shop, profile, collection, awards, and other pages that use `SkyBackground`.
- Added a cloud footer layer and soft tint to keep translucent cards readable.
- The existing splash, welcome, and egg screens retain their own illustrated backgrounds.

## Sounds
- Added two original soft sound effects: `pet_tap.wav` and `pet_cuddle.wav`.
- Existing tap, transition, success, and crystal-reward sounds are preserved.
