# Visual revision notes

## Changes in this revision
- Removed the duplicate quick-action strip and duplicate green CTA from the portrait home screen; the bottom Play control is the single primary action.
- Desktop home is simplified to one pet-world scene, HUD, and one CTA rather than a stack of repeated action tiles.
- Map stage controls no longer cover the crystals. Status labels are rendered underneath each crystal/pedestal.
- Completed first-world crystals receive a light fracture overlay, with a persistent 1–3 star rating beneath them.
- Star ratings are saved in SharedPreferences per user. Stage score rating: 85+ = 3 stars, 65–84 = 2 stars, below 65 = 1 star.
- Result screen is centered at a maximum width of 660 px, uses a compact game-like result banner, stars, reward, trainer hint, XP, achievements and responsive actions.
- Shared page content max width reduced from 1120 to 960 px and glass surfaces made less stark.

## Verification
Source files and asset paths were inspected. The execution environment does not include Flutter/Dart SDK, so `flutter analyze`, browser rendering, and APK compilation were not run here.
