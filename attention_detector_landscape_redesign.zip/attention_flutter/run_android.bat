@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo   DETECTOR VNIMANIYA - ANDROID
 echo ==========================================

where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter SDK не найден. Установите Flutter и добавьте папку bin в PATH.
  pause
  exit /b 1
)

if not exist "android\app\src\main\AndroidManifest.xml" (
  echo Создаю Android-платформу Flutter...
  flutter create --platforms=android --project-name attention_detector .
  if errorlevel 1 goto error
)

where py >nul 2>nul
if not errorlevel 1 (
  py -3 scripts\prepare_android.py
) else (
  python scripts\prepare_android.py
)
if errorlevel 1 goto error

flutter pub get
if errorlevel 1 goto error

echo.
echo Запускаю приложение.
echo Для эмулятора API по умолчанию: http://10.0.2.2:8000
if defined API_BASE (
  echo Используется API_BASE=%API_BASE%
  flutter run --dart-define=API_BASE=%API_BASE%
) else (
  flutter run
)
if errorlevel 1 goto error
exit /b 0

:error
echo.
echo Не удалось запустить приложение. Скопируйте текст ошибки из этого окна.
pause
exit /b 1
