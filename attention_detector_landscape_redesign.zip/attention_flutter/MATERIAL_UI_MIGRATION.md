# Миграция Material UI

В проекте заменён устаревший импорт Flutter Material:

- Было: `package:flutter/material.dart`
- Стало: `package:material_ui/material_ui.dart`

Добавлена зависимость `material_ui: ^1.11.1` в `pubspec.yaml`.

После распаковки проекта выполните в корневой папке:

```bash
flutter pub get
flutter analyze
```

Это обновляет зависимости и позволяет проверить оставшиеся предупреждения анализатора. Для этой миграции не требуется менять код виджетов: библиотека Material вынесена в отдельный официальный пакет.
