"""Prepare a Flutter-generated Android manifest for local HTTP development."""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "android" / "app" / "src" / "main" / "AndroidManifest.xml"


def main() -> int:
    if not MANIFEST.is_file():
        print(f"Не найден {MANIFEST}. Сначала выполните flutter create --platforms=android .")
        return 1

    source = MANIFEST.read_text(encoding="utf-8")

    permission = 'android.permission.INTERNET'
    if permission not in source:
        source, count = re.subn(
            r"(<manifest\b[^>]*>)",
            r'\1\n    <uses-permission android:name="android.permission.INTERNET" />',
            source,
            count=1,
        )
        if count != 1:
            print("Не удалось найти тег <manifest> в AndroidManifest.xml")
            return 1

    app_match = re.search(r"<application\b[^>]*>", source)
    if app_match is None:
        print("Не удалось найти открывающий тег <application>")
        return 1

    app_tag = app_match.group(0)
    if "android:usesCleartextTraffic" not in app_tag:
        new_tag = app_tag[:-1] + ' android:usesCleartextTraffic="true">'
        source = source[: app_match.start()] + new_tag + source[app_match.end() :]
    else:
        source = re.sub(
            r'android:usesCleartextTraffic="[^"]*"',
            'android:usesCleartextTraffic="true"',
            source,
            count=1,
        )

    MANIFEST.write_text(source, encoding="utf-8")
    print("AndroidManifest.xml: INTERNET permission и локальный HTTP включены для разработки.")
    print("Для публикации приложения используйте HTTPS и отключите cleartext traffic.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
