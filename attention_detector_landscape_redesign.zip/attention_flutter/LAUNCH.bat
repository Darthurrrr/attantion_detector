@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call :find_flutter
:menu
cls
echo ======================================================
echo             ATTENTION DETECTOR - LAUNCHER
echo ======================================================
echo.
echo  1. Start backend and app in Microsoft Edge
echo  2. Start backend only
echo  3. Start app web server only
echo  4. Run on Android device or emulator
echo  5. Run Flutter analyzer
echo  6. Open project in VS Code
echo  7. Open project folder
echo  0. Exit
echo.
set "CHOICE="
set /p "CHOICE=Select an option: "
if "%CHOICE%"=="1" goto all
if "%CHOICE%"=="2" goto backend
if "%CHOICE%"=="3" goto web
if "%CHOICE%"=="4" goto android
if "%CHOICE%"=="5" goto analyze
if "%CHOICE%"=="6" goto code
if "%CHOICE%"=="7" goto folder
if "%CHOICE%"=="0" goto finish
goto menu
:all
if not defined FLUTTER_BAT goto no_flutter
where python >nul 2>nul
if errorlevel 1 goto no_python
start "Attention Detector API" "%ComSpec%" /d /k call "%~dp0start_backend.bat"
echo Waiting for the API to respond...
for /l %%i in (1,1,45) do (
  curl.exe --silent --fail http://127.0.0.1:8000/api/health >nul 2>nul
  if not errorlevel 1 goto api_ready
  timeout /t 1 /nobreak >nul
)
echo WARNING: API did not respond in 45 seconds. Starting the web app anyway.
:api_ready
call :start_web_server
goto menu
:backend
start "Attention Detector API" "%ComSpec%" /d /k call "%~dp0start_backend.bat"
goto menu
:web
if not defined FLUTTER_BAT goto no_flutter
call :start_web_server
goto menu
:start_web_server
if not defined FLUTTER_BAT goto no_flutter
start "Attention Detector Web Server" "%ComSpec%" /d /k call "%~dp0start_edge.bat"
echo Waiting for Flutter Web server...
for /l %%i in (1,1,120) do (
  curl.exe --silent --fail http://127.0.0.1:53919/ >nul 2>nul
  if not errorlevel 1 goto web_ready
  timeout /t 1 /nobreak >nul
)
echo WARNING: Web server did not respond in 120 seconds.
echo Check the Attention Detector Web Server window for the error.
pause
exit /b 1
:web_ready
echo Flutter Web is ready. Opening Microsoft Edge...
call :open_edge
exit /b 0
:open_edge
set "EDGE_EXE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined EDGE_EXE if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if defined EDGE_EXE (
  start "" "%EDGE_EXE%" http://127.0.0.1:53919
) else (
  start "" http://127.0.0.1:53919
)
exit /b 0
:android
if not defined FLUTTER_BAT goto no_flutter
call "%FLUTTER_BAT%" pub get
if errorlevel 1 goto command_failed
call "%FLUTTER_BAT%" devices
call "%FLUTTER_BAT%" run --dart-define=API_BASE=http://127.0.0.1:8000
pause
goto menu
:analyze
if not defined FLUTTER_BAT goto no_flutter
call "%FLUTTER_BAT%" pub get
if errorlevel 1 goto command_failed
call "%FLUTTER_BAT%" analyze
pause
goto menu
:code
where code >nul 2>nul
if errorlevel 1 (echo VS Code command was not found. Open the folder manually.& pause & goto menu)
start "" code "%~dp0"
goto menu
:folder
start "" explorer "%~dp0"
goto menu
:find_flutter
set "FLUTTER_BAT="
if exist "%USERPROFILE%\gbgb\flutter\bin\flutter.bat" set "FLUTTER_BAT=%USERPROFILE%\gbgb\flutter\bin\flutter.bat"
if not defined FLUTTER_BAT if defined FLUTTER_ROOT if exist "%FLUTTER_ROOT%\bin\flutter.bat" set "FLUTTER_BAT=%FLUTTER_ROOT%\bin\flutter.bat"
if not defined FLUTTER_BAT for /f "delims=" %%F in ('where flutter.bat 2^>nul') do if not defined FLUTTER_BAT set "FLUTTER_BAT=%%F"
if defined FLUTTER_BAT for %%F in ("%FLUTTER_BAT%") do set "PATH=%%~dpF;%PATH%"
exit /b 0
:no_flutter
echo ERROR: Flutter SDK was not found. Expected %USERPROFILE%\gbgb\flutter\bin\flutter.bat
pause
goto menu
:no_python
echo ERROR: Python was not found in PATH.
pause
goto menu
:command_failed
echo Flutter command failed. Read the error output above.
pause
goto menu
:finish
exit /b 0
