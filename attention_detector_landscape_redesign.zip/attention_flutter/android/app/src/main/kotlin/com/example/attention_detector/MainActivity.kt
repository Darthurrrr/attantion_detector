package com.example.attention_detector

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
