import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';
import '../core/models.dart';
import '../core/game_sounds.dart';

class C {
  static const ink = Color(0xFF34205F);
  static const muted = Color(0xFF8576A9);
  static const sky = Color(0xFFEDE4FF);
  static const green = Color(0xFF58CC02);
  static const gold = Color(0xFFFFC84A);
  static const bad = Color(0xFFE5484D);
  static const good = Color(0xFF2FA866);
}

Color alpha(Color c, double a) => c.withAlpha((a * 255).round().clamp(0, 255).toInt());

final GlobalKey<ScaffoldMessengerState> messengerKey = GlobalKey<ScaffoldMessengerState>();

void toast(String emoji, String title, String text) {
  final m = messengerKey.currentState;
  if (m == null) return;
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(
    behavior: SnackBarBehavior.floating,
    backgroundColor: Colors.white,
    elevation: 6,
    margin: const EdgeInsets.fromLTRB(16, 0, 16, 24),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    duration: const Duration(seconds: 3),
    content: Row(children: [
      Text(emoji, style: const TextStyle(fontSize: 26)),
      const SizedBox(width: 12),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(title, style: const TextStyle(color: C.ink, fontWeight: FontWeight.w800, fontSize: 14)),
          if (text.isNotEmpty) Text(text, style: const TextStyle(color: C.muted, fontSize: 12)),
        ]),
      ),
    ]),
  ));
}

void toastSoon(String feature) =>
    toast('ℹ️', 'Скоро!', '$feature: эта функция пока недоступна. Мы работаем над ней.');

/// Единое небесное окружение для всех разделов игры.
class SkyBackground extends StatelessWidget {
  final Widget child;
  const SkyBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFD7C5FF), Color(0xFFF0E8FF), Color(0xFFFFF3E2)],
            ),
          ),
        ),
        // Общий мир приложения: теперь статистика, магазин, профиль и результаты
        // находятся в том же фантазийном окружении, что главная и карта.
        Positioned.fill(
          child: Opacity(
            opacity: .72,
            child: Image.asset(
              'assets/backgrounds/world_pages.png',
              fit: BoxFit.cover,
              alignment: Alignment.center,
              errorBuilder: (_, __, ___) => const SizedBox.expand(),
            ),
          ),
        ),
        Positioned(
          left: 0, right: 0, bottom: -22, height: 178,
          child: Opacity(
            opacity: .30,
            child: Image.asset('assets/backgrounds/cloud_footer.png', fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox.expand()),
          ),
        ),
        const Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0x55D9ECFF), Color(0x44F6FBFF), Color(0x66EAF7FF)],
              ),
            ),
          ),
        ),
        Positioned(top: -90, right: -55, child: _GlowOrb(size: 250, color: Color(0x558BCBFF))),
        Positioned(bottom: -110, left: -65, child: _GlowOrb(size: 280, color: Color(0x44A7EBCB))),
        Positioned(top: 110, left: 35, child: Icon(Icons.auto_awesome_rounded, size: 13, color: alpha(Colors.white, .85))),
        Positioned(top: 210, right: 90, child: Icon(Icons.auto_awesome_rounded, size: 10, color: alpha(Colors.white, .8))),
        child,
      ]);
}

class _GlowOrb extends StatelessWidget {
  final double size;
  final Color color;
  const _GlowOrb({required this.size, required this.color});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [color, color.withAlpha(0)])),
      );
}

/// Вертикальный кадр 390×844, масштабируемый под окно и центрированный.
class GameFrame extends StatelessWidget {
  final Widget Function(BuildContext context, double s) builder;
  const GameFrame({super.key, required this.builder});
  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, box) {
        final s = math.min(box.maxWidth / 390, box.maxHeight / 844).toDouble();
        return Center(child: SizedBox(width: 390 * s, height: 844 * s, child: builder(context, s)));
      });
}

class ArtImage extends StatelessWidget {
  final String path;
  final double? width, height;
  final BoxFit fit;
  const ArtImage(this.path, {super.key, this.width, this.height, this.fit = BoxFit.contain});
  @override
  Widget build(BuildContext context) => Image.asset(
        path,
        width: width,
        height: height,
        fit: fit,
        filterQuality: FilterQuality.high,
        errorBuilder: (_, __, ___) => SizedBox(width: width, height: height),
      );
}

class PetImage extends StatelessWidget {
  final Pet? pet;
  final String? art;
  final double size;
  const PetImage({super.key, this.pet, this.art, required this.size});
  @override
  Widget build(BuildContext context) {
    final name = art ?? pet?.skin ?? 'slime';
    return SizedBox(
      width: size,
      height: size,
      child: Image.asset(
        'assets/pets/$name.png',
        fit: BoxFit.contain,
        filterQuality: FilterQuality.high,
        errorBuilder: (_, __, ___) =>
            Center(child: Text(pet?.emoji ?? '🟢', style: TextStyle(fontSize: size * 0.5))),
      ),
    );
  }
}

class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? color;
  final VoidCallback? onTap;
  const Glass({super.key, required this.child, this.padding = const EdgeInsets.all(14),
      this.radius = 22, this.color, this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap == null ? null : () { GameSounds.tap(); onTap!(); },
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: color ?? alpha(const Color(0xFFFCFDFF), 0.84),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: alpha(Colors.white, .96), width: 1.5),
            boxShadow: [BoxShadow(color: alpha(const Color(0xFF6F93CA), 0.22), blurRadius: 18, offset: const Offset(0, 6))],
          ),
          child: child,
        ),
      );
}

/// Крупная объёмная зелёная кнопка.
class GameButton extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;
  final List<Color> colors;
  final double height;
  const GameButton(this.text, {super.key, this.onTap, this.height = 56,
      this.colors = const [Color(0xFFB47BFF), Color(0xFF8650DE), Color(0xFF6235B7)]});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap == null ? null : () { GameSounds.tap(); onTap!(); },
        child: Opacity(
          opacity: onTap == null ? 0.5 : 1,
          child: Container(
            height: height,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: colors),
              borderRadius: BorderRadius.circular(height / 2),
              border: Border.all(color: const Color(0xFFE4C9FF), width: 2),
              boxShadow: [BoxShadow(color: alpha(const Color(0xFF512A9D), 0.42), blurRadius: 14, offset: const Offset(0, 6))],
            ),
            child: Text(text,
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: height * 0.38)),
          ),
        ),
      );
}

class GhostButton extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;
  const GhostButton(this.text, {super.key, this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap == null ? null : () { GameSounds.tap(); onTap!(); },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: alpha(Colors.white, 0.85),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFD7E6FF), width: 1.5),
          ),
          child: Text(text, style: const TextStyle(color: Color(0xFF34468C), fontWeight: FontWeight.w800, fontSize: 14)),
        ),
      );
}

/// Общая шапка разделов: название, краткое назначение и понятная навигация.
class PageBanner extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData icon;
  final Widget? trailing;
  const PageBanner({super.key, required this.title, this.subtitle, this.icon = Icons.auto_awesome_rounded, this.trailing});

  @override
  Widget build(BuildContext context) => Glass(
        radius: 22,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        child: Row(children: [
          Container(
            width: 43, height: 43,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF8BCFFF), Color(0xFF637EEA)]),
              borderRadius: BorderRadius.circular(15),
              boxShadow: [BoxShadow(color: alpha(const Color(0xFF4776C9), .18), blurRadius: 8, offset: const Offset(0, 3))],
            ),
            child: Icon(icon, color: Colors.white, size: 23),
          ),
          const SizedBox(width: 11),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: C.ink, fontSize: 17, fontWeight: FontWeight.w900)),
            if (subtitle != null)
              Text(subtitle!, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: C.muted, fontSize: 10, height: 1.25)),
          ])),
          if (trailing != null) ...[const SizedBox(width: 8), trailing!],
        ]),
      );
}

/// Обычный экран использует тот же игровой визуальный язык, что главная и карта.
class ScreenScaffold extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget child;
  final bool showBack;
  const ScreenScaffold({super.key, required this.title, this.subtitle, required this.child, this.showBack = true});

  IconData _iconForTitle() {
    if (title.contains('Магазин')) return Icons.storefront_rounded;
    if (title.contains('Профиль')) return Icons.person_rounded;
    if (title.contains('Коллекция')) return Icons.pets_rounded;
    if (title.contains('Тест')) return Icons.psychology_rounded;
    return Icons.auto_awesome_rounded;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SkyBackground(
          child: SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 920),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                  child: Column(children: [
                    Row(children: [
                      if (showBack)
                        Container(
                          margin: const EdgeInsets.only(right: 8),
                          decoration: BoxDecoration(color: alpha(Colors.white, .8), shape: BoxShape.circle,
                              border: Border.all(color: const Color(0xFFD4E5FB))),
                          child: IconButton(
                            onPressed: () => Navigator.of(context).maybePop(),
                            icon: const Icon(Icons.arrow_back_rounded, color: C.ink),
                            tooltip: 'Назад',
                          ),
                        ),
                      Expanded(child: PageBanner(title: title, subtitle: subtitle, icon: _iconForTitle())),
                    ]),
                    const SizedBox(height: 9),
                    Expanded(child: child),
                  ]),
                ),
              ),
            ),
          ),
        ),
      );
}

class Bar extends StatelessWidget {
  final double value;
  final Color color;
  final double height;
  const Bar(this.value, {super.key, this.color = C.green, this.height = 12});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(height),
        child: LinearProgressIndicator(
          value: value.clamp(0.0, 1.0).toDouble(),
          minHeight: height,
          color: color,
          backgroundColor: const Color(0xFFDDE7FF),
        ),
      );
}

Color scoreColor(num s) => s >= 80 ? C.good : (s >= 60 ? const Color(0xFFF59E0B) : C.bad);

Color hexColor(String hex, [Color fallback = C.ink]) {
  var h = hex.replaceAll('#', '');
  if (h.length == 6) h = 'FF$h';
  final v = int.tryParse(h, radix: 16);
  return v == null ? fallback : Color(v);
}
