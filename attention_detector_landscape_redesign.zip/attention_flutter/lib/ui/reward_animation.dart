import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';
import '../core/app_state.dart';
import '../core/game_sounds.dart';
import 'kit.dart';

/// Единственный кристалл за завершённую тренировку летит от питомца к счётчику.
/// Крошечные искры остаются позади и постепенно растворяются.
class CrystalRewardPanel extends StatefulWidget {
  final int balance;
  final int totalGain;
  const CrystalRewardPanel({super.key, required this.balance, required this.totalGain});

  @override
  State<CrystalRewardPanel> createState() => _CrystalRewardPanelState();
}

class _CrystalRewardPanelState extends State<CrystalRewardPanel>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    GameSounds.reward();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1450),
    )..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Offset _point(Size size, double t) {
    final start = Offset(76, size.height - 24);
    final control = Offset(size.width * .48, -8);
    final end = Offset(size.width - 42, 25);
    final u = 1 - t;
    return start * (u * u) + control * (2 * u * t) + end * (t * t);
  }

  @override
  Widget build(BuildContext context) {
    final bonus = math.max(0, widget.totalGain - 1);
    final startingBalance = math.max(0, widget.balance - widget.totalGain);
    return Glass(
      radius: 24,
      padding: const EdgeInsets.fromLTRB(16, 12, 14, 10),
      color: const Color(0xFFF8FCFF),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Награда за тренировку',
            style: TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 14)),
        const SizedBox(height: 2),
        const Text('Питомец нашёл для тебя кристалл!',
            style: TextStyle(color: C.muted, fontSize: 11)),
        SizedBox(
          height: 112,
          child: LayoutBuilder(builder: (context, box) {
            final size = Size(box.maxWidth, 112);
            return AnimatedBuilder(
              animation: _controller,
              builder: (context, _) {
                final t = Curves.easeInOutCubic.transform(_controller.value);
                final point = _point(size, t);
                final shownBalance = startingBalance + (widget.totalGain * t).round();
                return Stack(clipBehavior: Clip.none, children: [
                  Positioned.fill(
                    child: CustomPaint(
                      painter: _RewardTrailPainter(progress: t, pointFor: (v) => _point(size, v)),
                    ),
                  ),
                  Positioned(left: 2, bottom: 0, width: 58, height: 58,
                    child: Transform.translate(
                      offset: Offset(0, -math.sin(t * math.pi) * 4),
                      child: PetImage(pet: AppState.I.pet, size: 58),
                    ),
                  ),
                  Positioned(
                    right: 0,
                    top: 4,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEAF5FF),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: const Color(0xFFB8D9FF)),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        const ArtImage('assets/ui/gem.png', width: 19, height: 19),
                        const SizedBox(width: 5),
                        Text('$shownBalance',
                            style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 13)),
                      ]),
                    ),
                  ),
                  Positioned(
                    left: point.dx - 17,
                    top: point.dy - 17,
                    width: 34,
                    height: 34,
                    child: Opacity(
                      opacity: (1 - math.max(0, (t - .88) / .12)).clamp(0.0, 1.0).toDouble(),
                      child: Transform.scale(
                        scale: 1 + math.sin(t * math.pi * 5).abs() * .10,
                        child: const ArtImage('assets/ui/gem.png', width: 34, height: 34),
                      ),
                    ),
                  ),
                  if (_controller.isCompleted)
                    Positioned(
                      right: 2,
                      bottom: 0,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5F8E7),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Text('+1 💎',
                            style: TextStyle(color: Color(0xFF258344), fontWeight: FontWeight.w900, fontSize: 12)),
                      ),
                    ),
                ]);
              },
            );
          }),
        ),
        Row(children: [
          const Icon(Icons.auto_awesome_rounded, size: 15, color: C.gold),
          const SizedBox(width: 5),
          const Expanded(child: Text('+1 кристалл за выполненное задание',
              style: TextStyle(color: C.ink, fontSize: 11, fontWeight: FontWeight.w800))),
          if (bonus > 0)
            Text('ещё +$bonus бонусом',
                style: const TextStyle(color: Color(0xFF2D9A64), fontSize: 10, fontWeight: FontWeight.w800)),
        ]),
      ]),
    );
  }
}

class _RewardTrailPainter extends CustomPainter {
  final double progress;
  final Offset Function(double t) pointFor;
  const _RewardTrailPainter({required this.progress, required this.pointFor});

  @override
  void paint(Canvas canvas, Size size) {
    if (progress <= 0) return;
    final path = Path()..moveTo(pointFor(0).dx, pointFor(0).dy);
    for (var i = 1; i <= 24; i++) {
      final t = progress * i / 24;
      final p = pointFor(t);
      path.lineTo(p.dx, p.dy);
    }
    final line = Paint()
      ..color = alpha(const Color(0xFF6AD8FF), .52)
      ..strokeWidth = 2.4
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(path, line);

    for (var i = 0; i < 9; i++) {
      final t = progress - i * .075;
      if (t <= 0) continue;
      final p = pointFor(t);
      final fade = (1 - i / 9) * .88;
      final radius = 1.2 + (i % 3) * .65;
      final paint = Paint()..color = alpha(const Color(0xFFB9F5FF), fade);
      canvas.drawCircle(p + Offset(math.sin(i * 2.1) * 5, math.cos(i * 1.7) * 4), radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _RewardTrailPainter oldDelegate) =>
      oldDelegate.progress != progress;
}
