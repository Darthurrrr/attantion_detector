import 'package:material_ui/material_ui.dart';
import '../core/models.dart';
import '../tests/host.dart';
import '../ui/kit.dart';

/// Список всех тестов + «Полный тест» (четыре основных подряд).
class TestsHubScreen extends StatelessWidget {
  const TestsHubScreen({super.key});

  static const _order = ['reaction', 'stroop', 'schulte', 'memory', 'gonogo', 'nback', 'simon', 'odd'];

  @override
  Widget build(BuildContext context) => ScreenScaffold(
        title: 'Тесты',
        subtitle: 'Проверь внимание, реакцию и память',
        child: ListView(padding: const EdgeInsets.fromLTRB(14, 8, 14, 18), children: [
          Glass(
            radius: 22,
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              const PetImage(art: 'robot', size: 76),
              const SizedBox(width: 12),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Выбери свой вызов', style: TextStyle(color: C.ink, fontSize: 16, fontWeight: FontWeight.w900)),
                SizedBox(height: 4),
                Text('Короткие игровые задания для реакции, памяти и концентрации.',
                    style: TextStyle(color: C.muted, fontSize: 11, height: 1.35)),
              ])),
            ]),
          ),
          const SizedBox(height: 12),
          const Text('ОСНОВНЫЕ ТРЕНИРОВКИ',
              style: TextStyle(color: C.muted, fontWeight: FontWeight.w900, fontSize: 10, letterSpacing: .8)),
          const SizedBox(height: 7),
          for (final k in _order.take(4))
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Glass(
                onTap: () => runTest(context, k),
                child: Row(children: [
                  Container(
                    width: 48, height: 48, alignment: Alignment.center,
                    decoration: BoxDecoration(color: const Color(0xFFE8F0FF), borderRadius: BorderRadius.circular(16)),
                    child: Text(kTestEmoji[k] ?? '🎯', style: const TextStyle(fontSize: 26)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(kTestNames[k] ?? k, style: const TextStyle(color: C.ink, fontSize: 16, fontWeight: FontWeight.w800)),
                      Text(kTestDesc[k] ?? '', style: const TextStyle(color: C.muted, fontSize: 12)),
                    ]),
                  ),
                  const Icon(Icons.chevron_right_rounded, color: C.muted),
                ]),
              ),
            ),
          const SizedBox(height: 8),
          const Text('ДОПОЛНИТЕЛЬНЫЕ ИГРЫ',
              style: TextStyle(color: C.muted, fontWeight: FontWeight.w900, fontSize: 10, letterSpacing: .8)),
          const SizedBox(height: 7),
          for (final k in _order.skip(4))
            Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: Glass(
                onTap: () => runTest(context, k),
                child: Row(children: [
                  Container(width: 48, height: 48, alignment: Alignment.center,
                    decoration: BoxDecoration(color: const Color(0xFFEDE8FF), borderRadius: BorderRadius.circular(16)),
                    child: Text(kTestEmoji[k] ?? '🎯', style: const TextStyle(fontSize: 26))),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(kTestNames[k] ?? k, style: const TextStyle(color: C.ink, fontSize: 15, fontWeight: FontWeight.w800)),
                    Text(kTestDesc[k] ?? '', style: const TextStyle(color: C.muted, fontSize: 11)),
                  ])),
                  const Icon(Icons.chevron_right_rounded, color: C.muted),
                ]),
              ),
            ),
          const SizedBox(height: 6),
          GameButton('Полный тест (4 теста подряд)',
              colors: const [Color(0xFFFFD86B), Color(0xFFF4B72D), Color(0xFFD99A10)],
              onTap: () => runTest(context, 'reaction', queue: const ['stroop', 'schulte', 'memory'])),
        ]),
      );
}
