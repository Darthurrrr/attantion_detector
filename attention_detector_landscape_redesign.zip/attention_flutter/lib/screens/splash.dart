import 'package:material_ui/material_ui.dart';
import '../ui/kit.dart';

/// Стартовый экран с исходной композицией: логотип, робот и замок на острове.
/// Нижняя часть оригинального арта перекрывается облаками, чтобы убрать статичные
/// «75%» и подсказку; вместо них показывается настоящий индикатор запуска.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _breath;
  @override
  void initState() {
    super.initState();
    _breath = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200),
        lowerBound: .99, upperBound: 1.01)..repeat(reverse: true);
  }
  @override
  void dispose() { _breath.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: LayoutBuilder(builder: (context, box) {
          final wide = box.maxWidth > box.maxHeight;
          return Stack(fit: StackFit.expand, children: [
            ColoredBox(color: const Color(0xFF8CCFFF)),
            Center(
              child: AnimatedBuilder(
                animation: _breath,
                builder: (context, _) => Transform.scale(
                  scale: _breath.value,
                  child: SizedBox(
                    width: wide ? box.maxHeight * .562 : box.maxWidth,
                    height: wide ? box.maxHeight : box.maxHeight,
                    child: const ArtImage('assets/backgrounds/loading_screen.png', fit: BoxFit.cover),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              height: wide ? 112 : 150,
              child: Stack(alignment: Alignment.bottomCenter, children: [
                const Positioned.fill(child: ArtImage('assets/backgrounds/cloud_footer.png', fit: BoxFit.cover)),
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Text('Загрузка твоего мира…',
                        style: TextStyle(color: Color(0xFF455BA5), fontWeight: FontWeight.w900, fontSize: 13)),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: 240,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: const LinearProgressIndicator(
                          minHeight: 8,
                          backgroundColor: Color(0xFFD7E3FF),
                          color: Color(0xFF52BFF6),
                        ),
                      ),
                    ),
                  ]),
                ),
              ]),
            ),
          ]);
        }),
      );
}
