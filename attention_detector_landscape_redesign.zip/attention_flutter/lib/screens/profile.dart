import 'package:material_ui/material_ui.dart';
import '../core/app_state.dart';
import '../core/game_sounds.dart';
import '../ui/kit.dart';

class _StreakCard extends StatelessWidget {
  final int days;
  const _StreakCard({required this.days});

  @override
  Widget build(BuildContext context) {
    final progress = (days / 7).clamp(0.0, 1.0).toDouble();
    final message = days >= 7 ? 'Недельная серия достигнута! Так держать.' : 'Ещё ${7 - days} ${_pluralDay(7 - days)} до недельной серии.';
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFFFFF2D9), Color(0xFFFFD6AF), Color(0xFFFFE9D8)]),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFFFC58D), width: 1.4),
        boxShadow: [BoxShadow(color: const Color(0xFFE99A59).withValues(alpha: .18), blurRadius: 16, offset: const Offset(0, 6))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 48, height: 48, decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFFFA34B), Color(0xFFEF673C)]),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: const Color(0xFFE36D3D).withValues(alpha: .25), blurRadius: 9, offset: const Offset(0, 3))],
          ), child: const Icon(Icons.local_fire_department_rounded, color: Colors.white, size: 31)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('ТВОЯ СЕРИЯ', style: TextStyle(color: Color(0xFFAA6847), fontSize: 9, letterSpacing: 1.1, fontWeight: FontWeight.w900)),
            Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [
              Text('$days', style: const TextStyle(color: Color(0xFF8C492D), fontSize: 27, height: 1.1, fontWeight: FontWeight.w900)),
              const SizedBox(width: 6),
              Text(_pluralDay(days), style: const TextStyle(color: Color(0xFF9D5D3D), fontSize: 12, fontWeight: FontWeight.w800)),
            ]),
          ])),
          const Icon(Icons.auto_awesome_rounded, color: Color(0xFFE6A53F), size: 22),
        ]),
        const SizedBox(height: 12),
        ClipRRect(borderRadius: BorderRadius.circular(9), child: LinearProgressIndicator(
          value: progress, minHeight: 9, color: const Color(0xFFEF8C3B), backgroundColor: const Color(0xFFFFF9F0))),
        const SizedBox(height: 6),
        Text(message, style: const TextStyle(color: Color(0xFF98664E), fontSize: 11, fontWeight: FontWeight.w700)),
      ]),
    );
  }
}

String _pluralDay(int days) {
  final n = days.abs() % 100;
  if (n >= 11 && n <= 14) return 'дней';
  switch (days.abs() % 10) { case 1: return 'день'; case 2: case 3: case 4: return 'дня'; default: return 'дней'; }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final pr = st.progress;
          final quests = (pr['quests'] ?? []) as List;
          final league = (pr['league'] ?? {}) as Map;
          final goalXp = ((pr['goal_xp'] ?? st.user?.goal ?? 50) as num).toInt();
          final todayXp = ((pr['today_xp'] ?? 0) as num).toInt();
          return ScreenScaffold(
            title: 'Профиль',
            child: ListView(padding: const EdgeInsets.all(16), children: [
              Glass(
                child: Row(children: [
                  Container(
                    width: 76, height: 76,
                    decoration: BoxDecoration(
                      color: Colors.white, shape: BoxShape.circle,
                      border: Border.all(color: const Color(0xFF8FB8FF), width: 3)),
                    child: Padding(padding: const EdgeInsets.all(6), child: PetImage(pet: st.pet, size: 60)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(st.user?.name ?? '', style: const TextStyle(color: C.ink, fontSize: 22, fontWeight: FontWeight.w900)),
                      Text('Уровень ${st.level}  ·  ${pr['title'] ?? ''}',
                          style: const TextStyle(color: C.muted, fontSize: 12)),
                      if (league['name'] != null)
                        Text('Лига: ${league['name']}',
                            style: TextStyle(color: hexColor('${league['color']}'), fontWeight: FontWeight.w800, fontSize: 12)),
                      const SizedBox(height: 6),
                      Bar(st.xpNow / st.xpNeed, color: C.gold),
                      Text('${st.xpNow} / ${st.xpNeed} XP', style: const TextStyle(color: C.muted, fontSize: 11)),
                    ]),
                  ),
                ]),
              ),
              const SizedBox(height: 10),
              StatefulBuilder(builder: (context, setSoundState) => Glass(
                radius: 18,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    const Icon(Icons.volume_up_rounded, color: Color(0xFF6376D8), size: 22),
                    const SizedBox(width: 9),
                    const Expanded(child: Text('Звуки игры', style: TextStyle(color: C.ink, fontWeight: FontWeight.w900))),
                    Switch.adaptive(value: GameSounds.enabled, onChanged: (value) {
                      setSoundState(() => GameSounds.enabled = value);
                      if (value) GameSounds.success();
                    }),
                  ]),
                  if (GameSounds.enabled) Row(children: [
                    const Text('Громкость', style: TextStyle(color: C.muted, fontSize: 11)),
                    Expanded(child: Slider(
                      value: GameSounds.masterVolume,
                      min: 0.15,
                      max: 1.0,
                      onChanged: (value) => setSoundState(() => GameSounds.masterVolume = value),
                    )),
                    Text('${(GameSounds.masterVolume * 100).round()}%', style: const TextStyle(color: C.ink, fontSize: 11, fontWeight: FontWeight.w800)),
                  ]),
                ]),
              )),
              const SizedBox(height: 10),
              _StreakCard(days: st.streak),
              const SizedBox(height: 10),
              Row(children: [
                _stat('💎', '${st.gems}', 'самоцветов'),
                const SizedBox(width: 10),
                _stat('🏆', '${pr['unlocked'] ?? 0}', 'наград'),
              ]),
              const SizedBox(height: 14),
              const Text('Цель на день', style: TextStyle(color: C.ink, fontSize: 16, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Glass(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Bar(todayXp / goalXp, color: C.green),
                  const SizedBox(height: 4),
                  Text('Сегодня $todayXp из $goalXp XP', style: const TextStyle(color: C.muted, fontSize: 12)),
                  const SizedBox(height: 10),
                  Row(children: [
                    for (final g in const [30, 50, 100])
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 3),
                          child: GestureDetector(
                            onTap: () async {
                              final err = await st.setGoal(g);
                              if (err != null) toast('⚠️', 'Не получилось', err);
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: goalXp == g ? C.green : const Color(0xFFE8F0FF),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Text('$g XP',
                                  style: TextStyle(
                                      color: goalXp == g ? Colors.white : C.ink, fontWeight: FontWeight.w800)),
                            ),
                          ),
                        ),
                      ),
                  ]),
                ]),
              ),
              if (quests.isNotEmpty) ...[
                const SizedBox(height: 14),
                const Text('Задания дня', style: TextStyle(color: C.ink, fontSize: 16, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                for (final q in quests)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Glass(
                      radius: 16,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      child: Row(children: [
                        Icon((q as Map)['done'] == true ? Icons.check_circle_rounded : Icons.radio_button_unchecked,
                            color: q['done'] == true ? C.good : C.muted),
                        const SizedBox(width: 10),
                        Expanded(child: Text('${q['title']}', style: const TextStyle(color: C.ink, fontWeight: FontWeight.w700))),
                        Text('+${q['xp']} XP', style: const TextStyle(color: C.gold, fontWeight: FontWeight.w900)),
                      ]),
                    ),
                  ),
              ],
              const SizedBox(height: 18),
              GhostButton('Сменить пользователя', onTap: () async {
                await st.logout();
                if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
              }),
            ]),
          );
        },
      );

  Widget _stat(String emoji, String value, String label) => Expanded(
        child: Glass(
          radius: 18,
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(children: [
            Text(emoji, style: const TextStyle(fontSize: 22)),
            Text(value, style: const TextStyle(color: C.ink, fontSize: 18, fontWeight: FontWeight.w900)),
            Text(label, style: const TextStyle(color: C.muted, fontSize: 10)),
          ]),
        ),
      );
}
