import 'package:material_ui/material_ui.dart';
import '../core/app_state.dart';
import '../ui/kit.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});
  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final _name = TextEditingController();
  final _age = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _age.dispose();
    super.dispose();
  }

  Future<void> _go() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      setState(() => _error = 'Напиши, как к тебе обращаться');
      return;
    }
    int? age;
    if (_age.text.trim().isNotEmpty) {
      age = int.tryParse(_age.text.trim());
      if (age == null || age < 5 || age > 99) {
        setState(() => _error = 'Возраст должен быть от 5 до 99 лет');
        return;
      }
    }
    setState(() { _busy = true; _error = null; });
    final err = await AppState.I.login(name, age);
    if (!mounted) return;
    setState(() { _busy = false; _error = err; });
  }

  InputDecoration _field(String label, IconData icon) => InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: const Color(0xFF7587C0)),
        filled: true,
        fillColor: const Color(0xFFF7FAFF),
        counterText: '',
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: Color(0xFFDCE7FA)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: Color(0xFF65BDF5), width: 1.8),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Stack(fit: StackFit.expand, children: [
          const ArtImage('assets/backgrounds/home_main.png', fit: BoxFit.cover),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [alpha(const Color(0xFF2A81D9), .08), alpha(const Color(0xFFEAF5FF), .14), alpha(const Color(0xFF183D75), .17)],
              ),
            ),
          ),
          SafeArea(
            child: LayoutBuilder(builder: (context, constraints) {
              final compact = constraints.maxHeight < 720;
              return Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 430),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const SizedBox(height: 8),
                      const PetImage(art: 'robot', size: 116),
                      const Text('Твоё приключение начинается!',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white, fontSize: 23, height: 1.1, fontWeight: FontWeight.w900,
                            shadows: [Shadow(color: Color(0x66304C91), blurRadius: 10, offset: Offset(0, 3))])),
                      const SizedBox(height: 6),
                      const Text('Тренируй внимание, открывай уровни и заботься о питомце',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Color(0xFFF5FAFF), fontSize: 12, fontWeight: FontWeight.w700,
                            shadows: [Shadow(color: Color(0x66304C91), blurRadius: 8)])),
                      SizedBox(height: compact ? 12 : 22),
                      Glass(
                        radius: 28,
                        padding: const EdgeInsets.all(20),
                        color: const Color(0xF7FFFFFF),
                        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                          const Text('Создай свой профиль',
                              style: TextStyle(color: C.ink, fontSize: 20, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 4),
                          const Text('Это займёт всего пару секунд',
                              style: TextStyle(color: C.muted, fontSize: 12)),
                          const SizedBox(height: 16),
                          TextField(
                            controller: _name,
                            maxLength: 30,
                            textInputAction: TextInputAction.next,
                            decoration: _field('Как тебя зовут?', Icons.person_rounded),
                          ),
                          const SizedBox(height: 9),
                          TextField(
                            controller: _age,
                            keyboardType: TextInputType.number,
                            textInputAction: TextInputAction.done,
                            decoration: _field('Возраст (необязательно)', Icons.cake_rounded),
                            onSubmitted: (_) => _go(),
                          ),
                          if (_error != null) ...[
                            const SizedBox(height: 9),
                            Text(_error!, style: const TextStyle(color: C.bad, fontWeight: FontWeight.w700, fontSize: 12)),
                          ],
                          const SizedBox(height: 14),
                          GameButton(_busy ? 'Готовим приключение…' : 'Начать играть',
                              height: 54, onTap: _busy ? null : _go),
                        ]),
                      ),
                      const SizedBox(height: 12),
                      const Text('Без соревнований и оценок — только твой прогресс 💙',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700,
                            shadows: [Shadow(color: Color(0x77304C91), blurRadius: 8)])),
                    ]),
                  ),
                ),
              );
            }),
          ),
        ]),
      );
}
