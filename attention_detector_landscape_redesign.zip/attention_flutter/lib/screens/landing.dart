import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';
import '../core/app_state.dart';
import '../core/game_sounds.dart';
import '../core/models.dart';
import '../ui/kit.dart';
import 'collection.dart';
import 'profile.dart';
import 'shop.dart';
import 'tests_hub.dart';

String _compact(int v) {
  if (v >= 1000000) return '${(v / 1000000).toStringAsFixed(1).replaceAll('.0', '')}M';
  if (v >= 10000) return '${(v / 1000).round()}K';
  if (v >= 1000) return '${(v / 1000).toStringAsFixed(1).replaceAll('.0', '')}K';
  return '$v';
}

class LandingTab extends StatelessWidget {
  final VoidCallback? onPlay;
  const LandingTab({super.key, this.onPlay});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) => LayoutBuilder(builder: (context, box) {
          if (box.maxWidth >= 680 && box.maxWidth > box.maxHeight * 1.12) {
            return _WideLanding(onPlay: onPlay);
          }
          return _PortraitLanding(onPlay: onPlay);
        }),
      );
}

class _PortraitLanding extends StatelessWidget {
  final VoidCallback? onPlay;
  const _PortraitLanding({this.onPlay});

  @override
  Widget build(BuildContext context) {
    void open(Widget page) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
    return Padding(
      padding: const EdgeInsets.fromLTRB(9, 8, 9, 7),
      child: Column(children: [
        _PlayerHud(
          compact: true,
          onProfile: () => open(const ProfileScreen()),
          onShop: () => open(const ShopScreen()),
        ),
        const SizedBox(height: 10),
        // The bottom game's primary Play control is the single main CTA.
        // Removing the duplicate quick-action strip gives the pet world room to breathe.
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(bottom: 2),
            child: _PetWorld(portrait: true),
          ),
        ),
      ]),
    );
  }
}

class _WideLanding extends StatelessWidget {
  final VoidCallback? onPlay;
  const _WideLanding({this.onPlay});

  @override
  Widget build(BuildContext context) {
    void open(Widget page) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
    return Padding(
      padding: const EdgeInsets.all(16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: Stack(children: [
          Positioned.fill(child: _PetWorld(portrait: false)),
          Positioned(
            left: 16,
            right: 16,
            top: 13,
            child: _PlayerHud(
              compact: false,
              onProfile: () => open(const ProfileScreen()),
              onShop: () => open(const ShopScreen()),
            ),
          ),
          Positioned(
            right: 20,
            bottom: 17,
            child: SizedBox(
              width: 224,
              child: GameButton('Начать тренировку  ›', onTap: onPlay, height: 50,
                colors: const [Color(0xFFFFD978), Color(0xFFF2AE35), Color(0xFFD9871C)]),
            ),
          ),
        ]),
      ),
    );
  }
}

class _PlayerHud extends StatelessWidget {
  final bool compact;
  final VoidCallback onProfile;
  final VoidCallback onShop;
  const _PlayerHud({required this.compact, required this.onProfile, required this.onShop});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final avatar = GestureDetector(
      onTap: () { GameSounds.tap(); onProfile(); },
      child: Container(
        width: compact ? 43 : 52,
        height: compact ? 43 : 52,
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(color: const Color(0xFF9BCBFF), width: 2.4),
          boxShadow: [BoxShadow(color: alpha(const Color(0xFF335C9A), .18), blurRadius: 10, offset: const Offset(0, 3))],
        ),
        child: const PetImage(art: 'robot', size: 42),
      ),
    );
    final progress = Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
      Row(children: [
        Container(
          width: compact ? 24 : 28,
          height: compact ? 24 : 28,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: C.gold, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
          child: Text('${st.level}', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: compact ? 11 : 13)),
        ),
        const SizedBox(width: 7),
        Text(st.user?.name ?? 'Путешественник',
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: C.ink, fontSize: compact ? 12 : 15, fontWeight: FontWeight.w900)),
      ]),
      const SizedBox(height: 4),
      SizedBox(
        width: compact ? 116 : 210,
        child: Bar(st.xpNow / st.xpNeed, color: C.gold, height: compact ? 8 : 10),
      ),
      Text('${st.xpNow} / ${st.xpNeed} XP',
          style: TextStyle(color: const Color(0xFF38528D), fontWeight: FontWeight.w800, fontSize: compact ? 9 : 10)),
    ]);
    final wallet = GestureDetector(
      onTap: () { GameSounds.tap(); onShop(); },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: compact ? 9 : 13, vertical: compact ? 7 : 9),
        decoration: BoxDecoration(
          color: const Color(0xF2FFFFFF),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFAED3FF), width: 1.5),
          boxShadow: [BoxShadow(color: alpha(const Color(0xFF3B68A9), .16), blurRadius: 9, offset: const Offset(0, 3))],
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const ArtImage('assets/ui/gem.png', width: 20, height: 20),
          const SizedBox(width: 5),
          Text(_compact(st.gems), style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 13)),
          const SizedBox(width: 4),
          const Icon(Icons.add_circle_rounded, size: 17, color: Color(0xFF48C66A)),
        ]),
      ),
    );
    return Row(children: [
      avatar,
      const SizedBox(width: 8),
      Expanded(child: progress),
      const SizedBox(width: 5),
      _StreakBadge(value: st.streak, compact: compact),
      const SizedBox(width: 6),
      wallet,
      if (!compact) ...[
        const SizedBox(width: 10),
        IconButton(
          tooltip: 'Профиль',
          onPressed: onProfile,
          style: IconButton.styleFrom(backgroundColor: const Color(0xEFFFFFFF), foregroundColor: C.ink),
          icon: const Icon(Icons.settings_rounded),
        ),
      ],
    ]);
  }
}

class _StreakBadge extends StatelessWidget {
  final int value;
  final bool compact;
  const _StreakBadge({required this.value, required this.compact});

  @override
  Widget build(BuildContext context) => Tooltip(
        message: '$value дней подряд',
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: compact ? 7 : 10, vertical: compact ? 5 : 7),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFFFF1D8), Color(0xFFFFD4A7)],
            ),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: const Color(0xFFFFB96A), width: 1.2),
            boxShadow: [BoxShadow(color: alpha(const Color(0xFFE58A3A), .20), blurRadius: 8, offset: const Offset(0, 3))],
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.local_fire_department_rounded, color: const Color(0xFFF07835), size: compact ? 19 : 22),
            const SizedBox(width: 3),
            Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('$value', style: TextStyle(color: const Color(0xFF8A4C2B), fontSize: compact ? 12 : 14, height: 1, fontWeight: FontWeight.w900)),
              Text('дней', style: TextStyle(color: const Color(0xFFA96847), fontSize: compact ? 7 : 8, height: 1.05, fontWeight: FontWeight.w800)),
            ]),
          ]),
        ),
      );
}

class _PetWorld extends StatefulWidget {
  final bool portrait;
  const _PetWorld({required this.portrait});

  @override
  State<_PetWorld> createState() => _PetWorldState();
}

class _PetWorldState extends State<_PetWorld> with TickerProviderStateMixin {
  late final AnimationController _float;
  late final AnimationController _squish;
  late final AnimationController _affection;
  double _strokeDistance = 0;
  bool _strokeFired = false;

  @override
  void initState() {
    super.initState();
    _float = AnimationController(vsync: this, duration: const Duration(milliseconds: 2500))..repeat(reverse: true);
    _squish = AnimationController(vsync: this, duration: const Duration(milliseconds: 310));
    _affection = AnimationController(vsync: this, duration: const Duration(milliseconds: 820));
  }

  @override
  void dispose() {
    _float.dispose();
    _squish.dispose();
    _affection.dispose();
    super.dispose();
  }

  void _petTouchDown(TapDownDetails _) {
    _squish.forward(from: 0);
    GameSounds.petTap();
  }

  void _strokeStart(DragStartDetails _) {
    _strokeDistance = 0;
    _strokeFired = false;
  }

  void _strokeUpdate(DragUpdateDetails details) {
    _strokeDistance += details.delta.distance;
    if (_strokeDistance > 34 && !_strokeFired) {
      _strokeFired = true;
      _affection.forward(from: 0);
      GameSounds.petCuddle();
    }
  }

  void _strokeEnd(DragEndDetails _) {
    _strokeDistance = 0;
    _strokeFired = false;
  }

  void _quickAction(BuildContext context, String action) {
    GameSounds.tap();
    switch (action) {
      case 'shop':
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ShopScreen()));
        break;
      case 'pets':
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CollectionScreen()));
        break;
      case 'tasks':
        _showTasks(context);
        break;
      case 'daily':
        _showDaily(context);
        break;
      case 'event':
        toastSoon('События');
        break;
      case 'friends':
        toastSoon('Друзья');
        break;
    }
  }

  void _showDaily(BuildContext context) {
    final streak = AppState.I.streak;
    final quests = (AppState.I.progress['quests'] ?? const []) as List;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheet) => _QuickSheet(
        icon: Icons.local_fire_department_rounded,
        title: 'Ежедневная серия',
        subtitle: streak > 0 ? 'Ты уже занимаешься $streak ${_dayWord(streak)} подряд. Сохрани свой ритм!' : 'Начни серию сегодня — даже одна короткая тренировка считается.',
        accent: const Color(0xFFF28A43),
        actionText: 'К заданиям дня',
        onAction: () { Navigator.pop(sheet); _showTasks(context); },
        children: [
          _SheetStat(icon: '🔥', title: '$streak ${_dayWord(streak)} подряд', detail: 'Твоя текущая серия'),
          _SheetStat(icon: '🎯', title: '${quests.where((q) => q is Map && q['done'] == true).length}/${quests.length} заданий', detail: 'Выполнено сегодня'),
        ],
      ),
    );
  }

  void _showTasks(BuildContext context) {
    final quests = (AppState.I.progress['quests'] ?? const []) as List;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheet) => _QuickSheet(
        icon: Icons.task_alt_rounded,
        title: 'Задания дня',
        subtitle: 'Небольшие цели, которые помогают поддерживать привычку.',
        accent: const Color(0xFF55A6E8),
        actionText: 'Выбрать тренировку',
        onAction: () { Navigator.pop(sheet); Navigator.of(context).push(MaterialPageRoute(builder: (_) => const TestsHubScreen())); },
        children: quests.isEmpty
            ? [const _SheetStat(icon: '✨', title: 'Твои задания появятся здесь', detail: 'Сервер пока не вернул список ежедневных целей.')]
            : [for (final q in quests.whereType<Map>()) _SheetStat(
                icon: q['done'] == true ? '✅' : '🎯',
                title: '${q['title'] ?? 'Задание'}',
                detail: '${q['desc'] ?? 'Продолжай тренироваться'}  ·  +${q['xp'] ?? 0} XP',
              )],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pet = AppState.I.pet;
    return LayoutBuilder(builder: (context, box) {
      final w = box.maxWidth;
      final h = box.maxHeight;
      final petSize = widget.portrait ? math.min(w * .58, h * .48).toDouble() : math.min(330.0, h * .64).toDouble();
      final worldRadius = widget.portrait ? 22.0 : 28.0;
      final quickSize = widget.portrait ? 62.0 : 70.0;
      return ClipRRect(
        borderRadius: BorderRadius.circular(worldRadius),
        child: Stack(fit: StackFit.expand, children: [
          ArtImage(widget.portrait ? 'assets/backgrounds/home_main.png' : 'assets/backgrounds/home_landscape.jpg', fit: BoxFit.cover),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [alpha(const Color(0xFF5EAEF0), .06), Colors.transparent, alpha(const Color(0xFFDFF9A9), .08)],
              ),
            ),
          ),
          Positioned(
            top: widget.portrait ? 14 : 82,
            left: widget.portrait ? 28 : 60,
            right: widget.portrait ? 28 : 60,
            child: Center(
              child: Glass(
                radius: 17,
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                child: Text(
                  pet == null ? 'Скоро здесь появится твой спутник!' : 'Погладь меня — я люблю внимание! ✨',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: C.ink, fontSize: widget.portrait ? 11 : 14, fontWeight: FontWeight.w900),
                ),
              ),
            ),
          ),
          // Вернули быстрые игровые действия по бокам питомца — они не перекрывают его.
          Positioned(left: 4, top: h * .22, child: _QuickAction(asset: 'shop', label: 'Магазин', size: quickSize, onTap: () => _quickAction(context, 'shop'))),
          Positioned(left: 4, top: h * .405, child: _QuickAction(asset: 'tasks', label: 'Задания', size: quickSize, onTap: () => _quickAction(context, 'tasks'))),
          Positioned(left: 4, top: h * .59, child: _QuickAction(asset: 'friends', label: 'Друзья', size: quickSize, onTap: () => _quickAction(context, 'friends'))),
          Positioned(right: 4, top: h * .265, child: _QuickAction(asset: 'daily', label: 'Награда', size: quickSize, onTap: () => _quickAction(context, 'daily'))),
          Positioned(right: 4, top: h * .45, child: _QuickAction(asset: 'pets', label: 'Питомцы', size: quickSize, onTap: () => _quickAction(context, 'pets'))),
          Positioned(right: 4, top: h * .635, child: _QuickAction(asset: 'event', label: 'Событие', size: quickSize, onTap: () => _quickAction(context, 'event'))),
          Positioned(
            left: 0,
            right: 0,
            top: widget.portrait ? h * .18 : h * .13,
            bottom: widget.portrait ? h * .02 : h * .03,
            child: AnimatedBuilder(
              animation: _float,
              builder: (context, _) {
                final bob = math.sin(_float.value * math.pi) * (widget.portrait ? 5.0 : 8.0);
                return Transform.translate(
                  offset: Offset(0, -bob),
                  child: Stack(alignment: Alignment.center, children: [
                    Positioned(
                      bottom: widget.portrait ? 22 : 28,
                      child: Container(
                        width: petSize * .55,
                        height: petSize * .12,
                        decoration: BoxDecoration(color: alpha(const Color(0xFF3A7425), .25), borderRadius: BorderRadius.circular(100)),
                      ),
                    ),
                    Align(
                      alignment: Alignment(widget.portrait ? 0 : .06, .28),
                      child: _InteractivePet(
                        pet: pet,
                        size: petSize,
                        onTouchDown: _petTouchDown,
                        onStrokeStart: _strokeStart,
                        onStrokeUpdate: _strokeUpdate,
                        onStrokeEnd: _strokeEnd,
                        affection: _affection,
                        squish: _squish,
                      ),
                    ),
                    Positioned(
                      bottom: widget.portrait ? 4 : 6,
                      child: Glass(
                        radius: 16,
                        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Text(pet?.name ?? 'Твой питомец', style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 12)),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                            decoration: BoxDecoration(color: C.gold, borderRadius: BorderRadius.circular(10)),
                            child: Text('Ур. ${pet?.level ?? 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 10)),
                          ),
                        ]),
                      ),
                    ),
                    Positioned(top: widget.portrait ? 35 : 48, left: widget.portrait ? w * .16 : w * .22, child: const _Sparkle(size: 16)),
                    Positioned(top: widget.portrait ? 80 : 100, right: widget.portrait ? w * .17 : w * .24, child: const _Sparkle(size: 11)),
                  ]),
                );
              },
            ),
          ),
        ]),
      );
    });
  }
}

class _InteractivePet extends StatelessWidget {
  final Pet? pet;
  final double size;
  final ValueChanged<TapDownDetails> onTouchDown;
  final ValueChanged<DragStartDetails> onStrokeStart;
  final ValueChanged<DragUpdateDetails> onStrokeUpdate;
  final ValueChanged<DragEndDetails> onStrokeEnd;
  final AnimationController affection;
  final AnimationController squish;
  const _InteractivePet({required this.pet, required this.size, required this.onTouchDown,
    required this.onStrokeStart, required this.onStrokeUpdate, required this.onStrokeEnd,
    required this.affection, required this.squish});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size * 1.12,
        child: Stack(clipBehavior: Clip.none, children: [
          Positioned(
            left: 0, right: 0, bottom: 0,
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTapDown: onTouchDown,
              onTap: () { affection.forward(from: 0); },
              onPanStart: onStrokeStart,
              onPanUpdate: onStrokeUpdate,
              onPanEnd: onStrokeEnd,
              child: AnimatedBuilder(
                animation: squish,
                builder: (context, _) {
                  final t = squish.value;
                  final y = t < .24 ? 1 - .14 * (t / .24) : (t < .58 ? .86 + .19 * ((t - .24) / .34) : 1.05 - .05 * ((t - .58) / .42));
                  final x = t < .24 ? 1 + .035 * (t / .24) : (t < .58 ? 1.035 - .045 * ((t - .24) / .34) : .99 + .01 * ((t - .58) / .42));
                  return Transform.scale(
                    scaleX: x,
                    scaleY: y,
                    alignment: Alignment.bottomCenter,
                    child: PetImage(pet: pet, art: pet == null ? 'robot' : null, size: size),
                  );
                },
              ),
            ),
          ),
          Positioned(
            top: 2,
            left: 0,
            right: 0,
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: affection,
                builder: (context, _) {
                  final t = Curves.easeOut.transform(affection.value);
                  return Opacity(
                    opacity: (1 - t).clamp(0.0, 1.0).toDouble(),
                    child: Transform.translate(
                      offset: Offset(0, -18 * t),
                      child: Transform.scale(
                        scale: .72 + .55 * t,
                        child: const Text('💗  ✨', textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 24, shadows: [Shadow(color: Color(0x66FFFFFF), blurRadius: 8)])),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ]),
      );
}

class _QuickAction extends StatelessWidget {
  final String asset;
  final String label;
  final double size;
  final VoidCallback onTap;
  const _QuickAction({required this.asset, required this.label, required this.size, required this.onTap});

  @override
  Widget build(BuildContext context) => Tooltip(
        message: label,
        child: GestureDetector(
          onTap: onTap,
          child: Semantics(
            button: true,
            label: label,
            child: SizedBox(
              width: size,
              height: size,
              child: ArtImage('assets/buttons/$asset.png', fit: BoxFit.contain),
            ),
          ),
        ),
      );
}

class _QuickSheet extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color accent;
  final List<Widget> children;
  final String actionText;
  final VoidCallback onAction;
  const _QuickSheet({required this.icon, required this.title, required this.subtitle, required this.accent,
    required this.children, required this.actionText, required this.onAction});

  @override
  Widget build(BuildContext context) => SafeArea(
        child: Container(
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [Color(0xFFF9FCFF), Color(0xFFEAF4FF)]),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white, width: 2),
            boxShadow: [BoxShadow(color: alpha(const Color(0xFF486DA8), .22), blurRadius: 26, offset: const Offset(0, 8))],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [
              Container(width: 42, height: 42, decoration: BoxDecoration(color: alpha(accent, .13), borderRadius: BorderRadius.circular(14)),
                child: Icon(icon, color: accent, size: 25)),
              const SizedBox(width: 10),
              Expanded(child: Text(title, style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 19))),
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded, color: C.ink)),
            ]),
            const SizedBox(height: 5),
            Text(subtitle, style: const TextStyle(color: C.muted, fontSize: 12, height: 1.35)),
            const SizedBox(height: 13),
            ...children,
            const SizedBox(height: 13),
            GameButton(actionText, onTap: onAction, height: 48),
          ]),
        ),
      );
}

class _SheetStat extends StatelessWidget {
  final String icon;
  final String title;
  final String detail;
  const _SheetStat({required this.icon, required this.title, required this.detail});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Colors.white.withValues(alpha: .78), borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFDCEAFF))),
          child: Row(children: [
            Text(icon, style: const TextStyle(fontSize: 22)), const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 12)),
              Text(detail, style: const TextStyle(color: C.muted, fontSize: 10, height: 1.3)),
            ])),
          ]),
        ),
      );
}

String _dayWord(int value) {
  final mod100 = value % 100;
  if (mod100 >= 11 && mod100 <= 14) return 'дней';
  switch (value % 10) { case 1: return 'день'; case 2: case 3: case 4: return 'дня'; default: return 'дней'; }
}

class _Sparkle extends StatefulWidget {
  final double size;
  const _Sparkle({required this.size});
  @override
  State<_Sparkle> createState() => _SparkleState();
}

class _SparkleState extends State<_Sparkle> with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;
  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 1450))..repeat(reverse: true);
  }
  @override
  void dispose() { _pulse.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
        opacity: Tween<double>(begin: .28, end: .95).animate(_pulse),
        child: ScaleTransition(
          scale: Tween<double>(begin: .78, end: 1.22).animate(_pulse),
          child: Icon(Icons.auto_awesome_rounded, size: widget.size, color: const Color(0xFFFFF7B2)),
        ),
      );
}
