import 'package:material_ui/material_ui.dart';
import '../core/app_state.dart';
import '../core/game_sounds.dart';
import '../ui/kit.dart';
import 'awards.dart';
import 'collection.dart';
import 'history.dart';
import 'landing.dart';
import 'path_map.dart';
import 'profile.dart';
import 'shop.dart';
import 'tests_hub.dart';

/// Основная оболочка: мобильная игровая навигация и отдельная композиция для широких экранов.
class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    AppState.I.refresh();
  }

  void _select(int i) {
    if (i == 8) {
      _showMore();
      return;
    }
    GameSounds.transition();
    if (i >= 4 && i <= 7) {
      final Widget page = switch (i) {
        4 => const ShopScreen(),
        5 => const CollectionScreen(),
        6 => const TestsHubScreen(),
        _ => const ProfileScreen(),
      };
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
      AppState.I.refresh();
      return;
    }
    setState(() => _tab = i);
    AppState.I.refresh();
  }

  void _showMore() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: Container(
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
          decoration: BoxDecoration(
            color: const Color(0xFFF7FBFF),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white, width: 2),
            boxShadow: [BoxShadow(color: alpha(const Color(0xFF496A9C), .20), blurRadius: 26, offset: const Offset(0, 8))],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              const Expanded(child: Text('Все разделы', style: TextStyle(color: C.ink, fontSize: 19, fontWeight: FontWeight.w900))),
              IconButton(onPressed: () => Navigator.pop(sheetContext), icon: const Icon(Icons.close_rounded, color: C.ink)),
            ]),
            const SizedBox(height: 8),
            Wrap(spacing: 10, runSpacing: 10, children: [
              _MoreTile(icon: Icons.storefront_rounded, title: 'Магазин', subtitle: 'Яйца и предметы', onTap: () { Navigator.pop(sheetContext); _select(4); }),
              _MoreTile(icon: Icons.pets_rounded, title: 'Питомцы', subtitle: 'Коллекция и уход', onTap: () { Navigator.pop(sheetContext); _select(5); }),
              _MoreTile(icon: Icons.psychology_rounded, title: 'Тренировки', subtitle: 'Все упражнения', onTap: () { Navigator.pop(sheetContext); _select(6); }),
              _MoreTile(icon: Icons.person_rounded, title: 'Профиль', subtitle: 'Цели и настройки', onTap: () { Navigator.pop(sheetContext); _select(7); }),
            ]),
          ]),
        ),
      ),
    );
  }

  Widget _content() {
    switch (_tab) {
      case 1: return const HistoryTab();
      case 2: return const PathTab();
      case 3: return const AwardsTab();
      default: return LandingTab(onPlay: () => _select(2));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SkyBackground(
          child: LayoutBuilder(builder: (context, box) {
            final wide = box.maxWidth >= 1120 && box.maxHeight >= 480;
            if (wide) return _DesktopShell(tab: _tab, onSelect: _select, content: _content());
            if (box.maxWidth >= 680 && box.maxWidth > box.maxHeight * 1.18) {
              return _LandscapeShell(tab: _tab, onSelect: _select, content: _content());
            }
            return GameFrame(
              builder: (context, s) => Column(children: [
                Expanded(child: _content()),
                SizedBox(height: 86 * s, child: _BottomBar(s: s, tab: _tab, onSelect: _select)),
              ]),
            );
          }),
        ),
      );
}


class _LandscapeShell extends StatelessWidget {
  final int tab;
  final ValueChanged<int> onSelect;
  final Widget content;
  const _LandscapeShell({required this.tab, required this.onSelect, required this.content});

  @override
  Widget build(BuildContext context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 12, 8),
          child: Row(children: [
            Container(
              width: 72,
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 5),
              decoration: BoxDecoration(
                color: const Color(0xEDEFE5FF),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFFFFFFFF), width: 1.5),
                boxShadow: [BoxShadow(color: alpha(const Color(0xFF55338F), .16), blurRadius: 18, offset: const Offset(0, 5))],
              ),
              child: Column(children: [
                const PetImage(art: 'robot', size: 48),
                const SizedBox(height: 7),
                Expanded(child: ListView(padding: EdgeInsets.zero, children: [
                  _RailButton(icon: Icons.home_rounded, label: 'Домой', active: tab == 0, onTap: () => onSelect(0)),
                  _RailButton(icon: Icons.route_rounded, label: 'Путь', active: tab == 2, onTap: () => onSelect(2)),
                  _RailButton(icon: Icons.insights_rounded, label: 'Статы', active: tab == 1, onTap: () => onSelect(1)),
                  _RailButton(icon: Icons.emoji_events_rounded, label: 'Награды', active: tab == 3, onTap: () => onSelect(3)),
                  _RailButton(icon: Icons.storefront_rounded, label: 'Магазин', active: false, onTap: () => onSelect(4)),
                  _RailButton(icon: Icons.pets_rounded, label: 'Питомцы', active: false, onTap: () => onSelect(5)),
                  _RailButton(icon: Icons.psychology_rounded, label: 'Тесты', active: false, onTap: () => onSelect(6)),
                  _RailButton(icon: Icons.person_rounded, label: 'Профиль', active: false, onTap: () => onSelect(7)),
                ])),
              ]),
            ),
            const SizedBox(width: 10),
            Expanded(child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 220),
              child: KeyedSubtree(key: ValueKey(tab), child: content),
            )),
          ]),
        ),
      );
}

class _RailButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _RailButton({required this.icon, required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 5),
        child: Material(
          color: active ? const Color(0xFF7B4BC8) : Colors.transparent,
          borderRadius: BorderRadius.circular(15),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(15),
            child: SizedBox(
              height: 58,
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(icon, size: 22, color: active ? Colors.white : const Color(0xFF70558F)),
                const SizedBox(height: 3),
                Text(label, maxLines: 1, style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900,
                    color: active ? Colors.white : const Color(0xFF70558F))),
              ]),
            ),
          ),
        ),
      );
}

class _DesktopShell extends StatelessWidget {
  final int tab;
  final ValueChanged<int> onSelect;
  final Widget content;
  const _DesktopShell({required this.tab, required this.onSelect, required this.content});

  @override
  Widget build(BuildContext context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            SizedBox(width: 174, child: _DesktopRail(tab: tab, onSelect: onSelect)),
            const SizedBox(width: 16),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 260),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                child: Center(
                  key: ValueKey(tab),
                  child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1180), child: content),
                ),
              ),
            ),
            const SizedBox(width: 16),
            const SizedBox(width: 276, child: _DesktopCompanionPanel()),
          ]),
        ),
      );
}

class _DesktopRail extends StatelessWidget {
  final int tab;
  final ValueChanged<int> onSelect;
  const _DesktopRail({required this.tab, required this.onSelect});

  @override
  Widget build(BuildContext context) => Column(children: [
        Glass(
          radius: 24,
          padding: const EdgeInsets.fromLTRB(12, 16, 12, 14),
          child: Column(children: [
            const PetImage(art: 'robot', size: 70),
            const SizedBox(height: 7),
            const Text('Детектор\nвнимания', textAlign: TextAlign.center,
                style: TextStyle(color: C.ink, fontSize: 17, height: 1.05, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            const Text('Твой мир тренировок', style: TextStyle(color: C.muted, fontSize: 10)),
          ]),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: ListView(padding: EdgeInsets.zero, children: [
            _NavButton(icon: Icons.home_rounded, title: 'Главная', active: tab == 0, onTap: () => onSelect(0)),
            _NavButton(icon: Icons.insights_rounded, title: 'Статистика', active: tab == 1, onTap: () => onSelect(1)),
            _NavButton(icon: Icons.route_rounded, title: 'Путь', active: tab == 2, onTap: () => onSelect(2)),
            _NavButton(icon: Icons.emoji_events_rounded, title: 'Достижения', active: tab == 3, onTap: () => onSelect(3)),
            _NavButton(icon: Icons.storefront_rounded, title: 'Магазин', active: false, onTap: () => onSelect(4)),
            _NavButton(icon: Icons.pets_rounded, title: 'Питомцы', active: false, onTap: () => onSelect(5)),
            _NavButton(icon: Icons.psychology_rounded, title: 'Тренировки', active: false, onTap: () => onSelect(6)),
            _NavButton(icon: Icons.person_rounded, title: 'Профиль', active: false, onTap: () => onSelect(7)),
          ]),
        ),
        Glass(
          radius: 18,
          padding: const EdgeInsets.all(10),
          child: Row(children: [
            const Icon(Icons.auto_awesome_rounded, color: C.gold, size: 19),
            const SizedBox(width: 6),
            const Expanded(child: Text('Каждый день —\nмаленький прогресс',
                style: TextStyle(color: C.ink, fontWeight: FontWeight.w800, fontSize: 10))),
          ]),
        ),
      ]);
}

class _MoreTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _MoreTile({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: 148,
        child: Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          child: InkWell(
            onTap: () { GameSounds.tap(); onTap(); },
            borderRadius: BorderRadius.circular(18),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFD9E9FF))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(icon, color: const Color(0xFF6376D8), size: 25),
                const SizedBox(height: 8),
                Text(title, style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 13)),
                const SizedBox(height: 2),
                Text(subtitle, style: const TextStyle(color: C.muted, fontSize: 10)),
              ]),
            ),
          ),
        ),
      );
}

class _NavButton extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool active;
  final VoidCallback onTap;
  const _NavButton({required this.icon, required this.title, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 7),
        child: Material(
          color: active ? const Color(0xFFDAEFFF) : alpha(Colors.white, .44),
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () { GameSounds.tap(); onTap(); },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: active ? const Color(0xFF8CCBFF) : alpha(Colors.white, .7)),
              ),
              child: Row(children: [
                Icon(icon, color: active ? const Color(0xFF3C75C3) : C.muted, size: 21),
                const SizedBox(width: 10),
                Text(title, style: TextStyle(color: active ? C.ink : const Color(0xFF5E6F98),
                    fontWeight: FontWeight.w900, fontSize: 12)),
              ]),
            ),
          ),
        ),
      );
}

class _DesktopCompanionPanel extends StatelessWidget {
  const _DesktopCompanionPanel();
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final pr = st.progress;
          final quests = (pr['quests'] ?? []) as List;
          final todayXp = ((pr['today_xp'] ?? 0) as num).toInt();
          final goal = ((pr['goal_xp'] ?? st.user?.goal ?? 50) as num).toInt();
          return Column(children: [
            Glass(
              radius: 24,
              padding: const EdgeInsets.all(14),
              child: Column(children: [
                Row(children: [
                  Container(
                    width: 48, height: 48,
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFF9BCBFF), width: 2)),
                    child: PetImage(pet: st.pet, art: st.pet == null ? 'robot' : null, size: 42),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(st.user?.name ?? 'Путешественник', maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 14)),
                    Text('Уровень ${st.level}', style: const TextStyle(color: C.muted, fontSize: 11)),
                  ])),
                ]),
                const SizedBox(height: 12),
                Bar(st.xpNow / st.xpNeed, color: C.gold, height: 10),
                const SizedBox(height: 4),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('${st.xpNow} / ${st.xpNeed} XP', style: const TextStyle(color: C.muted, fontSize: 10)),
                  Text('${st.streak} 🔥', style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 11)),
                ]),
              ]),
            ),
            const SizedBox(height: 12),
            Glass(
              radius: 22,
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const Expanded(child: Text('Цель на сегодня', style: TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 14))),
                  Text('$todayXp / $goal XP', style: const TextStyle(color: C.muted, fontWeight: FontWeight.w800, fontSize: 10)),
                ]),
                const SizedBox(height: 9),
                Bar(todayXp / goal, color: C.green, height: 11),
                const SizedBox(height: 10),
                const Text('Небольшие шаги каждый день помогают заметить свой прогресс.',
                    style: TextStyle(color: C.muted, fontSize: 11, height: 1.35)),
              ]),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: Glass(
                radius: 22,
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Row(children: [
                    Icon(Icons.flag_rounded, color: C.gold, size: 19),
                    SizedBox(width: 6),
                    Text('Задания дня', style: TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 14)),
                  ]),
                  const SizedBox(height: 8),
                  if (quests.isEmpty)
                    const Expanded(child: Center(child: Text('Здесь появятся твои задания',
                        textAlign: TextAlign.center, style: TextStyle(color: C.muted, fontSize: 11))))
                  else
                    for (final q in quests.take(3))
                      Padding(
                        padding: const EdgeInsets.only(bottom: 9),
                        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Icon((q as Map)['done'] == true ? Icons.check_circle_rounded : Icons.circle_outlined,
                              color: q['done'] == true ? C.good : C.muted, size: 17),
                          const SizedBox(width: 7),
                          Expanded(child: Text('${q['title']}', maxLines: 2, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: C.ink, fontSize: 10, fontWeight: FontWeight.w700))),
                          Text('+${q['xp']}', style: const TextStyle(color: C.gold, fontSize: 10, fontWeight: FontWeight.w900)),
                        ]),
                      ),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            Glass(
              radius: 20,
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
              child: Row(children: [
                const ArtImage('assets/ui/gem.png', width: 25, height: 25),
                const SizedBox(width: 8),
                const Expanded(child: Text('Твои кристаллы', style: TextStyle(color: C.ink, fontSize: 11, fontWeight: FontWeight.w800))),
                Text('${st.gems}', style: const TextStyle(color: C.ink, fontSize: 16, fontWeight: FontWeight.w900)),
              ]),
            ),
          ]);
        },
      );
}

class _BottomBar extends StatelessWidget {
  final double s;
  final int tab;
  final ValueChanged<int> onSelect;
  const _BottomBar({required this.s, required this.tab, required this.onSelect});

  Widget _item(int index, double w, Widget visual, {double underline = 34}) {
    final active = index == 8 ? tab >= 4 : tab == index;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () { GameSounds.tap(); onSelect(index); },
      child: SizedBox(
        width: w * s,
        height: 76 * s,
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          visual,
          Container(width: underline * s, height: 3 * s,
              decoration: BoxDecoration(color: active ? C.gold : Colors.transparent, borderRadius: BorderRadius.circular(3 * s))),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [alpha(Colors.white, 0), alpha(Colors.white, .94)]),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          _item(0, 46, Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 42 * s, height: 39 * s,
                decoration: BoxDecoration(color: const Color(0xFFE9E5FF), borderRadius: BorderRadius.circular(15 * s),
                    border: Border.all(color: const Color(0xFFCFC6FF), width: 1.5 * s)),
                child: Icon(Icons.home_rounded, size: 26 * s, color: const Color(0xFF5848C8))),
            Text('Главная', style: TextStyle(fontSize: 9 * s, fontWeight: FontWeight.w800, color: const Color(0xFF5143B8))),
          ])),
          _item(1, 58, ArtImage('assets/buttons/stats.png', width: 58 * s, height: 58 * s)),
          _item(2, 130, ArtImage('assets/buttons/play.png', width: 130 * s, height: 64 * s), underline: 54),
          _item(3, 66, ArtImage('assets/buttons/achievements.png', width: 66 * s, height: 58 * s)),
          _item(8, 58, Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 42 * s, height: 39 * s, decoration: BoxDecoration(color: const Color(0xFFE8F0FF), borderRadius: BorderRadius.circular(15 * s), border: Border.all(color: const Color(0xFFC9D9FF), width: 1.5 * s)), child: Icon(Icons.grid_view_rounded, size: 23 * s, color: const Color(0xFF5267C8))),
            Text('Ещё', style: TextStyle(fontSize: 9 * s, fontWeight: FontWeight.w800, color: const Color(0xFF5143B8))),
          ])),
        ]),
      );
}
