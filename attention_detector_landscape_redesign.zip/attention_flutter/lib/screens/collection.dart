import 'package:material_ui/material_ui.dart';
import '../core/app_state.dart';
import '../core/models.dart';
import '../ui/kit.dart';

class CollectionScreen extends StatelessWidget {
  const CollectionScreen({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          return ScreenScaffold(
            title: 'Коллекция',
            subtitle: '${st.owned.length} / ${kPetCatalog.length}',
            child: LayoutBuilder(builder: (context, box) => GridView.count(
              padding: const EdgeInsets.all(12),
              crossAxisCount: box.maxWidth >= 700 ? 5 : 3,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: box.maxWidth >= 700 ? 1.05 : 0.82,
              children: [
                for (final base in kPetCatalog) _cell(context, st, base),
              ],
            )),
          );
        },
      );

  Widget _cell(BuildContext context, AppState st, Pet base) {
    Pet? mine;
    for (final p in st.owned) {
      if (p.id == base.id) mine = p;
    }
    final active = mine != null && st.activeId == mine.id;
    return GestureDetector(
      onTap: mine == null
          ? () => toast('🔒', 'Закрыто', 'Достань это яйцо в магазине — и питомец твой!')
          : () => _details(context, mine!),
      child: Glass(
        radius: 18,
        padding: const EdgeInsets.all(8),
        color: active ? const Color(0xFFE3F7EF) : null,
        child: Column(children: [
          Expanded(
            child: mine == null
                ? ColorFiltered(
                    colorFilter: const ColorFilter.mode(Color(0xFF9AA8C8), BlendMode.srcATop),
                    child: PetImage(pet: base, size: 90),
                  )
                : PetImage(pet: mine, size: 90),
          ),
          Text(mine == null ? '???' : mine.name,
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: C.ink, fontWeight: FontWeight.w800, fontSize: 12)),
          Text(mine == null ? base.rarity : 'Ур. ${mine.level}${active ? '  ✓' : ''}',
              style: const TextStyle(color: C.muted, fontSize: 10)),
        ]),
      ),
    );
  }

  void _details(BuildContext context, Pet pet) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (c) => ListenableBuilder(
        listenable: AppState.I,
        builder: (c, _) {
          final st = AppState.I;
          final p = st.owned.firstWhere((x) => x.id == pet.id);
          final isActive = st.activeId == p.id;
          return Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Color(0xFFF1F7FF),
              borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              PetImage(pet: p, size: 150),
              Text(p.name, style: const TextStyle(color: C.ink, fontSize: 22, fontWeight: FontWeight.w900)),
              Text('${p.rarity} · Уровень ${p.level} · Эволюция ${p.evolution}/2',
                  style: const TextStyle(color: C.muted, fontSize: 12)),
              const SizedBox(height: 10),
              Bar(p.level >= 99 ? 1 : p.xpInLevel / p.xpNeeded, color: C.gold),
              Text(p.level >= 99 ? 'Максимальный уровень' : '${p.xpInLevel} / ${p.xpNeeded} XP', style: const TextStyle(color: C.muted, fontSize: 11)),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                  child: GameButton(isActive ? 'Выбран' : 'Выбрать', height: 46,
                      onTap: isActive ? null : () => st.selectPet(p.id)),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: GameButton('Эволюция', height: 46,
                      colors: const [Color(0xFFFFD86B), Color(0xFFF4B72D), Color(0xFFD99A10)], onTap: () async {
                    final err = await st.evolve(p.id);
                    if (err != null) {
                      toast('🔒', 'Пока рано', err);
                    } else {
                      toast('✨', 'Эволюция завершена!', '${p.name} получил новую звезду');
                    }
                  }),
                ),
              ]),
            ]),
          );
        },
      ),
    );
  }
}
