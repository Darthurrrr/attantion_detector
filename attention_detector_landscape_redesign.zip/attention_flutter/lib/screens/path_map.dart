import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';
import '../core/app_state.dart';
import '../core/models.dart';
import '../ui/kit.dart';
import '../tests/host.dart';
import 'tests_hub.dart';

/// В каждой главе четыре этапа. После них маршрут переходит в следующий мир.
/// Четыре кристалла первой карты остаются частью исходной иллюстрации; новых не добавляем.
class PathTab extends StatelessWidget {
  const PathTab({super.key});

  static const _tests = [
    'reaction', 'schulte', 'stroop', 'memory', 'gonogo', 'nback', 'simon', 'odd',
  ];
  static const _levelsPerChapter = 4;

  // В первой главе узлы точно соответствуют четырём уже нарисованным кристаллам.
  // Новые кристаллы на эту карту не добавляются.
  static const _crystalValleyNodes = <Offset>[
    Offset(.13, .68), Offset(.37, .39), Offset(.64, .66), Offset(.87, .34),
  ];

  // Во второй главе маршрут переходит на другую существующую иллюстрацию — зелёные острова.
  // Это четыре отметки этапов на островах, а не новые кристаллы.
  static const _greenIslandsNodes = <Offset>[
    Offset(.13, .36), Offset(.38, .68), Offset(.64, .34), Offset(.87, .65),
  ];

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final completed = AppState.I.pathProgress;
          if (completed >= _tests.length) return const _JourneyComplete();
          final globalLevel = completed + 1;
          final chapter = ((globalLevel - 1) ~/ _levelsPerChapter) + 1;
          final activeIndex = (globalLevel - 1) % _levelsPerChapter;
          final testIndex = (globalLevel - 1) % _tests.length;
          final activeTest = _tests[testIndex];
          final doneInChapter = activeIndex;

          return LayoutBuilder(builder: (context, box) {
            if (box.maxWidth >= 980) {
              return Row(children: [
                Expanded(child: _mapArea(chapter, completed)),
                const SizedBox(width: 16),
                SizedBox(width: 270, child: _chapterPanel(chapter, activeIndex, completed, activeTest, context)),
              ]);
            }
            return Column(children: [
              _header(chapter, doneInChapter, completed),
              const SizedBox(height: 7),
              Expanded(child: _mapArea(chapter, completed)),
            ]);
          });
        },
      );

  Widget _header(int chapter, int doneInChapter, int completed) => Glass(
        radius: 20,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF8BD5FF), Color(0xFF5487EB)]),
              borderRadius: BorderRadius.circular(15),
              boxShadow: [BoxShadow(color: alpha(const Color(0xFF3979CB), .22), blurRadius: 8, offset: const Offset(0, 3))],
            ),
            child: const Icon(Icons.route_rounded, color: Colors.white, size: 24),
          ),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Путь · Глава $chapter',
                style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 14)),
            Text('Этап ${doneInChapter + 1} из $_levelsPerChapter · пройдено $completed из 8',
                style: const TextStyle(color: C.muted, fontWeight: FontWeight.w700, fontSize: 10)),
          ])),
          SizedBox(
            width: 54,
            height: 38,
            child: Stack(alignment: Alignment.center, children: [
              CircularProgressIndicator(value: doneInChapter / _levelsPerChapter, strokeWidth: 5,
                  backgroundColor: const Color(0xFFDCE9F9), color: C.green),
              Text('$doneInChapter/$_levelsPerChapter', style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 9)),
            ]),
          ),
        ]),
      );

  Widget _mapArea(int chapter, int completed) =>
      LayoutBuilder(builder: (context, box) {
        final w = box.maxWidth;
        final h = box.maxHeight;
        final mapW = w;
        final mapH = h;
        const left = 0.0;
        final scale = math.min(w / 900, h / 420).toDouble();
        final firstWorld = chapter.isOdd;
        final background = firstWorld
            ? 'assets/backgrounds/home_landscape.jpg'
            : 'assets/backgrounds/world_pages.png';
        final nodes = firstWorld ? _crystalValleyNodes : _greenIslandsNodes;
        final children = <Widget>[
          Positioned(left: left, top: 0, width: mapW, height: mapH,
              child: ArtImage(background, fit: BoxFit.cover)),
          Positioned(left: left, top: 0, width: mapW, height: mapH,
              child: CustomPaint(painter: _MapTrailPainter(points: nodes))),
        ];

        for (var i = 0; i < _levelsPerChapter; i++) {
          final globalNumber = (chapter - 1) * _levelsPerChapter + i + 1;
          final testIndex = globalNumber - 1;
          final done = globalNumber <= completed;
          final active = globalNumber == completed + 1;
          final unlocked = done || active;
          final center = nodes[i];
          final cx = left + center.dx * mapW;
          final cy = center.dy * mapH;
          final stars = AppState.I.pathStars[globalNumber] ?? (done ? 1 : 0);

          final nodeSize = (active ? 66.0 : 58.0) * scale.clamp(.78, 1.25);
          children.add(Positioned(
            left: cx - nodeSize / 2,
            top: cy - nodeSize / 2,
            width: nodeSize,
            height: nodeSize,
            child: GestureDetector(
              onTap: () {
                if (unlocked) {
                  runTest(context, _tests[testIndex], pathMode: true, pathStageNumber: globalNumber);
                } else {
                  toast('🔒', 'Этот этап пока закрыт', 'Сначала заверши предыдущую тренировку');
                }
              },
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: !unlocked
                      ? const [Color(0xFF8A83A8), Color(0xFF51466F)]
                      : active
                        ? const [Color(0xFFFFE58A), Color(0xFFE99A22)]
                        : const [Color(0xFFB78AFF), Color(0xFF7143C5)]),
                  border: Border.all(color: active ? const Color(0xFFFFF4C6) : Colors.white, width: 3),
                  boxShadow: [BoxShadow(color: alpha(active ? const Color(0xFFFFC64B) : const Color(0xFF59319A), .42), blurRadius: active ? 20 : 11, offset: const Offset(0, 5))],
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(!unlocked ? Icons.lock_rounded : done ? Icons.check_rounded : Icons.star_rounded,
                    color: Colors.white, size: nodeSize * .34),
                  Text('$globalNumber', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: nodeSize * .25)),
                ]),
              ),
            ),
          ));
          if (done) {
            children.add(Positioned(
              left: cx - 25 * scale,
              top: cy + nodeSize * .52,
              width: 50 * scale,
              height: 16 * scale,
              child: IgnorePointer(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(3, (star) => Icon(
                    Icons.star_rounded,
                    size: 14 * scale,
                    color: star < stars ? const Color(0xFFFFC83D) : const Color(0xFFB8C6D9),
                  )),
                ),
              ),
            ));
          }
        }

        return ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(clipBehavior: Clip.hardEdge, children: children),
        );
      });

  Widget _chapterPanel(int chapter, int activeIndex, int completed, String activeTest, BuildContext context) {
    final title = kTestNames[activeTest] ?? activeTest;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _header(chapter, activeIndex, completed),
      const SizedBox(height: 12),
      Expanded(
        child: Glass(
          radius: 24,
          padding: const EdgeInsets.all(17),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('ТВОЙ СЛЕДУЮЩИЙ ЭТАП',
                style: TextStyle(color: C.muted, fontWeight: FontWeight.w900, fontSize: 10, letterSpacing: .7)),
            const SizedBox(height: 12),
            Container(
              width: 62, height: 62,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFFE6F3FF),
                borderRadius: BorderRadius.circular(21),
                border: Border.all(color: const Color(0xFFB9D9FF), width: 1.5),
              ),
              child: Text(kTestEmoji[activeTest] ?? '🎯', style: const TextStyle(fontSize: 34)),
            ),
            const SizedBox(height: 11),
            Text(title, style: const TextStyle(color: C.ink, fontSize: 19, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Text(kTestDesc[activeTest] ?? '',
                style: const TextStyle(color: C.muted, fontSize: 12, height: 1.45)),
            const Spacer(),
            Row(children: [
              const Icon(Icons.lock_open_rounded, color: C.good, size: 17),
              const SizedBox(width: 6),
              Text('Этап ${completed + 1} доступен',
                  style: const TextStyle(color: C.good, fontWeight: FontWeight.w800, fontSize: 11)),
            ]),
            const SizedBox(height: 12),
            GameButton('Начать этап', onTap: () => runTest(context, activeTest, pathMode: true, pathStageNumber: completed + 1)),
            const SizedBox(height: 12),
            const Text('Впереди ещё много приключений. После четвёртого этапа откроется новый мир.',
                style: TextStyle(color: C.muted, fontSize: 10, height: 1.4)),
          ]),
        ),
      ),
    ]);
  }
}

class _CrystalCrackPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final lines = <Path>[
      Path()..moveTo(size.width * .51, size.height * .08)
        ..lineTo(size.width * .43, size.height * .38)
        ..lineTo(size.width * .60, size.height * .54)
        ..lineTo(size.width * .47, size.height * .91),
      Path()..moveTo(size.width * .43, size.height * .38)
        ..lineTo(size.width * .20, size.height * .56),
      Path()..moveTo(size.width * .60, size.height * .54)
        ..lineTo(size.width * .82, size.height * .70),
    ];
    final shadow = Paint()..color = const Color(0xA84F5BA8)..style = PaintingStyle.stroke
      ..strokeWidth = 1.7..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round;
    final shine = Paint()..color = const Color(0xEFFFFFFF)..style = PaintingStyle.stroke
      ..strokeWidth = 1.05..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round;
    for (final path in lines) {
      canvas.drawPath(path, shadow);
      canvas.drawPath(path.shift(const Offset(-.5, -.5)), shine);
    }
  }

  @override
  bool shouldRepaint(covariant _CrystalCrackPainter oldDelegate) => false;
}

class _MapTrailPainter extends CustomPainter {
  final List<Offset> points;
  const _MapTrailPainter({required this.points});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xDDF8FCFF)..style = PaintingStyle.fill;
    for (var i = 0; i < points.length - 1; i++) {
      final a = Offset(points[i].dx * size.width, points[i].dy * size.height);
      final b = Offset(points[i + 1].dx * size.width, points[i + 1].dy * size.height);
      final distance = (b - a).distance;
      final count = (distance / 13).round().clamp(2, 50);
      for (var j = 1; j < count; j++) {
        final t = j / count;
        final p = Offset(a.dx + (b.dx - a.dx) * t, a.dy + (b.dy - a.dy) * t);
        canvas.drawCircle(p, 1.6, paint);
      }
    }
  }
  @override
  bool shouldRepaint(covariant _MapTrailPainter oldDelegate) => oldDelegate.points != points;
}


class _JourneyComplete extends StatelessWidget {
  const _JourneyComplete();

  @override
  Widget build(BuildContext context) => Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 560),
          child: Glass(
            radius: 30,
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const PetImage(art: 'robot', size: 118),
              const SizedBox(height: 8),
              const Text('Ты прошёл оба мира!',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: C.ink, fontSize: 25, fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              const Text('Все 8 этапов приключения позади. Теперь можно продолжать тренировки в свободном режиме и улучшать свои результаты.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: C.muted, fontSize: 13, height: 1.45)),
              const SizedBox(height: 18),
              GameButton('Выбрать тренировку', onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const TestsHubScreen()))),
              const SizedBox(height: 9),
              const Text('8 / 8 этапов завершено  ✨',
                  style: TextStyle(color: C.good, fontWeight: FontWeight.w900, fontSize: 12)),
            ]),
          ),
        ),
      );
}
