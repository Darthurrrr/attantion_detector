import 'package:material_ui/material_ui.dart';
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/models.dart';
import '../ui/kit.dart';
import 'tests_hub.dart';

/// Вкладка «Статистика»: средние баллы по тестам и последние результаты.
class HistoryTab extends StatefulWidget {
  const HistoryTab({super.key});
  @override
  State<HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends State<HistoryTab> {
  List<dynamic> _rows = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await Api.history(AppState.I.uid);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _error = r.ok ? null : r.error;
      _rows = r.list;
    });
  }

  Future<void> _clear() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Очистить историю?'),
        content: const Text('Все результаты тестов будут удалены.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Отмена')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Удалить')),
        ],
      ),
    );
    if (ok != true) return;
    await Api.clearHistory(AppState.I.uid);
    await AppState.I.refresh();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final tests = Map<String, dynamic>.from((AppState.I.summary['tests'] ?? {}) as Map);
    return SafeArea(
      bottom: false,
      child: ListView(padding: const EdgeInsets.fromLTRB(14, 8, 14, 18), children: [
        PageBanner(
          title: 'Твоя статистика',
          subtitle: 'Смотри, как меняются внимание и скорость реакции',
          icon: Icons.insights_rounded,
          trailing: _rows.isNotEmpty ? IconButton(onPressed: _clear, icon: const Icon(Icons.delete_outline_rounded, color: C.muted)) : null,
        ),
        const SizedBox(height: 10),
        Row(children: [
          _summaryTile('🎯', '${AppState.I.summary['total'] ?? _rows.length}', 'тренировок'),
          const SizedBox(width: 8),
          _summaryTile('⭐', '${AppState.I.summary['overall'] ?? '—'}', 'общий балл'),
          const SizedBox(width: 8),
          _summaryTile('🔥', '${AppState.I.streak}', 'серия дней'),
        ]),
        const SizedBox(height: 12),
        if (_loading) const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator())),
        if (_error != null) Glass(child: Text(_error!, style: const TextStyle(color: C.bad, fontWeight: FontWeight.w700))),
        if (!_loading && _error == null && _rows.isEmpty)
          Glass(
            radius: 24,
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              const PetImage(art: 'robot', size: 108),
              const Text('Твоя история ещё чистая',
                  style: TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 17)),
              const SizedBox(height: 5),
              const Text('Пройди первую тренировку — и здесь появятся результаты, рекорды и динамика.',
                  textAlign: TextAlign.center, style: TextStyle(color: C.muted, fontSize: 12, height: 1.4)),
              const SizedBox(height: 14),
              SizedBox(width: 230, child: GameButton('Выбрать тренировку', onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const TestsHubScreen())))),
            ]),
          ),
        if (tests.isNotEmpty) ...[
          const Text('По тестам', style: TextStyle(color: C.ink, fontSize: 15, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          for (final e in tests.entries)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Glass(
                child: Row(children: [
                  Text(kTestEmoji[e.key] ?? '🎯', style: const TextStyle(fontSize: 24)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(kTestNames[e.key] ?? e.key,
                          style: const TextStyle(color: C.ink, fontWeight: FontWeight.w800)),
                      Text('попыток: ${(e.value as Map)['count']}  ·  лучший: ${(e.value as Map)['best']}',
                          style: const TextStyle(color: C.muted, fontSize: 12)),
                    ]),
                  ),
                  Text('${(e.value as Map)['avg']}',
                      style: TextStyle(color: scoreColor((e.value as Map)['avg'] as num), fontSize: 22, fontWeight: FontWeight.w900)),
                ]),
              ),
            ),
          const SizedBox(height: 8),
        ],
        if (_rows.isNotEmpty) ...[
          const Text('Последние результаты', style: TextStyle(color: C.ink, fontSize: 15, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          for (final r in _rows)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Glass(
                radius: 16,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                child: Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(kTestNames[(r as Map)['test']] ?? '${r['test']}',
                          style: const TextStyle(color: C.ink, fontWeight: FontWeight.w700)),
                      Text('${r['created_at']}'.replaceFirst('T', ' ').split('.').first,
                          style: const TextStyle(color: C.muted, fontSize: 11)),
                    ]),
                  ),
                  Text('${r['score']}',
                      style: TextStyle(color: scoreColor(r['score'] as num), fontSize: 20, fontWeight: FontWeight.w900)),
                ]),
              ),
            ),
        ],
        const SizedBox(height: 16),
      ]),
    );
  }

  Widget _summaryTile(String emoji, String value, String label) => Expanded(
        child: Glass(
          radius: 17,
          padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 4),
          child: Column(children: [
            Text(emoji, style: const TextStyle(fontSize: 19)),
            const SizedBox(height: 3),
            Text(value, style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 17)),
            Text(label, style: const TextStyle(color: C.muted, fontSize: 9, fontWeight: FontWeight.w700)),
          ]),
        ),
      );
}
