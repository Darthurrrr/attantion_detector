import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';
import '../core/app_state.dart';
import '../ui/kit.dart';

/// Вкладка «Достижения»: награды и шляпки робота.
class AwardsTab extends StatelessWidget {
  const AwardsTab({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final ach = (st.progress['achievements'] ?? []) as List;
          final hats = (st.progress['hats'] ?? []) as List;
          return SafeArea(
            bottom: false,
            child: ListView(padding: const EdgeInsets.fromLTRB(14, 8, 14, 18), children: [
              PageBanner(
                title: 'Твои достижения',
                subtitle: 'Каждая маленькая победа остаётся с тобой',
                icon: Icons.emoji_events_rounded,
                trailing: Text('${st.progress['unlocked'] ?? 0}/${st.progress['total'] ?? 0}',
                    style: const TextStyle(color: C.ink, fontSize: 12, fontWeight: FontWeight.w900)),
              ),
              const SizedBox(height: 10),
              Glass(
                radius: 20,
                padding: const EdgeInsets.all(13),
                child: Row(children: [
                  const Icon(Icons.workspace_premium_rounded, color: C.gold, size: 28),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Коллекция побед', style: TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 13)),
                    const SizedBox(height: 6),
                    Bar(
                      (((st.progress['unlocked'] ?? 0) as num).toDouble() /
                              math.max(1.0, ((st.progress['total'] ?? 1) as num).toDouble()))
                          .clamp(0.0, 1.0).toDouble(),
                      color: C.gold,
                      height: 9,
                    ),
                  ])),
                ]),
              ),
              const SizedBox(height: 12),
              const Text('Значки', style: TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 15)),
              const SizedBox(height: 7),
              for (final a in ach)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Opacity(
                    opacity: (a as Map)['unlocked'] == true ? 1 : 0.5,
                    child: Glass(
                      child: Row(children: [
                        Container(
                          width: 46, height: 46, alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: alpha(hexColor('${a['color']}'), 0.18), shape: BoxShape.circle),
                          child: Text(a['unlocked'] == true ? '${a['emoji']}' : '🔒', style: const TextStyle(fontSize: 22)),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('${a['title']}', style: const TextStyle(color: C.ink, fontWeight: FontWeight.w800)),
                            Text('${a['desc']}', style: const TextStyle(color: C.muted, fontSize: 12)),
                          ]),
                        ),
                      ]),
                    ),
                  ),
                ),
              if (hats.isNotEmpty) ...[
                const SizedBox(height: 12),
                const Text('Шляпки робота', style: TextStyle(color: C.ink, fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                for (final h in hats)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Glass(
                      child: Row(children: [
                        const Text('🎩', style: TextStyle(fontSize: 26)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('${(h as Map)['name']}', style: const TextStyle(color: C.ink, fontWeight: FontWeight.w800)),
                            Text('откроется на ${h['level']} уровне', style: const TextStyle(color: C.muted, fontSize: 12)),
                          ]),
                        ),
                        if (h['unlocked'] == true)
                          GestureDetector(
                            onTap: () async {
                              final on = st.user?.hat == h['key'];
                              final err = await st.setHat(on ? '' : '${h['key']}');
                              if (err != null) toast('⚠️', 'Не получилось', err);
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: st.user?.hat == h['key'] ? C.green : const Color(0xFFE8F0FF),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Text(st.user?.hat == h['key'] ? 'Надета' : 'Надеть',
                                  style: TextStyle(
                                      color: st.user?.hat == h['key'] ? Colors.white : C.ink,
                                      fontWeight: FontWeight.w800, fontSize: 12)),
                            ),
                          )
                        else
                          const Icon(Icons.lock_rounded, color: C.muted),
                      ]),
                    ),
                  ),
              ],
              const SizedBox(height: 16),
            ]),
          );
        },
      );
}
