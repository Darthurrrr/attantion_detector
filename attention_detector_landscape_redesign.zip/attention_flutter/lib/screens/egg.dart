import 'dart:async';
import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';
import '../core/app_state.dart';
import '../core/game_sounds.dart';
import '../core/models.dart';
import '../ui/kit.dart';

/// Яйцо: 8 нажатий, потом появляется питомец (редкость зависит от вида яйца).
class EggScreen extends StatefulWidget {
  const EggScreen({super.key});
  @override
  State<EggScreen> createState() => _EggScreenState();
}

class _EggScreenState extends State<EggScreen> {
  int _taps = 0;
  bool _revealing = false;

  void _tap() {
    if (_taps >= 8 || _revealing) return;
    setState(() => _taps++);
    if (_taps >= 8) {
      _revealing = true;
      Timer(const Duration(milliseconds: 850), _reveal);
    }
  }

  Future<void> _reveal() async {
    final pools = kEggPools[AppState.I.pendingEgg] ?? ['Обычный', 'Редкий', 'Эпический'];
    var pool = kPetCatalog.where((p) => pools.contains(p.rarity)).toList();
    if (pool.isEmpty) pool = kPetCatalog;
    final pet = pool[math.Random().nextInt(pool.length)];
    AppState.I.pendingEgg = 'common';
    if (!mounted) return;
    // Питомец сохраняется только по кнопке «Забрать» на следующем экране.
    GameSounds.success();
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => HatchedScreen(pet: pet)),
    );
    if (mounted) setState(() => _revealing = false);
  }

  @override
  Widget build(BuildContext context) {
    final stage = math.min(8, (_taps ~/ 2) * 2);
    return Scaffold(
      body: Stack(fit: StackFit.expand, children: [
        const ArtImage('assets/backgrounds/home_main.png', fit: BoxFit.cover),
        Container(color: alpha(Colors.white, 0.25)),
        SafeArea(
          child: Column(children: [
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: TextButton(
                  onPressed: AppState.I.pet != null ? () => Navigator.of(context).maybePop() : null,
                  child: AppState.I.pet != null ? const Text('Пропустить') : const SizedBox.shrink(),
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text('Нажимай на яйцо ещё раз!',
                textAlign: TextAlign.center,
                style: TextStyle(color: C.ink, fontSize: 24, fontWeight: FontWeight.w900)),
            const Spacer(),
            GestureDetector(
              onTap: _tap,
              child: AnimatedScale(
                scale: 1.0 + math.min(0.16, _taps * 0.02),
                duration: const Duration(milliseconds: 180),
                curve: Curves.easeOutBack,
                child: ArtImage('assets/ui/egg_$stage.png', width: 260, height: 260),
              ),
            ),
            const Spacer(),
            Glass(
              radius: 28,
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 10),
              child: Text('$_taps / 8',
                  style: const TextStyle(color: Color(0xFF3B3350), fontSize: 22, fontWeight: FontWeight.w900)),
            ),
            const SizedBox(height: 40),
          ]),
        ),
      ]),
    );
  }
}

class HatchedScreen extends StatelessWidget {
  final Pet pet;
  const HatchedScreen({super.key, required this.pet});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Stack(fit: StackFit.expand, children: [
          const ArtImage('assets/backgrounds/home_main.png', fit: BoxFit.cover),
          SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('Ура!', style: TextStyle(color: C.ink, fontSize: 34, fontWeight: FontWeight.w900)),
                  const Text('Ты получил питомца!',
                      style: TextStyle(color: C.ink, fontSize: 18, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 16),
                  Glass(
                    radius: 40,
                    padding: const EdgeInsets.all(20),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      PetImage(pet: pet, size: 220),
                      Text(pet.name, style: const TextStyle(color: C.ink, fontSize: 24, fontWeight: FontWeight.w900)),
                      Text(pet.rarity, style: const TextStyle(color: C.muted, fontSize: 13)),
                    ]),
                  ),
                  const SizedBox(height: 22),
                  SizedBox(
                    width: 280,
                    child: GameButton('Забрать питомца', onTap: () async {
                      await AppState.I.storePet(pet);
                      if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
                    }),
                  ),
                ]),
              ),
            ),
          ),
        ]),
      );
}
