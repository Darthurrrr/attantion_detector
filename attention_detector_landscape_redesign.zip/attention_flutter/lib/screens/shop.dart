import 'package:material_ui/material_ui.dart';
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/game_sounds.dart';
import '../ui/kit.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});
  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  bool _loading = true;
  bool _busy = false;
  int _quantity = 1;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await Api.shop();
    await AppState.I.refresh();
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _buy() async {
    final st = AppState.I;
    final total = _quantity * 60;
    if (st.gems < total || _busy) return;
    setState(() => _busy = true);
    var bought = 0;
    String? error;
    for (var i = 0; i < _quantity; i++) {
      final r = await Api.buy(st.uid, 'egg_universal');
      if (!r.ok) { error = r.error; break; }
      bought++;
    }
    if (bought > 0) await st.addUniversalEggs(bought);
    await st.refresh();
    if (!mounted) return;
    setState(() => _busy = false);
    if (error != null) {
      toast('⚠️', 'Покупка прервана', bought > 0 ? 'Куплено яиц: $bought. $error' : error);
    } else {
      GameSounds.success();
      toast('🥚', 'Покупка успешна', 'В инвентарь добавлено яиц: $bought');
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final maxQuantity = st.gems ~/ 60;
          return ScreenScaffold(
            title: 'Магазин',
            subtitle: 'Покупай универсальные яйца и храни их до призыва',
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : LayoutBuilder(builder: (context, box) => Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 850),
                      child: Row(children: [
                        Expanded(
                          flex: 5,
                          child: Glass(
                            radius: 28,
                            padding: const EdgeInsets.all(16),
                            child: Row(children: [
                              Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                const Text('🥚', style: TextStyle(fontSize: 84)),
                                const SizedBox(height: 8),
                                const Text('Универсальное яйцо', textAlign: TextAlign.center,
                                  style: TextStyle(color: C.ink, fontSize: 20, fontWeight: FontWeight.w900)),
                                const SizedBox(height: 5),
                                const Text('Может подарить питомца любой редкости', textAlign: TextAlign.center,
                                  style: TextStyle(color: C.muted, fontSize: 12)),
                                const SizedBox(height: 12),
                                Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                                  decoration: BoxDecoration(color: const Color(0xFFF0E5FF), borderRadius: BorderRadius.circular(18)),
                                  child: const Text('60 💎 за 1 яйцо', style: TextStyle(color: C.ink, fontWeight: FontWeight.w900))),
                              ])),
                              const SizedBox(width: 12),
                              Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                const Text('Количество', style: TextStyle(color: C.ink, fontWeight: FontWeight.w900)),
                                const SizedBox(height: 12),
                                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                  _stepButton(Icons.remove_rounded, () => setState(() => _quantity = (_quantity - 1).clamp(1, 99))),
                                  Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text('$_quantity',
                                    style: const TextStyle(color: C.ink, fontSize: 28, fontWeight: FontWeight.w900))),
                                  _stepButton(Icons.add_rounded, maxQuantity > _quantity ? () => setState(() => _quantity++) : null),
                                ]),
                                const SizedBox(height: 12),
                                Text('Итого: ${_quantity * 60} 💎', style: const TextStyle(color: C.ink, fontSize: 17, fontWeight: FontWeight.w900)),
                                Text('Баланс: ${st.gems} 💎', style: const TextStyle(color: C.muted, fontSize: 11)),
                                const SizedBox(height: 12),
                                SizedBox(width: double.infinity, child: GameButton(_busy ? 'Покупка…' : 'Купить', height: 48,
                                  onTap: !_busy && maxQuantity >= _quantity ? _buy : null,
                                  colors: const [Color(0xFFFFD978), Color(0xFFF2AE35), Color(0xFFD9871C)])),
                                if (maxQuantity == 0) const Padding(padding: EdgeInsets.only(top: 7), child: Text('Недостаточно кристаллов', style: TextStyle(color: C.bad, fontSize: 10))),
                              ])),
                            ]),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(flex: 2, child: Glass(radius: 24, child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          const Icon(Icons.inventory_2_rounded, size: 38, color: Color(0xFF8753D1)),
                          const SizedBox(height: 8),
                          const Text('В инвентаре', style: TextStyle(color: C.muted, fontSize: 11)),
                          Text('${st.universalEggs}', style: const TextStyle(color: C.ink, fontSize: 32, fontWeight: FontWeight.w900)),
                          const Text('яиц', style: TextStyle(color: C.muted, fontSize: 11)),
                          const SizedBox(height: 8),
                          const Text('Яйца не открываются автоматически после покупки', textAlign: TextAlign.center,
                            style: TextStyle(color: C.muted, fontSize: 10)),
                        ]))),
                      ]),
                    ),
                  )),
          );
        },
      );

  Widget _stepButton(IconData icon, VoidCallback? onTap) => Material(
    color: onTap == null ? const Color(0xFFE5DDF0) : const Color(0xFF8050C9),
    borderRadius: BorderRadius.circular(13),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(13),
      child: SizedBox(width: 36, height: 36, child: Icon(icon, color: onTap == null ? C.muted : Colors.white))),
  );
}
