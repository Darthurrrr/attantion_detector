import 'dart:async';
import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';
import 'package:flutter/services.dart';
import '../core/game_sounds.dart';
import '../ui/kit.dart';

typedef Done = void Function(Map<String, dynamic> metrics);

Widget buildGame(String test, Map<String, int> diff, Done onDone, {Key? key}) {
  switch (test) {
    case 'reaction':
      return ReactionGame(key: key, onDone: onDone);
    case 'stroop':
      return StroopGame(key: key, trials: diff['stroop_trials'] ?? 10, onDone: onDone);
    case 'schulte':
      return SchulteGame(key: key, size: diff['schulte_size'] ?? 4, onDone: onDone);
    case 'memory':
      return MemoryGame(key: key, start: diff['memory_start'] ?? 4, onDone: onDone);
    case 'gonogo':
      return GoNoGoGame(key: key, trials: diff['gonogo_trials'] ?? 24, onDone: onDone);
    case 'nback':
      return NBackGame(key: key, n: diff['nback_n'] ?? 1, onDone: onDone);
    case 'simon':
      return SimonGame(key: key, start: diff['simon_start'] ?? 3, onDone: onDone);
    case 'odd':
      return OddGame(key: key, size: diff['odd_size'] ?? 3, onDone: onDone);
  }
  return const Center(child: Text('Неизвестный тест'));
}

final _rnd = math.Random();

Widget _hint(String text) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Text(text,
          textAlign: TextAlign.center, style: const TextStyle(color: C.muted, fontSize: 14, fontWeight: FontWeight.w600)),
    );

// ---------------------------------------------------------------- Реакция
class ReactionGame extends StatefulWidget {
  final Done onDone;
  const ReactionGame({super.key, required this.onDone});
  @override
  State<ReactionGame> createState() => _ReactionGameState();
}

class _ReactionGameState extends State<ReactionGame> {
  static const attempts = 5;
  String _phase = 'wait'; // wait | go | early | ok
  final List<int> _times = [];
  int _false = 0;
  Timer? _t;
  final _sw = Stopwatch();

  @override
  void initState() {
    super.initState();
    _schedule();
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  void _schedule() {
    _t?.cancel();
    _t = Timer(Duration(milliseconds: 1200 + _rnd.nextInt(2400)), () {
      if (!mounted) return;
      setState(() => _phase = 'go');
      _sw
        ..reset()
        ..start();
    });
  }

  void _arm() {
    if (!mounted) return;
    setState(() => _phase = 'wait');
    _schedule();
  }

  void _tap() {
    GameSounds.tap();
    if (_phase == 'wait') {
      _false++;
      _t?.cancel();
      setState(() => _phase = 'early');
      _t = Timer(const Duration(milliseconds: 800), _arm);
    } else if (_phase == 'go') {
      _sw.stop();
      _times.add(_sw.elapsedMilliseconds);
      if (_times.length >= attempts) {
        final avg = _times.reduce((a, b) => a + b) / _times.length;
        widget.onDone({
          'avg_ms': avg,
          'false_starts': _false,
          'attempts': _times.length,
          'best_ms': _times.reduce(math.min),
        });
        return;
      }
      setState(() => _phase = 'ok');
      _t = Timer(const Duration(milliseconds: 700), _arm);
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _phase == 'go'
        ? const Color(0xFF2FC25B)
        : _phase == 'early'
            ? C.bad
            : const Color(0xFFB8C4E0);
    final text = _phase == 'go'
        ? 'ЖМИ!'
        : _phase == 'early'
            ? 'Рано!'
            : _phase == 'ok'
                ? '${_times.last} мс'
                : 'Жди…';
    return Column(children: [
      _hint('Попытка ${math.min(attempts, _times.length + 1)} из $attempts. Жми, как только круг станет зелёным.'),
      Expanded(
        child: Center(
          child: GestureDetector(
            onTap: _tap,
            behavior: HitTestBehavior.opaque,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 120),
              width: 240, height: 240,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: color, shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: alpha(color, 0.5), blurRadius: 26, offset: const Offset(0, 10))],
              ),
              child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900)),
            ),
          ),
        ),
      ),
    ]);
  }
}

// ---------------------------------------------------------------- Струп
class StroopGame extends StatefulWidget {
  final int trials;
  final Done onDone;
  const StroopGame({super.key, required this.trials, required this.onDone});
  @override
  State<StroopGame> createState() => _StroopGameState();
}

class _StroopGameState extends State<StroopGame> {
  static const _names = ['Красный', 'Синий', 'Зелёный', 'Жёлтый'];
  static const _colors = [Color(0xFFE5484D), Color(0xFF3B82F6), Color(0xFF22A559), Color(0xFFF5B50A)];
  int _idx = 0, _correct = 0, _word = 0, _ink = 0;
  final List<int> _times = [];
  final _sw = Stopwatch();

  @override
  void initState() {
    super.initState();
    _newTrial();
  }

  void _newTrial() {
    _word = _rnd.nextInt(4);
    _ink = _rnd.nextDouble() < 0.7 ? (_word + 1 + _rnd.nextInt(3)) % 4 : _word;
    _sw
      ..reset()
      ..start();
  }

  void _answer(int i) {
    GameSounds.tap();
    _times.add(_sw.elapsedMilliseconds);
    if (i == _ink) _correct++;
    if (_idx + 1 >= widget.trials) {
      widget.onDone({
        'total': widget.trials,
        'correct': _correct,
        'avg_ms': _times.reduce((a, b) => a + b) / _times.length,
      });
      return;
    }
    setState(() {
      _idx++;
      _newTrial();
    });
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        _hint('Нажми на ЦВЕТ букв, а не на слово.  ${_idx + 1} / ${widget.trials}'),
        Expanded(
          child: Center(
            child: Text(_names[_word].toUpperCase(),
                style: TextStyle(color: _colors[_ink], fontSize: 52, fontWeight: FontWeight.w900)),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: GridView.count(
            shrinkWrap: true,
            crossAxisCount: 2,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 2.6,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              for (var i = 0; i < 4; i++)
                GestureDetector(
                  onTap: () => _answer(i),
                  child: Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: alpha(Colors.white, 0.95),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: const Color(0xFFD7E6FF), width: 2),
                    ),
                    child: Text(_names[i], style: const TextStyle(color: C.ink, fontSize: 18, fontWeight: FontWeight.w800)),
                  ),
                ),
            ],
          ),
        ),
      ]);
}

// ---------------------------------------------------------------- Шульте
class SchulteGame extends StatefulWidget {
  final int size;
  final Done onDone;
  const SchulteGame({super.key, required this.size, required this.onDone});
  @override
  State<SchulteGame> createState() => _SchulteGameState();
}

class _SchulteGameState extends State<SchulteGame> {
  late final List<int> _cells;
  int _next = 1, _errors = 0, _hints = 0;
  int? _wrong;
  bool _hintOn = false;
  final _sw = Stopwatch()..start();

  int get _n => widget.size.clamp(3, 10).toInt();

  @override
  void initState() {
    super.initState();
    _cells = List.generate(_n * _n, (i) => i + 1)..shuffle(_rnd);
  }

  void _tap(int v) {
    GameSounds.tap();
    if (v == _next) {
      if (_next == _n * _n) {
        _sw.stop();
        widget.onDone({
          'size': _n,
          'seconds': _sw.elapsedMilliseconds / 1000.0,
          'errors': _errors,
          'hints': _hints,
        });
        return;
      }
      setState(() => _next++);
    } else {
      _errors++;
      setState(() => _wrong = v);
      Timer(const Duration(milliseconds: 250), () {
        if (mounted) setState(() => _wrong = null);
      });
    }
  }

  void _showHint() {
    _hints++;
    setState(() => _hintOn = true);
    Timer(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _hintOn = false);
    });
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        _hint2(),
        Expanded(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: AspectRatio(
                aspectRatio: 1,
                child: GridView.count(
                  crossAxisCount: _n,
                  mainAxisSpacing: 5,
                  crossAxisSpacing: 5,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    for (final v in _cells)
                      GestureDetector(
                        onTap: () => _tap(v),
                        child: Container(
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: v < _next
                                ? const Color(0xFFD5F3DF)
                                : (_hintOn && v == _next)
                                    ? const Color(0xFFFFE9A6)
                                    : v == _wrong
                                        ? const Color(0xFFFFD0D2)
                                        : Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0xFFD7E6FF), width: 1.5),
                          ),
                          child: Text('$v',
                              style: TextStyle(
                                  color: v < _next ? C.muted : C.ink,
                                  fontWeight: FontWeight.w900,
                                  fontSize: _n >= 7 ? 14 : 20)),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: GhostButton('💡 Подсказка (штраф 1 с)', onTap: _showHint),
        ),
      ]);

  Widget _hint2() => _hint('Находи числа по порядку: сейчас $_next из ${_n * _n}');
}

// ---------------------------------------------------------------- Память
class MemoryGame extends StatefulWidget {
  final int start;
  final Done onDone;
  const MemoryGame({super.key, required this.start, required this.onDone});
  @override
  State<MemoryGame> createState() => _MemoryGameState();
}

class _MemoryGameState extends State<MemoryGame> {
  int _len = 4, _best = 0, _mistakes = 0;
  String _number = '';
  bool _showing = true;
  Timer? _t;
  final _ctl = TextEditingController();
  String? _feedback;

  @override
  void initState() {
    super.initState();
    _len = widget.start.clamp(3, 8).toInt();
    _show();
  }

  @override
  void dispose() {
    _t?.cancel();
    _ctl.dispose();
    super.dispose();
  }

  void _show() {
    _number = List.generate(_len, (_) => _rnd.nextInt(10)).join();
    _ctl.clear();
    setState(() => _showing = true);
    _t = Timer(Duration(milliseconds: 1000 + 450 * _len), () {
      if (mounted) setState(() => _showing = false);
    });
  }

  void _submit() {
    GameSounds.tap();
    final ok = _ctl.text.trim() == _number;
    if (ok) {
      _best = math.max(_best, _len).toInt();
      if (_len >= 12) return _finish();
      _len++;
      _feedback = 'Верно! ✅';
    } else {
      _mistakes++;
      _feedback = 'Было: $_number';
      if (_mistakes >= 3) return _finish();
    }
    _show();
  }

  void _finish() => widget.onDone({'max_len': _best, 'mistakes': _mistakes});

  @override
  Widget build(BuildContext context) => Column(children: [
        _hint(_showing ? 'Запомни число' : 'Введи число, которое видел'),
        if (_feedback != null) Text(_feedback!, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w700)),
        Expanded(
          child: Center(
            child: _showing
                ? Text(_number, style: const TextStyle(color: C.ink, fontSize: 48, fontWeight: FontWeight.w900, letterSpacing: 4))
                : Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40),
                    child: TextField(
                      controller: _ctl,
                      autofocus: true,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: 4),
                      onSubmitted: (_) => _submit(),
                      decoration: const InputDecoration(border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
                    ),
                  ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text('Длина: $_len   ·   ошибок: $_mistakes / 3', style: const TextStyle(color: C.muted)),
        ),
        if (!_showing)
          Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), child: GameButton('Готово', onTap: _submit)),
      ]);
}

// ---------------------------------------------------------------- Светофор (Go/No-Go)
class GoNoGoGame extends StatefulWidget {
  final int trials;
  final Done onDone;
  const GoNoGoGame({super.key, required this.trials, required this.onDone});
  @override
  State<GoNoGoGame> createState() => _GoNoGoGameState();
}

class _GoNoGoGameState extends State<GoNoGoGame> {
  int _i = 0, _hits = 0, _goTotal = 0, _falseAlarms = 0, _noGoTotal = 0;
  final List<int> _rts = [];
  bool _visible = false, _isGo = true, _tapped = false;
  Timer? _t;
  final _sw = Stopwatch();

  @override
  void initState() {
    super.initState();
    _gap();
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  void _gap() {
    if (_i >= widget.trials) {
      widget.onDone({
        'hits': _hits,
        'go_total': _goTotal,
        'false_alarms': _falseAlarms,
        'nogo_total': _noGoTotal,
        'avg_ms': _rts.isEmpty ? 600.0 : _rts.reduce((a, b) => a + b) / _rts.length,
      });
      return;
    }
    setState(() => _visible = false);
    _t = Timer(Duration(milliseconds: 450 + _rnd.nextInt(450)), _show);
  }

  void _show() {
    if (!mounted) return;
    _isGo = _rnd.nextDouble() < 0.7;
    if (_isGo) {
      _goTotal++;
    } else {
      _noGoTotal++;
    }
    _tapped = false;
    _sw
      ..reset()
      ..start();
    setState(() => _visible = true);
    _t = Timer(const Duration(milliseconds: 900), () {
      if (!mounted) return;
      _i++;
      _gap();
    });
  }

  void _tap() {
    GameSounds.tap();
    if (!_visible || _tapped) return;
    _tapped = true;
    if (_isGo) {
      _hits++;
      _rts.add(_sw.elapsedMilliseconds);
    } else {
      _falseAlarms++;
    }
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        _hint('Зелёный — жми! Красный — не трогай!  ${math.min(_i + 1, widget.trials)} / ${widget.trials}'),
        Expanded(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: _tap,
            child: Center(
              child: Container(
                width: 220, height: 220,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: !_visible ? const Color(0x00000000) : (_isGo ? const Color(0xFF2FC25B) : C.bad),
                ),
              ),
            ),
          ),
        ),
      ]);
}

// ---------------------------------------------------------------- N-назад
class NBackGame extends StatefulWidget {
  final int n;
  final Done onDone;
  const NBackGame({super.key, required this.n, required this.onDone});
  @override
  State<NBackGame> createState() => _NBackGameState();
}

class _NBackGameState extends State<NBackGame> {
  static const total = 20;
  static const _letters = ['А', 'Б', 'В', 'Г', 'Д', 'Е'];
  late final List<String> _seq;
  int _i = 0, _hits = 0, _targets = 0, _false = 0, _nonTargets = 0;
  bool _pressed = false;
  Timer? _t;

  int get _n => widget.n.clamp(1, 3).toInt();

  @override
  void initState() {
    super.initState();
    _seq = [];
    for (var i = 0; i < total; i++) {
      if (i >= _n && _rnd.nextDouble() < 0.3) {
        _seq.add(_seq[i - _n]);
      } else {
        _seq.add(_letters[_rnd.nextInt(_letters.length)]);
      }
    }
    // Гарантируем хотя бы одну цель.
    final hasTarget = List.generate(total - _n, (k) => _seq[k + _n] == _seq[k]).any((e) => e);
    if (!hasTarget) _seq[_n + 2] = _seq[2];
    _t = Timer.periodic(const Duration(milliseconds: 2000), (_) => _step());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  void _step() {
    if (!mounted) return;
    // подводим итог по текущему символу
    if (_i >= _n) {
      final isTarget = _seq[_i] == _seq[_i - _n];
      if (isTarget) {
        _targets++;
        if (_pressed) _hits++;
      } else {
        _nonTargets++;
        if (_pressed) _false++;
      }
    }
    if (_i + 1 >= total) {
      _t?.cancel();
      widget.onDone({
        'n': _n, 'hits': _hits, 'targets': _targets,
        'false_alarms': _false, 'non_targets': math.max(1, _nonTargets),
      });
      return;
    }
    setState(() {
      _i++;
      _pressed = false;
    });
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        _hint('Жми «Совпало!», если символ такой же, как $_n ${_n == 1 ? 'шаг' : 'шага'} назад.  ${_i + 1} / $total'),
        Expanded(
          child: Center(
            child: Container(
              width: 200, height: 200, alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(40),
                border: Border.all(color: const Color(0xFFD7E6FF), width: 3),
              ),
              child: Text(_seq[_i], style: const TextStyle(color: C.ink, fontSize: 96, fontWeight: FontWeight.w900)),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: GameButton(_pressed ? 'Нажато ✓' : 'Совпало!', onTap: _pressed ? null : () => setState(() => _pressed = true)),
        ),
      ]);
}

// ---------------------------------------------------------------- Повтори за роботом (Саймон)
class SimonGame extends StatefulWidget {
  final int start;
  final Done onDone;
  const SimonGame({super.key, required this.start, required this.onDone});
  @override
  State<SimonGame> createState() => _SimonGameState();
}

class _SimonGameState extends State<SimonGame> {
  static const _colors = [Color(0xFFE5484D), Color(0xFF3B82F6), Color(0xFF22A559), Color(0xFFF5B50A)];
  final List<int> _seq = [];
  int _lit = -1, _pos = 0, _best = 0;
  bool _showing = true;
  bool _dead = false;

  @override
  void initState() {
    super.initState();
    for (var i = 0; i < widget.start.clamp(2, 8).toInt(); i++) {
      _seq.add(_rnd.nextInt(4));
    }
    _play();
  }

  @override
  void dispose() {
    _dead = true;
    super.dispose();
  }

  Future<void> _play() async {
    if (!mounted) return;
    setState(() {
      _showing = true;
      _pos = 0;
    });
    await Future.delayed(const Duration(milliseconds: 700));
    for (final p in _seq) {
      if (_dead || !mounted) return;
      setState(() => _lit = p);
      await Future.delayed(const Duration(milliseconds: 500));
      if (_dead || !mounted) return;
      setState(() => _lit = -1);
      await Future.delayed(const Duration(milliseconds: 250));
    }
    if (_dead || !mounted) return;
    setState(() => _showing = false);
  }

  void _tap(int p) {
    GameSounds.tap();
    if (_showing) return;
    if (p != _seq[_pos]) {
      widget.onDone({'max_len': _best, 'mistakes': 1});
      return;
    }
    setState(() => _lit = p);
    Timer(const Duration(milliseconds: 150), () {
      if (mounted) setState(() => _lit = -1);
    });
    _pos++;
    if (_pos >= _seq.length) {
      _best = _seq.length;
      if (_seq.length >= 12) {
        widget.onDone({'max_len': _best, 'mistakes': 0});
        return;
      }
      _seq.add(_rnd.nextInt(4));
      _play();
    }
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        _hint(_showing ? 'Смотри и запоминай…' : 'Твой ход! Повтори ${_seq.length} сигн.'),
        Expanded(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: AspectRatio(
                aspectRatio: 1,
                child: GridView.count(
                  crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    for (var i = 0; i < 4; i++)
                      GestureDetector(
                        onTap: () => _tap(i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 90),
                          decoration: BoxDecoration(
                            color: _lit == i ? _colors[i] : alpha(_colors[i], 0.35),
                            borderRadius: BorderRadius.circular(28),
                            boxShadow: _lit == i
                                ? [BoxShadow(color: alpha(_colors[i], 0.7), blurRadius: 24)]
                                : const [],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ]);
}

// ---------------------------------------------------------------- Лишнее
class OddGame extends StatefulWidget {
  final int size;
  final Done onDone;
  const OddGame({super.key, required this.size, required this.onDone});
  @override
  State<OddGame> createState() => _OddGameState();
}

class _OddGameState extends State<OddGame> {
  static const rounds = 8;
  static const _pairs = [
    ['🔵', '🟣'], ['🍎', '🍅'], ['🐶', '🐺'], ['😀', '😃'], ['⭐', '🌟'], ['🟦', '🟪'], ['🐱', '🐯'],
  ];
  int _r = 0, _correct = 0, _oddIdx = 0;
  late List<String> _pair;
  final List<int> _times = [];
  final _sw = Stopwatch();

  int get _n => widget.size.clamp(3, 6).toInt();

  @override
  void initState() {
    super.initState();
    _newRound();
  }

  void _newRound() {
    final p = List<String>.from(_pairs[_rnd.nextInt(_pairs.length)]);
    if (_rnd.nextBool()) p.setAll(0, [p[1], p[0]]);
    _pair = p;
    _oddIdx = _rnd.nextInt(_n * _n);
    _sw
      ..reset()
      ..start();
  }

  void _tap(int i) {
    _times.add(_sw.elapsedMilliseconds);
    if (i == _oddIdx) _correct++;
    if (_r + 1 >= rounds) {
      widget.onDone({
        'total': rounds,
        'correct': _correct,
        'avg_ms': _times.reduce((a, b) => a + b) / _times.length,
        'size': _n,
      });
      return;
    }
    setState(() {
      _r++;
      _newRound();
    });
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        _hint('Найди лишнюю фигуру.  ${_r + 1} / $rounds'),
        Expanded(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: AspectRatio(
                aspectRatio: 1,
                child: GridView.count(
                  crossAxisCount: _n, mainAxisSpacing: 6, crossAxisSpacing: 6,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    for (var i = 0; i < _n * _n; i++)
                      GestureDetector(
                        onTap: () => _tap(i),
                        child: Container(
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: alpha(Colors.white, 0.95),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: const Color(0xFFD7E6FF), width: 1.5),
                          ),
                          child: FittedBox(
                            child: Padding(
                              padding: const EdgeInsets.all(6),
                              child: Text(i == _oddIdx ? _pair[1] : _pair[0], style: const TextStyle(fontSize: 40)),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ]);
}
