import 'dart:math' as math;
import 'package:material_ui/material_ui.dart';
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/game_sounds.dart';
import '../core/models.dart';
import '../ui/kit.dart';
import '../ui/reward_animation.dart';
import 'games.dart';

void runTest(BuildContext context, String key, {List<String> queue = const [], bool pathMode = false, int? pathStageNumber}) {
  Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => TestHost(test: key, queue: queue, pathMode: pathMode, pathStageNumber: pathStageNumber)));
}

const _defaults = <String, int>{
  'schulte_size': 4, 'stroop_trials': 10, 'memory_start': 4, 'gonogo_trials': 24,
  'nback_n': 1, 'simon_start': 3, 'odd_size': 3,
};

/// Запускает тест, отправляет метрики на сервер (/api/results) и показывает результат.
class TestHost extends StatefulWidget {
  final String test;
  final List<String> queue;
  final bool pathMode;
  final int? pathStageNumber;
  const TestHost({super.key, required this.test, this.queue = const [], this.pathMode = false, this.pathStageNumber});
  @override
  State<TestHost> createState() => _TestHostState();
}

class _TestHostState extends State<TestHost> {
  late String _test;
  late List<String> _queue;
  Map<String, int>? _diff;
  Map<String, dynamic>? _res;
  String? _error;
  bool _sending = false;
  bool _pathMode = false;
  int _run = 0;
  int _pathStageNumber = 1;
  int? _resultBalance;

  @override
  void initState() {
    super.initState();
    _test = widget.test;
    _queue = [...widget.queue];
    _pathMode = widget.pathMode;
    _pathStageNumber = widget.pathStageNumber ?? AppState.I.pathProgress + 1;
    _loadDiff();
  }

  Future<void> _loadDiff() async {
    final r = await Api.difficulty(AppState.I.uid);
    final d = Map<String, int>.from(_defaults);
    if (r.ok) {
      r.map.forEach((k, v) {
        if (v is num) d[k] = v.toInt();
      });
    }
    if (mounted) setState(() => _diff = d);
  }

  Future<void> _finish(Map<String, dynamic> metrics) async {
    final balanceBefore = AppState.I.gems;
    setState(() => _sending = true);
    final r = await Api.sendResult(AppState.I.uid, _test, metrics);
    if (!mounted) return;
    if (!r.ok) {
      setState(() {
        _sending = false;
        _error = r.error;
      });
      return;
    }
    final res = r.map;
    final gained = ((res['gems_gain'] ?? 1) as num).toInt();
    final grown = await AppState.I.addPetXp(((res['xp_gain'] ?? 0) as num).toInt());
    final refreshed = await AppState.I.refresh();
    final resultBalance = refreshed ? AppState.I.gems : balanceBefore + gained;
    if (_pathMode) {
      final score = ((res['score'] ?? 0) as num).toInt();
      await AppState.I.completePathStage(_pathStageNumber, _starsForScore(score));
    }
    if (!mounted) return;
    GameSounds.success();
    setState(() {
      _sending = false;
      _res = res;
      _resultBalance = resultBalance;
      _error = null;
    });
    if (grown != null) toast('⭐', '${AppState.I.pet?.name ?? 'Питомец'} вырос!', 'Теперь $grown уровень');
    if (res['level_up'] == true) {
      final lvl = (res['lvl'] ?? {}) as Map;
      toast('🎖️', 'Новый уровень ${lvl['level']}!', '${lvl['title'] ?? ''}');
    }
  }

  void _again() => setState(() {
        _res = null;
        _resultBalance = null;
        _error = null;
        _run++;
      });

  void _next() {
    if (_queue.isEmpty) return;
    setState(() {
      _test = _queue.removeAt(0);
      _res = null;
      _error = null;
      _run++;
    });
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (_diff == null || _sending) {
      body = const Center(child: CircularProgressIndicator());
    } else if (_error != null) {
      body = Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Glass(child: Text('Результат не сохранён: $_error', style: const TextStyle(color: C.bad, fontWeight: FontWeight.w800))),
          const SizedBox(height: 14),
          GameButton('Ещё раз', onTap: _again),
        ]),
      );
    } else if (_res != null) {
      body = _ResultView(res: _res!, balance: _resultBalance ?? AppState.I.gems,
          hasNext: _queue.isNotEmpty, onAgain: _again, onNext: _next);
    } else {
      body = buildGame(_test, _diff!, _finish, key: ValueKey('$_test#$_run'));
    }
    return ScreenScaffold(title: kTestNames[_test] ?? _test, child: body);
  }
}

int _starsForScore(int score) => score >= 80 ? 3 : (score >= 60 ? 2 : 1);

class _ResultView extends StatelessWidget {
  final Map<String, dynamic> res;
  final int balance;
  final bool hasNext;
  final VoidCallback onAgain, onNext;
  const _ResultView({required this.res, required this.balance,
    required this.hasNext, required this.onAgain, required this.onNext});

  @override
  Widget build(BuildContext context) {
    final score = ((res['score'] ?? 0) as num).toInt();
    final lvl = (res['lvl'] ?? {}) as Map;
    final xp = ((res['xp_gain'] ?? 0) as num).toInt();
    final need = ((lvl['xp_needed'] ?? 100) as num).toInt();
    final frac = (need <= 0 ? 0.0 : ((lvl['xp_in_level'] ?? 0) as num).toInt() / need).clamp(0.0, 1.0).toDouble();
    final ach = (res['new_achievements'] ?? []) as List;
    final hats = (res['new_hats'] ?? []) as List;
    final stars = _starsForScore(score);
    final headline = score >= 80 ? 'Превосходно!' : score >= 60 ? 'Отличная работа!' : 'Хорошая попытка!';
    final encouragement = score >= 80
        ? 'Ты отлично справился. Так держать!'
        : score >= 60
            ? 'Внимание становится сильнее с каждой тренировкой.'
            : 'Сегодня ты сделал ещё один шаг. Попробуем улучшить результат в следующий раз.';

    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 660),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 22),
          children: [
            _ResultHero(score: score, stars: stars, headline: headline, encouragement: encouragement),
            const SizedBox(height: 12),
            CrystalRewardPanel(
              balance: balance,
              totalGain: math.max(1, ((res['gems_gain'] ?? 1) as num).toInt()).toInt(),
            ),
            const SizedBox(height: 12),
            Glass(
              radius: 20,
              padding: const EdgeInsets.all(16),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(color: const Color(0xFFE8F4FF), borderRadius: BorderRadius.circular(13)),
                  child: const Icon(Icons.lightbulb_rounded, color: Color(0xFF5F83D8), size: 21),
                ),
                const SizedBox(width: 11),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Подсказка тренера', style: TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 13)),
                  const SizedBox(height: 4),
                  Text('${res['recommendation'] ?? encouragement}',
                      style: const TextStyle(color: C.muted, fontSize: 12, height: 1.4)),
                ])),
              ]),
            ),
            if (xp > 0) ...[
              const SizedBox(height: 12),
              Glass(
                radius: 20,
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    const Icon(Icons.bolt_rounded, color: Color(0xFFF2A928), size: 21),
                    const SizedBox(width: 6),
                    Text('+$xp XP', style: const TextStyle(color: Color(0xFFE49A19), fontSize: 20, fontWeight: FontWeight.w900)),
                    const Spacer(),
                    Text('Уровень ${lvl['level'] ?? ''}', style: const TextStyle(color: C.muted, fontSize: 11, fontWeight: FontWeight.w800)),
                  ]),
                  const SizedBox(height: 9),
                  Bar(frac, color: const Color(0xFFF2B23E), height: 10),
                ]),
              ),
            ],
            for (final h in hats)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Glass(radius: 18, child: Row(children: [
                  const Text('🎩', style: TextStyle(fontSize: 26)),
                  const SizedBox(width: 11),
                  Expanded(child: Text('Новый аксессуар: ${(h as Map)['name']}',
                      style: const TextStyle(color: C.ink, fontWeight: FontWeight.w800, fontSize: 12))),
                ])),
              ),
            for (final a in ach)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Glass(radius: 18, child: Row(children: [
                  Text('${(a as Map)['emoji']}', style: const TextStyle(fontSize: 27)),
                  const SizedBox(width: 11),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Новое достижение: ${a['title']}', style: const TextStyle(color: C.ink, fontWeight: FontWeight.w900, fontSize: 12)),
                    Text('${a['desc']}', style: const TextStyle(color: C.muted, fontSize: 11)),
                  ])),
                ])),
              ),
            const SizedBox(height: 16),
            LayoutBuilder(builder: (context, box) {
              if (box.maxWidth < 390) {
                return Column(children: [
                  GameButton(hasNext ? 'Следующая тренировка  ›' : 'Повторить тренировку', onTap: hasNext ? onNext : onAgain),
                  const SizedBox(height: 8),
                  GhostButton('Вернуться назад', onTap: () => Navigator.of(context).maybePop()),
                ]);
              }
              return Row(children: [
                Expanded(child: GameButton(hasNext ? 'Следующая тренировка  ›' : 'Повторить', onTap: hasNext ? onNext : onAgain, height: 52)),
                const SizedBox(width: 10),
                GhostButton('Назад', onTap: () => Navigator.of(context).maybePop()),
              ]);
            }),
          ],
        ),
      ),
    );
  }
}

class _ResultHero extends StatelessWidget {
  final int score;
  final int stars;
  final String headline;
  final String encouragement;
  const _ResultHero({required this.score, required this.stars, required this.headline, required this.encouragement});

  @override
  Widget build(BuildContext context) {
    final pet = AppState.I.pet;
    return Container(
      padding: const EdgeInsets.fromLTRB(17, 16, 17, 15),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF537FD4), Color(0xFF756FCE), Color(0xFF8B77CE)],
        ),
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: Colors.white, width: 1.6),
        boxShadow: [BoxShadow(color: alpha(const Color(0xFF536DB4), .25), blurRadius: 18, offset: const Offset(0, 7))],
      ),
      child: Row(children: [
        SizedBox(
          width: 84,
          child: PetImage(pet: pet, art: pet == null ? 'robot' : null, size: 78),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('ТРЕНИРОВКА ЗАВЕРШЕНА',
              style: TextStyle(color: alpha(Colors.white, .78), fontSize: 9, letterSpacing: 1.05, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(headline, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          Text('Твой результат',
              style: TextStyle(color: alpha(Colors.white, .9), fontSize: 12, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Row(children: List.generate(3, (i) => Padding(
            padding: const EdgeInsets.only(right: 2),
            child: Icon(Icons.star_rounded, size: 22,
                color: i < stars ? const Color(0xFFFFDC68) : alpha(Colors.white, .28)),
          ))),
          const SizedBox(height: 2),
          Text(encouragement, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: alpha(Colors.white, .83), fontSize: 10, height: 1.25)),
        ])),
        const SizedBox(width: 7),
        Container(
          width: 58, height: 58,
          decoration: BoxDecoration(
            color: alpha(Colors.white, .16),
            shape: BoxShape.circle,
            border: Border.all(color: alpha(Colors.white, .48), width: 1.4),
          ),
          child: Center(child: Text('$score',
              style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900))),
        ),
      ]),
    );
  }
}
