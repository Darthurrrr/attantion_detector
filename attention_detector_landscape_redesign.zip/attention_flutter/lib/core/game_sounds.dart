import 'dart:async';
import 'package:audioplayers/audioplayers.dart';

/// Неброские оригинальные звуки интерфейса. Ошибка аудиоплагина не мешает игре.
class GameSounds {
  GameSounds._();

  static final AudioPlayer _player = AudioPlayer();
  static bool enabled = true;
  static double masterVolume = 0.68;

  static void tap() => unawaited(_play('audio/ui_tap.wav', 0.20));
  static void success() => unawaited(_play('audio/success_chime.wav', 0.25));
  static void reward() => unawaited(_play('audio/crystal_reward.wav', 0.28));
  static void transition() => unawaited(_play('audio/soft_transition.wav', 0.18));
  static void petTap() => unawaited(_play('audio/pet_tap.wav', 0.24));
  static void petCuddle() => unawaited(_play('audio/pet_cuddle.wav', 0.30));

  static Future<void> _play(String asset, double volume) async {
    if (!enabled) return;
    try {
      await _player.setVolume((volume * masterVolume).clamp(0.0, 1.0).toDouble());
      await _player.play(AssetSource(asset));
    } catch (_) {
      // В браузере звук может быть заблокирован до первого действия пользователя.
    }
  }

  static Future<void> dispose() async {
    try {
      await _player.dispose();
    } catch (_) {}
  }
}
