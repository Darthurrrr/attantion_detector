/// Адрес бэкенда. Меняется при запуске:
///   flutter run --dart-define=API_BASE=http://192.168.1.50:8000
/// Для эмулятора Android обычно http://10.0.2.2:8000
class Config {
  static const apiBase =
      String.fromEnvironment('API_BASE', defaultValue: 'http://127.0.0.1:8000');
  static const baseW = 390.0;
  static const baseH = 844.0;
  static const navH = 86.0;
}
