import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

/// Локальное хранение: текущий пользователь и коллекция питомцев
/// (в старой версии это был settings.json, теперь — shared_preferences).
class Store {
  static late SharedPreferences _p;
  static Future<void> init() async => _p = await SharedPreferences.getInstance();

  static AppUser? loadUser() {
    final raw = _p.getString('user');
    if (raw == null) return null;
    try {
      return AppUser.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  static Future<void> saveUser(AppUser? u) async {
    if (u == null) {
      await _p.remove('user');
    } else {
      await _p.setString('user', jsonEncode(u.toJson()));
    }
  }

  static Map<String, dynamic> loadPets(int uid) {
    final raw = _p.getString('pet_game_$uid');
    if (raw == null) return {'owned': [], 'active': null};
    try {
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return {'owned': [], 'active': null};
    }
  }

  static Future<void> savePets(int uid, Map<String, dynamic> data) =>
      _p.setString('pet_game_$uid', jsonEncode(data));

  static int loadEggs(int uid) => _p.getInt('universal_eggs_$uid') ?? 0;
  static Future<void> saveEggs(int uid, int value) =>
      _p.setInt('universal_eggs_$uid', value < 0 ? 0 : value);

  static int loadPathProgress(int uid) => _p.getInt('path_progress_$uid') ?? 0;

  static Future<void> savePathProgress(int uid, int value) =>
      _p.setInt('path_progress_$uid', value < 0 ? 0 : value);

  static Map<int, int> loadPathStars(int uid) {
    final raw = _p.getString('path_stars_$uid');
    if (raw == null) return <int, int>{};
    try {
      final decoded = jsonDecode(raw) as Map;
      return decoded.map((key, value) => MapEntry(
            int.tryParse(key.toString()) ?? 0,
            (value as num).toInt().clamp(0, 3).toInt(),
          ))..removeWhere((key, _) => key <= 0);
    } catch (_) {
      return <int, int>{};
    }
  }

  static Future<void> savePathStars(int uid, Map<int, int> values) =>
      _p.setString('path_stars_$uid', jsonEncode(values.map((k, v) => MapEntry('$k', v))));
}
