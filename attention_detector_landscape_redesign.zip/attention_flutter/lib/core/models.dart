class AppUser {
  final int id;
  final String name;
  final int? age;
  final String hat;
  final int goal;
  const AppUser({required this.id, required this.name, this.age, this.hat = '', this.goal = 50});

  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        id: (j['id'] as num).toInt(),
        name: (j['name'] ?? '').toString(),
        age: j['age'] == null ? null : (j['age'] as num).toInt(),
        hat: (j['hat'] ?? '').toString(),
        goal: j['goal'] == null ? 50 : (j['goal'] as num).toInt(),
      );

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'age': age, 'hat': hat, 'goal': goal};

  AppUser copyWith({String? hat, int? goal, int? age}) => AppUser(
      id: id, name: name, age: age ?? this.age, hat: hat ?? this.hat, goal: goal ?? this.goal);
}

int petXpForLevel(int level) {
  if (level <= 10) return 22;
  if (level <= 33) return 27;
  if (level <= 66) return 37;
  return 49;
}

int petLevelFromXp(int xp) {
  var level = 1;
  var remaining = xp < 0 ? 0 : xp;
  while (level < 99 && remaining >= petXpForLevel(level)) {
    remaining -= petXpForLevel(level);
    level++;
  }
  return level;
}

int petXpWithinLevel(int xp) {
  var remaining = xp < 0 ? 0 : xp;
  var level = 1;
  while (level < 99 && remaining >= petXpForLevel(level)) {
    remaining -= petXpForLevel(level);
    level++;
  }
  return remaining;
}

class Pet {
  final String id, name, emoji, art, rarity;
  int level, xp, evolution;

  Pet({
    required this.id,
    required this.name,
    required this.emoji,
    required this.art,
    required this.rarity,
    this.level = 1,
    this.xp = 0,
    this.evolution = 0,
  });

  factory Pet.fromJson(Map<String, dynamic> j) {
    final xp = ((j['xp'] ?? 0) as num).toInt();
    return Pet(
      id: j['id'].toString(),
      name: (j['name'] ?? 'Питомец').toString(),
      emoji: (j['emoji'] ?? '🟢').toString(),
      art: (j['art'] ?? j['id'] ?? 'slime').toString(),
      rarity: (j['rarity'] ?? 'Обычный').toString(),
      level: petLevelFromXp(xp),
      xp: xp,
      evolution: ((j['evolution'] ?? 0) as num).toInt(),
    );
  }

  int get xpInLevel => petXpWithinLevel(xp);
  int get xpNeeded => level >= 99 ? 0 : petXpForLevel(level);

  Map<String, dynamic> toJson() => {
        'id': id, 'name': name, 'emoji': emoji, 'art': art, 'rarity': rarity,
        'level': level, 'xp': xp, 'evolution': evolution,
      };

  Pet copy() => Pet.fromJson(toJson());

  /// Картинка с учётом стадии эволюции (как pet_art() в старом frontend.py).
  String get skin {
    const evo = {
      'slime': ['blue_slime', 'royal_slime'],
      'cat': ['cat_slime', 'royal_slime'],
      'fox': ['fox', 'phoenix'],
      'penguin': ['blue_slime', 'royal_slime'],
      'axolotl': ['axolotl', 'phoenix'],
      'dragon': ['dragon', 'phoenix'],
      'ghost': ['ghost', 'star'],
    };
    final skins = evo[id];
    if (evolution > 0 && skins != null && skins.length >= evolution) {
      return skins[evolution - 1];
    }
    return art;
  }
}

Pet _p(String id, String name, String emoji, String art, String rarity) =>
    Pet(id: id, name: name, emoji: emoji, art: art, rarity: rarity);

/// Каталог питомцев (совпадает с PETS из старого frontend.py).
final List<Pet> kPetCatalog = [
  _p('slime', 'Зелёный слайм', '🟢', 'slime', 'Обычный'),
  _p('cat', 'Котик', '🐱', 'cat_slime', 'Обычный'),
  _p('penguin', 'Пингвин', '🐧', 'penguin', 'Обычный'),
  _p('fox', 'Лисёнок', '🦊', 'fox', 'Редкий'),
  _p('hamster', 'Хомячок', '🐹', 'panda', 'Обычный'),
  _p('capybara', 'Капибара', '🦫', 'capybara', 'Редкий'),
  _p('ghost', 'Призрак', '👻', 'ghost', 'Редкий'),
  _p('axolotl', 'Аксолотль', '🦎', 'axolotl', 'Эпический'),
  _p('dragon', 'Дракончик', '🐉', 'dragon', 'Эпический'),
  _p('panda', 'Панда', '🐼', 'panda', 'Обычный'),
  _p('royal_slime', 'Королевский слайм', '👑', 'royal_slime', 'Легендарный'),
  _p('phoenix', 'Феникс', '🔥', 'phoenix', 'Легендарный'),
];

const Map<String, List<String>> kEggPools = {
  'common': ['Обычный'],
  'rare': ['Редкий', 'Эпический'],
  'epic': ['Эпический'],
  'legendary': ['Легендарный'],
};

const Map<String, String> kTestNames = {
  'reaction': 'Реакция',
  'stroop': 'Тест Струпа',
  'schulte': 'Таблица Шульте',
  'memory': 'Память на числа',
  'gonogo': 'Светофор',
  'nback': 'N-назад',
  'simon': 'Повтори за роботом',
  'odd': 'Лишнее',
};

const Map<String, String> kTestDesc = {
  'reaction': 'Жмите, как только круг станет зелёным. Проверяет скорость реакции.',
  'stroop': 'Выбирайте ЦВЕТ букв, а не само слово. Тренирует умение не отвлекаться.',
  'schulte': 'Находите числа по порядку. Сложность подстраивается под ваши результаты.',
  'memory': 'Запомните число и введите его. С каждым успехом оно длиннее.',
  'gonogo': 'Зелёный круг: жми. Красный: не трогай! Тренирует самоконтроль.',
  'nback': 'Нажимайте, если символ такой же, как N шагов назад.',
  'simon': 'Запомните последовательность сигналов и повторите её.',
  'odd': 'Найдите лишнюю фигуру среди одинаковых.',
};

const Map<String, String> kTestEmoji = {
  'reaction': '🎯', 'stroop': '🎨', 'schulte': '➕', 'memory': '🧠',
  'gonogo': '🚦', 'nback': '🧩', 'simon': '🎵', 'odd': '🔍',
};
