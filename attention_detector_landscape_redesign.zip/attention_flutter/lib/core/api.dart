import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';

class ApiResult {
  final dynamic data;
  final String? error;
  const ApiResult(this.data, this.error);
  bool get ok => error == null;
  Map<String, dynamic> get map =>
      data is Map ? Map<String, dynamic>.from(data as Map) : <String, dynamic>{};
  List<dynamic> get list => data is List ? data as List : const [];
}

/// Тонкая обёртка над REST API из backend.py (маршруты /api/...).
class Api {
  static const _headers = {'Content-Type': 'application/json'};

  static Uri _u(String path, [Map<String, String>? q]) =>
      Uri.parse('${Config.apiBase}/api$path').replace(queryParameters: q);

  static Future<ApiResult> _send(Future<http.Response> Function() call) async {
    try {
      final r = await call().timeout(const Duration(seconds: 8));
      dynamic body;
      try {
        body = jsonDecode(utf8.decode(r.bodyBytes));
      } catch (_) {}
      if (r.statusCode >= 400) {
        final d = (body is Map && body['detail'] != null)
            ? body['detail'].toString()
            : 'Ошибка сервера';
        return ApiResult(null, d);
      }
      return ApiResult(body, null);
    } catch (_) {
      return const ApiResult(null, 'Сервер недоступен');
    }
  }

  static Future<ApiResult> get(String p, [Map<String, String>? q]) =>
      _send(() => http.get(_u(p, q)));
  static Future<ApiResult> post(String p, Map<String, dynamic> b) =>
      _send(() => http.post(_u(p), headers: _headers, body: jsonEncode(b)));
  static Future<ApiResult> put(String p, Map<String, dynamic> b) =>
      _send(() => http.put(_u(p), headers: _headers, body: jsonEncode(b)));
  static Future<ApiResult> delete(String p, [Map<String, String>? q]) =>
      _send(() => http.delete(_u(p, q)));

  static Future<ApiResult> createUser(String name, int? age) =>
      post('/users', {'name': name, 'age': age});
  static Future<ApiResult> summary(int uid) => get('/summary', {'user_id': '$uid'});
  static Future<ApiResult> pathProgress(int uid) => get('/path-progress', {'user_id': '$uid'});
  static Future<ApiResult> savePathProgress(int uid, int level) =>
      put('/path-progress', {'user_id': uid, 'level': level});
  static Future<ApiResult> history(int uid, {int limit = 30}) =>
      get('/history', {'user_id': '$uid', 'limit': '$limit'});
  static Future<ApiResult> clearHistory(int uid) =>
      delete('/history', {'user_id': '$uid'});
  static Future<ApiResult> difficulty(int uid) =>
      get('/difficulty', {'user_id': '$uid'});
  static Future<ApiResult> sendResult(int uid, String test, Map<String, dynamic> m) =>
      post('/results', {'user_id': uid, 'test': test, 'metrics': m});
  static Future<ApiResult> shop() => get('/shop');
  static Future<ApiResult> buy(int uid, String item) =>
      post('/shop/buy', {'user_id': uid, 'item': item});
  static Future<ApiResult> setHat(int uid, String hat) =>
      put('/users/$uid/hat', {'hat': hat});
  static Future<ApiResult> setGoal(int uid, int goal) =>
      put('/users/$uid/goal', {'goal': goal});
}
