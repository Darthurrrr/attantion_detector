import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'api.dart';
import 'models.dart';
import 'store.dart';

class AppState extends ChangeNotifier {
  AppState._();
  static final AppState I = AppState._();

  AppUser? user;
  List<Pet> owned = [];
  String? activeId;
  Map<String, dynamic> summary = {};
  Map<String, dynamic> progress = {};
  bool serverOk = true;
  bool initialized = false;
  int pathProgress = 0;
  Map<int, int> pathStars = <int, int>{};
  int universalEggs = 0;

  /// Вид яйца, которое будет открыто следующим (common/rare/epic/legendary).
  String pendingEgg = 'common';

  int get uid => user?.id ?? 0;

  Pet? get pet {
    for (final p in owned) {
      if (p.id == activeId) return p;
    }
    return null;
  }

  int get level => ((progress['level'] ?? 1) as num).toInt();
  int get gems => ((progress['gems'] ?? 0) as num).toInt();
  int get streak => ((progress['streak'] ?? 0) as num).toInt();
  int get xpNow => ((progress['xp_in_level'] ?? 0) as num).toInt();
  int get xpNeed => math.max(1, ((progress['xp_needed'] ?? 100) as num).toInt()).toInt();

  Future<void> init() async {
    try {
      await Store.init();
      user = Store.loadUser();
      _loadPets();
      pathProgress = user == null ? 0 : Store.loadPathProgress(user!.id);
      pathStars = user == null ? <int, int>{} : Store.loadPathStars(user!.id);
      universalEggs = user == null ? 0 : Store.loadEggs(user!.id);
      if (user != null) {
        unawaited(_syncPathProgress(user!.id));
      }
    } finally {
      initialized = true;
      notifyListeners();
    }
  }

  void _loadPets() {
    owned = [];
    activeId = null;
    if (user == null) return;
    final data = Store.loadPets(user!.id);
    owned = ((data['owned'] ?? []) as List)
        .map((e) => Pet.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
    activeId = data['active']?.toString();
  }

  Future<void> _savePets() async {
    if (user == null) return;
    await Store.savePets(user!.id, {
      'owned': owned.map((p) => p.toJson()).toList(),
      'active': activeId,
    });
  }

  /// Возвращает текст ошибки или null.
  Future<String?> login(String name, int? age) async {
    final r = await Api.createUser(name.trim(), age);
    if (!r.ok) return r.error;
    user = AppUser.fromJson(r.map);
    await Store.saveUser(user);
    _loadPets();
    pathProgress = Store.loadPathProgress(user!.id);
    pathStars = Store.loadPathStars(user!.id);
    universalEggs = Store.loadEggs(user!.id);
    unawaited(_syncPathProgress(user!.id));
    notifyListeners();
    return null;
  }

  Future<void> logout() async {
    user = null;
    owned = [];
    activeId = null;
    pathProgress = 0;
    pathStars = <int, int>{};
    universalEggs = 0;
    summary = {};
    progress = {};
    await Store.saveUser(null);
    notifyListeners();
  }

  Future<bool> refresh() async {
    if (user == null) return false;
    final r = await Api.summary(user!.id);
    serverOk = r.ok;
    if (r.ok) {
      summary = r.map;
      progress = Map<String, dynamic>.from((summary['progress'] ?? {}) as Map);
    }
    notifyListeners();
    return r.ok;
  }

  Future<void> addUniversalEggs(int count) async {
    if (user == null || count <= 0) return;
    universalEggs += count;
    await Store.saveEggs(user!.id, universalEggs);
    notifyListeners();
  }

  Future<void> storePet(Pet fromCatalog) async {
    final existing = owned.where((p) => p.id == fromCatalog.id).toList();
    if (existing.isNotEmpty) {
      // Дубликат превращается в небольшой запас опыта питомца.
      final p = existing.first;
      // Повторное получение не создаёт вторую запись питомца.
      // Компенсация дубликата будет начисляться серверной системой призыва.
    } else {
      final fresh = fromCatalog.copy();
      fresh.level = 1;
      fresh.xp = 0;
      fresh.evolution = 0;
      owned.add(fresh);
    }
    activeId = fromCatalog.id;
    await _savePets();
    notifyListeners();
  }

  /// Возвращает новый уровень питомца, если он вырос, иначе null.
  Future<int?> addPetXp(int amount) async {
    final p = pet;
    if (amount <= 0 || p == null) return null;
    final old = p.level;
    p.xp = math.max(0, p.xp + amount).toInt();
    p.level = petLevelFromXp(p.xp);
    await _savePets();
    notifyListeners();
    return p.level > old ? p.level : null;
  }

  Future<void> selectPet(String id) async {
    if (owned.any((p) => p.id == id)) {
      activeId = id;
      await _savePets();
      notifyListeners();
    }
  }

  /// null — успех, иначе текст причины.
  Future<String?> evolve(String id) async {
    final p = owned.firstWhere((x) => x.id == id);
    const required = [33, 66];
    if (p.evolution >= 2 || p.level < required[p.evolution]) {
      return p.evolution >= 2 ? 'Максимальная стадия' : 'Нужен ${required[p.evolution]} уровень';
    }
    p.evolution += 1;
    await _savePets();
    notifyListeners();
    return null;
  }

  Future<void> _syncPathProgress(int userId) async {
    final remote = await Api.pathProgress(userId);
    if (!remote.ok || user?.id != userId) return;
    final serverLevel = ((remote.map['level'] ?? 0) as num).toInt();
    final localLevel = pathProgress;
    final merged = math.max(localLevel, serverLevel).toInt();
    if (merged != localLevel) {
      pathProgress = merged;
      await Store.savePathProgress(userId, merged);
      notifyListeners();
    }
    if (localLevel > serverLevel) {
      await Api.savePathProgress(userId, localLevel);
    }
  }

  /// Завершает конкретный этап и сохраняет его рейтинг (1–3 звезды).
  /// Номер этапа начинается с 1; повторное прохождение не уменьшает рейтинг.
  Future<void> completePathStage(int stageNumber, int stars) async {
    if (user == null || stageNumber < 1) return;
    final currentUser = user!.id;
    final rating = stars.clamp(1, 3).toInt();
    pathStars[stageNumber] = math.max(pathStars[stageNumber] ?? 0, rating).toInt();
    pathProgress = math.max(pathProgress, stageNumber).toInt();
    await Store.savePathProgress(currentUser, pathProgress);
    await Store.savePathStars(currentUser, pathStars);
    // Сервер хранит открытые этапы; рейтинг звёзд хранится локально для каждого пользователя.
    unawaited(Api.savePathProgress(currentUser, pathProgress).then<void>((_) {}));
    notifyListeners();
  }

  Future<void> advancePath() async {
    await completePathStage(pathProgress + 1, 1);
  }

  Future<String?> setGoal(int goal) async {
    final r = await Api.setGoal(uid, goal);
    if (!r.ok) return r.error;
    user = user!.copyWith(goal: goal);
    await Store.saveUser(user);
    await refresh();
    return null;
  }

  Future<String?> setHat(String hat) async {
    final r = await Api.setHat(uid, hat);
    if (!r.ok) return r.error;
    user = user!.copyWith(hat: hat);
    await Store.saveUser(user);
    notifyListeners();
    return null;
  }
}
