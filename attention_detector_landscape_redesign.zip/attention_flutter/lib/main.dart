import 'package:material_ui/material_ui.dart';
import 'package:flutter/services.dart';
import 'core/app_state.dart';
import 'screens/shell.dart';
import 'screens/splash.dart';
import 'screens/welcome.dart';
import 'ui/kit.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(const [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const AttentionApp());
  await Future.wait([
    AppState.I.init(),
    Future<void>.delayed(const Duration(milliseconds: 900)),
  ]);
}

class AttentionApp extends StatelessWidget {
  const AttentionApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Детектор внимания',
        debugShowCheckedModeBanner: false,
        scaffoldMessengerKey: messengerKey,
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF8050D8),
          scaffoldBackgroundColor: const Color(0xFF21153F),
          fontFamily: 'Roboto',
        ),
        home: const Root(),
      );
}

/// Корневой экран: решает, что показывать — вход, яйцо или главную.
class Root extends StatelessWidget {
  const Root({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final s = AppState.I;
          if (!s.initialized) return const SplashScreen();
          if (s.user == null) return const WelcomeScreen();
          return const Shell();
        },
      );
}
