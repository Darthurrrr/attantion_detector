import 'package:flutter_test/flutter_test.dart';
import 'package:attention_detector/core/models.dart';

void main() {
  test('каталог питомцев совпадает с версией на Flet', () {
    expect(kPetCatalog.length, 12);
    expect(kPetCatalog.map((p) => p.id).toSet().length, 12);
  });

  test('эволюция меняет картинку питомца', () {
    final slime = kPetCatalog.firstWhere((p) => p.id == 'slime').copy();
    expect(slime.skin, 'slime');
    slime.evolution = 1;
    expect(slime.skin, 'blue_slime');
    slime.evolution = 2;
    expect(slime.skin, 'royal_slime');
  });

  test('питомец сохраняется в JSON и обратно', () {
    final p = kPetCatalog.first.copy()..level = 3..xp = 250;
    final back = Pet.fromJson(p.toJson());
    expect(back.level, 3);
    expect(back.xp, 250);
    expect(back.name, p.name);
  });

  test('пулы редкости яиц ссылаются на существующие редкости', () {
    final rarities = kPetCatalog.map((p) => p.rarity).toSet();
    for (final pool in kEggPools.values) {
      expect(pool.any(rarities.contains), isTrue);
    }
  });
}
