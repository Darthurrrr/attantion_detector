import 'package:flutter_test/flutter_test.dart';
import 'package:attention_detector/main.dart';

void main() {
  testWidgets('Attention Detector root widget builds', (tester) async {
    await tester.pumpWidget(const AttentionApp());
    await tester.pump();
    expect(find.byType(AttentionApp), findsOneWidget);
  });
}
